# Planificador Microcurricular ERCA + DUA 3.0

Elaborado por: **MSc. Marco Perugachi Salazar**

Aplicación web (React + TypeScript + Vite) que arma el *prompt* para una IA, recibe su respuesta y la convierte en un documento institucional (PDF y Word) con logo, nombre de la unidad educativa y docente/tutor al pie.

## Ejecutar

```bash
npm install
npm run dev        # desarrollo: http://localhost:5173
npm run build      # genera la carpeta dist/ (sitio estático)
npm run preview    # prueba el build
```

Requiere Node.js 18 o superior.

## Flujo de uso

Al abrir (o al crear una «Nueva planificación») el sistema pregunta **¿Qué deseas planificar?**: PUD, micro-curricular, PCA, clase/diaria, recuperación pedagógica o por competencias (CNC). Cada tipo genera un prompt con su propia estructura.

1. **Institución**: nombre, logo, docente, tutor/a y firmantes (rector, vicerrector, comisión, secretario, inspector y los que agregues).
2. **Currículo**: sube el `.json`; busca por código, contenido o tema (sugiere destreza, indicador y objetivo) o elige criterio → destrezas a mano.
3. **Datos y tiempos**: curso, fechas, períodos por destreza (total de la unidad), competencias e inserciones con iconos, cronograma semanal por fases.
4. **Metodología y NEE**: ERCA, ACC, Saberes y conocimientos (MOSEIB), ABP, Proyectos, Indagación, DUA, Aula invertida o «que la IA elija»; estrategia activa; extensión; columnas del cuadro principal (activar, renombrar, reordenar); NEE.
5. **Fases y actividades**: actividades por fase editables, «Pegar lista», **Regenerar** (por fase o todas), **Imagen o esquema** y **Fórmula** (valores preestablecidos, constructor de ecuaciones o LaTeX).
6. **Prompt para IA**: instrucciones adicionales + copiar.
7. **PDF / Word**: pega la respuesta de la IA, ajusta la página y descarga. Antes de generar, el sistema pregunta **¿Quién firma el documento?** y agrega la tabla de legalización.
8. **Mis planificaciones** (por trimestre y parcial) y **Respaldo e iconos**.

## Iconografía de la metodología (DUA 3.0 y fases)

En «Fases y actividades» (y en «Respaldo e iconos») se suben una sola vez 6 imágenes: Compromiso, Representación y Acción y Expresión (DUA) y Anticipación, Construcción y Consolidación (fases). Se guardan en el dispositivo y en el respaldo, y se usan en todas las planificaciones sin modificar su diseño. Opcionalmente se sube una imagen por cada combinación de los tres colores (7 en total); las que no se suban se dibujan con los colores DUA.

En el documento (vista previa, PDF y Word) el sistema coloca junto al título de cada fase su icono y una barra que suma los principios DUA de sus actividades (los no aplicados quedan en blanco), y al final de cada actividad el indicador de los principios que le corresponden (los decide la IA; si falta, el sistema lo sugiere según el contenido). En la pantalla de fases puedes corregir los principios de cada actividad.

## Notas técnicas

- Todo se guarda en el navegador del dispositivo (`localStorage`). Para pasar el trabajo a otro equipo usa el respaldo `.json`.
- **PDF**: se genera con `pdfmake` (vectorial, texto seleccionable) y se descarga directamente; las filas largas de las tablas continúan en la página siguiente con el encabezado repetido, y cada página lleva membrete, pie con docente/tutor y «Pág. x de y».
- **Fórmulas**: LaTeX → SVG con la distribución de navegador de MathJax (`tex-svg-full`, se carga solo al usarla; incluye química con `\ce{}`); se incrustan como gráficos vectoriales en el PDF y como imágenes en Word. Los errores de sintaxis se muestran junto a la vista previa. Imágenes y fórmulas tienen tamaño ajustable.
- **Calendario**: las semanas se cuentan de lunes a domingo con los días de clase elegidos y sin feriados; una semana parcial recibe períodos proporcionales (períodos por semana × días de clase / días de clase por semana). Minutos por período: 40, 45 u otro.
- **Word**: se descarga un `.doc` (HTML/MHTML) con encabezado, pie, tablas e imágenes; si aparece una barra amarilla, pulsa «Habilitar edición».
- **Buscador**: local (BM25 con raíces de palabras), sin internet y sin modelo de lenguaje; sugiere y tú decides.
- **Marcadores**: la IA coloca `{{comp:...}}`, `{{ins:...}}`, `{{fig:...}}` y `{{eq:...}}`; el sistema los reemplaza por iconos, imágenes y fórmulas. Lo que la IA no coloque se agrega en un anexo.
- Ejemplo de JSON en `public/ejemplo-filosofia.json`.

## Estructura

```
src/
  App.tsx, main.tsx, styles.css, store.tsx, types.ts, constants.ts, defaults.ts
  lib/    curriculum.ts (JSON + buscador), schedule.ts (semanas y períodos),
          prompt.ts (prompt por tipo), docRender.ts (HTML/Word), pdf.ts (PDF), math.ts (fórmulas), actividades.ts, firmas.ts, planOps.ts
  pages/  Institucion, Curriculo, Datos, Metodologia, Fases, Prompt, Documento, Biblioteca, Respaldo
  components/  TipoModal, MathView, EquationBuilder, VisualDialogs
```
