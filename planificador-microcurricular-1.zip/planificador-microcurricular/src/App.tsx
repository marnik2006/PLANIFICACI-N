import { useEffect, useState } from 'react'
import { useApp } from './store'
import { CREDITO, TIPOS } from './constants'
import type { PageId } from './types'
import { TipoModal } from './components/TipoModal'
import InstitucionPage from './pages/InstitucionPage'
import CurriculoPage from './pages/CurriculoPage'
import DatosPage from './pages/DatosPage'
import MetodologiaPage from './pages/MetodologiaPage'
import FasesPage from './pages/FasesPage'
import PromptPage from './pages/PromptPage'
import DocumentoPage from './pages/DocumentoPage'
import BibliotecaPage from './pages/BibliotecaPage'
import RespaldoPage from './pages/RespaldoPage'

const NAV: { id: PageId; label: string; icon: string; paso?: number }[] = [
  { id: 'institucion', label: 'Institución', icon: '🏫', paso: 1 },
  { id: 'curriculo', label: 'Currículo', icon: '📚', paso: 2 },
  { id: 'datos', label: 'Datos y tiempos', icon: '🗓️', paso: 3 },
  { id: 'metodologia', label: 'Metodología y NEE', icon: '🧭', paso: 4 },
  { id: 'fases', label: 'Fases y actividades', icon: '🪜', paso: 5 },
  { id: 'prompt', label: 'Prompt para IA', icon: '✨', paso: 6 },
  { id: 'documento', label: 'PDF / Word', icon: '📄', paso: 7 },
  { id: 'biblioteca', label: 'Mis planificaciones', icon: '🗂️' },
  { id: 'respaldo', label: 'Respaldo e iconos', icon: '💾' },
]
const ids = NAV.map((n) => n.id)
const fromHash = (): PageId => {
  const h = window.location.hash.replace('#', '') as PageId
  return ids.includes(h) ? h : 'institucion'
}

export default function App() {
  const { toastMsg, saveError, state, setPlan } = useApp()
  const [page, setPage] = useState<PageId>(fromHash)
  const [cerrado, setCerrado] = useState(false)
  const [forzar, setForzar] = useState(false)
  const tipo = state.plan.tipo
  const abrirTipo = (!tipo && !cerrado) || forzar

  useEffect(() => {
    const onHash = () => setPage(fromHash())
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])
  useEffect(() => { if (!tipo) setCerrado(false) }, [tipo])

  const go = (p: PageId) => {
    window.location.hash = p
    setPage(p)
    window.scrollTo({ top: 0 })
  }
  const tipoDef = TIPOS.find((t) => t.id === tipo)

  return (
    <div className="app">
      <aside className="side">
        <div className="brand">
          <div className="faja" aria-hidden />
          <h1>Planificador Microcurricular</h1>
          <p>ERCA + DUA 3.0</p>
        </div>
        <nav aria-label="Secciones">
          {NAV.map((n) => (
            <button key={n.id} className={page === n.id ? 'on' : ''} onClick={() => go(n.id)} aria-current={page === n.id ? 'page' : undefined}>
              <span className="nav-ico" aria-hidden>{n.icon}</span>
              <span className="nav-txt">{n.label}</span>
              {n.paso && <span className="nav-n">{n.paso}</span>}
            </button>
          ))}
        </nav>
        <div className="side-foot">
          {state.institucion.nombre && <p className="side-inst">{state.institucion.nombre}</p>}
          <p>Elaborado por:<br /><strong>{CREDITO}</strong></p>
        </div>
      </aside>

      <main className="main">
        <div className="tipo-bar">
          <span>Planificando: <strong>{tipoDef ? tipoDef.nombre : 'sin elegir'}</strong></span>
          <button className="btn small" onClick={() => setForzar(true)}>{tipoDef ? 'Cambiar' : 'Elegir tipo'}</button>
        </div>
        {saveError && <div className="alert top">{saveError}</div>}
        {page === 'institucion' && <InstitucionPage />}
        {page === 'curriculo' && <CurriculoPage go={go} />}
        {page === 'datos' && <DatosPage go={go} />}
        {page === 'metodologia' && <MetodologiaPage go={go} />}
        {page === 'fases' && <FasesPage go={go} />}
        {page === 'prompt' && <PromptPage go={go} />}
        {page === 'documento' && <DocumentoPage />}
        {page === 'biblioteca' && <BibliotecaPage go={go} />}
        {page === 'respaldo' && <RespaldoPage />}
        <footer className="foot">Elaborado por: {CREDITO}</footer>
      </main>

      {abrirTipo && (
        <TipoModal
          actual={tipo}
          onClose={() => { setCerrado(true); setForzar(false) }}
          onPick={(t) => {
            setPlan({ tipo: t })
            setForzar(false)
            go(state.institucion.nombre.trim() ? 'curriculo' : 'institucion')
          }}
        />
      )}
      {toastMsg && <div className="toast" role="status">{toastMsg}</div>}
    </div>
  )
}
