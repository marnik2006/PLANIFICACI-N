import { useMemo, useState } from 'react'
import { Modal } from '../ui'
import { MathView } from './MathView'
import { CATEGORIAS } from '../lib/ecuaciones'
import { copyText } from '../lib/util'

export function EquationBuilder({ inicial, onInsert, onClose }: { inicial: string; onInsert: (tex: string) => void; onClose: () => void }) {
  const [code, setCode] = useState(inicial)
  const [cat, setCat] = useState(CATEGORIAS[0].id)
  const [q, setQ] = useState('')
  const piezas = useMemo(() => {
    if (q.trim()) return CATEGORIAS.flatMap((c) => c.piezas).filter((p) => p.label.toLowerCase().includes(q.toLowerCase()))
    return CATEGORIAS.find((c) => c.id === cat)!.piezas
  }, [cat, q])
  const add = (tex: string) => setCode((c) => (c.trim() ? `${c} ${tex}` : tex))
  return (
    <Modal title="Ecuaciones" onClose={onClose} wide>
      <input className="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar (fracción, integral…)" />
      <div className="eq-preview">{code.trim() ? <MathView latex={code} /> : <span className="muted">Toque una pieza de abajo para empezar</span>}</div>
      <label className="field">
        <span className="field-label">Código LaTeX</span>
        <textarea rows={2} className="mono" value={code} onChange={(e) => setCode(e.target.value)} />
        <span className="hint">Puede escribirlo a mano si conoce LaTeX. El dibujo de arriba es exactamente lo que saldrá impreso.</span>
      </label>
      <div className="seg wrap">
        {CATEGORIAS.map((c) => (
          <button key={c.id} className={cat === c.id && !q ? 'on' : ''} onClick={() => { setCat(c.id); setQ('') }}>{c.nombre}</button>
        ))}
      </div>
      <div className="tiles">
        {piezas.map((p) => (
          <button key={p.label + p.tex} className="tile" onClick={() => add(p.tex)} title={p.tex}>
            <span className="tile-m"><MathView latex={p.tex} display={false} /></span>
            <span className="tile-l">{p.label}</span>
          </button>
        ))}
      </div>
      <div className="row end">
        <button className="btn ghost" onClick={() => void copyText(code)}>Copiar código</button>
        <button className="btn ghost" onClick={() => setCode('')}>Limpiar</button>
        <button className="btn ghost" onClick={onClose}>Cancelar</button>
        <button className="btn primary" disabled={!code.trim()} onClick={() => onInsert(code.trim())}>Insertar</button>
      </div>
    </Modal>
  )
}
