import { useEffect, useState } from 'react'
import { latexToSvg, normalizeLatex } from '../lib/math'

export function MathView({ latex, display = true }: { latex: string; display?: boolean }) {
  const [html, setHtml] = useState<string | null>(null)
  const [bad, setBad] = useState('')
  useEffect(() => {
    let live = true
    const l = normalizeLatex(latex)
    if (!l) { setHtml(null); setBad(''); return }
    latexToSvg(l, display).then((r) => { if (live) { setHtml(r.svg || null); setBad(r.ok ? '' : r.motor ? 'No se pudo cargar el motor de fórmulas (revisa tu conexión y vuelve a intentar).' : `Error en la fórmula${r.mensaje ? ': ' + r.mensaje : ''}`) } }).catch(() => live && setBad('No se pudo dibujar la fórmula'))
    return () => { live = false }
  }, [latex, display])
  if (!latex.trim()) return null
  if (!html && !bad) return <span className="muted small">Dibujando…</span>
  return (
    <span>
      {html && <span className="math" dangerouslySetInnerHTML={{ __html: html }} />}
      {bad && <span className="math-err" role="alert"> {bad}</span>}
    </span>
  )
}
