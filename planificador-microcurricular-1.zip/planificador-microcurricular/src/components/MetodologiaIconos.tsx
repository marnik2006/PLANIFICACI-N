import type { ChangeEvent } from 'react'
import { useApp } from '../store'
import { COMBOS_DUA, DUA_PRINC, FASES_ICONO } from '../constants'
import { resizeIconPng } from '../lib/image'
import { comboSvg, svgUri } from '../lib/dua'

function Casilla({ k, titulo, sub, previo, onFile, onQuitar, subida }: { k: string; titulo: string; sub?: string; previo?: string; onFile: (k: string, e: ChangeEvent<HTMLInputElement>) => void; onQuitar: (k: string) => void; subida?: string }) {
  return (
    <div className="icon-card">
      <div className="icon-prev">{subida ? <img src={subida} alt={titulo} style={{ maxWidth: 52, maxHeight: 52 }} /> : previo ? <img src={previo} alt="" style={{ maxWidth: 52, maxHeight: 52, opacity: 0.85 }} /> : <span className="muted small">Sin icono</span>}</div>
      <div className="icon-txt">
        <strong>{titulo}</strong>
        <span className="muted small">{subida ? '✔ Cargado' : sub ?? 'Pendiente'}</span>
      </div>
      <div className="row">
        <label className="btn small">
          {subida ? 'Cambiar' : 'Subir'}
          <input type="file" accept="image/*" hidden onChange={(e) => onFile(k, e)} />
        </label>
        {subida && <button className="btn small ghost" onClick={() => onQuitar(k)}>Quitar</button>}
      </div>
    </div>
  )
}

/** Carga las 6 iconografías de la metodología (3 principios DUA + 3 fases) y los indicadores por combinación. */
export function MetodologiaIconos({ compacto = false }: { compacto?: boolean }) {
  const { state, update, toast } = useApp()
  const ic = state.iconos
  const seis = [...DUA_PRINC.map((p) => p.key), ...FASES_ICONO.map((f) => f.key)]
  const cargadas = seis.filter((k) => ic[k]).length

  async function onFile(k: string, e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    try {
      const url = await resizeIconPng(f, 256)
      update((s) => ({ ...s, iconos: { ...s.iconos, [k]: url } }))
    } catch {
      toast('No se pudo leer la imagen. Usa PNG, JPG o SVG.')
    }
  }
  const quitar = (k: string) =>
    update((s) => {
      const iconos = { ...s.iconos }
      delete iconos[k]
      return { ...s, iconos }
    })

  const cuerpo = (
    <>
      <p className="hint">Se suben una sola vez y se guardan en este dispositivo (también en el respaldo) para todas las planificaciones. Se usan tal cual, sin modificar su diseño.</p>
      <h3 className="sub-t">Principios DUA 3.0</h3>
      <div className="icons-grid">
        {DUA_PRINC.map((p) => <Casilla key={p.key} k={p.key} titulo={p.nombre.toUpperCase()} sub="Pendiente" subida={ic[p.key]} onFile={onFile} onQuitar={quitar} />)}
      </div>
      <h3 className="sub-t">Fases ERCA</h3>
      <div className="icons-grid">
        {FASES_ICONO.map((f) => <Casilla key={f.key} k={f.key} titulo={f.nombre.toUpperCase()} subida={ic[f.key]} onFile={onFile} onQuitar={quitar} />)}
      </div>
      <h3 className="sub-t">Indicador por actividad: una imagen por combinación (opcional)</h3>
      <p className="hint">Orden de los cuadros: 1.º Compromiso · 2.º Representación · 3.º Acción y expresión. Si no subes una combinación, se dibuja con los colores DUA.</p>
      <div className="icons-grid">
        {COMBOS_DUA.map((c) => <Casilla key={c.key} k={c.key} titulo={c.nombre} previo={svgUri(comboSvg(c.bits))} subida={ic[c.key]} onFile={onFile} onQuitar={quitar} />)}
      </div>
      <div className="seg" style={{ marginTop: 12 }}>
        <button className={state.duaModo === 'cuadros' ? 'on' : ''} onClick={() => update((s) => ({ ...s, duaModo: 'cuadros' }))}>Marcar con la combinación de cuadros</button>
        <button className={state.duaModo === 'iconos' ? 'on' : ''} onClick={() => update((s) => ({ ...s, duaModo: 'iconos' }))}>Marcar con los iconos de cada principio</button>
      </div>
    </>
  )

  if (compacto) {
    return (
      <details className={`card met-iconos ${cargadas < 6 ? 'pend' : ''}`} open={cargadas < 6}>
        <summary>
          <strong>Iconografía de la metodología</strong>{' '}
          <span className={`badge ${cargadas === 6 ? 'ok' : ''}`}>{cargadas}/6 cargadas</span>
          {cargadas < 6 && <span className="muted"> — súbelas una sola vez para ver las fases con su icono y barra DUA</span>}
        </summary>
        {cuerpo}
      </details>
    )
  }
  return (
    <div className="card">
      <h2 className="card-title">Iconografía de la metodología (DUA 3.0 y fases) <span className={`badge ${cargadas === 6 ? 'ok' : ''}`}>{cargadas}/6</span></h2>
      {cuerpo}
    </div>
  )
}
