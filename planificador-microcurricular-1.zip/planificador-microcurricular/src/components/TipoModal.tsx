import { Modal } from '../ui'
import { TIPOS } from '../constants'
import type { TipoPlan } from '../types'

export function TipoModal({ actual, onPick, onClose }: { actual: TipoPlan; onPick: (t: Exclude<TipoPlan, ''>) => void; onClose: () => void }) {
  return (
    <Modal title="¿Qué deseas planificar?" onClose={onClose}>
      <p className="hint">El tipo de documento cambia la estructura que pedirá el prompt a la IA. Puedes cambiarlo después.</p>
      <div className="tipos">
        {TIPOS.map((t) => (
          <button key={t.id} className={`tipo ${actual === t.id ? 'on' : ''}`} onClick={() => onPick(t.id)}>
            <span className="tipo-ico" aria-hidden>{t.icon}</span>
            <span>
              <strong>{t.nombre}</strong>
              <small>{t.desc}</small>
            </span>
            <span aria-hidden>›</span>
          </button>
        ))}
      </div>
    </Modal>
  )
}
