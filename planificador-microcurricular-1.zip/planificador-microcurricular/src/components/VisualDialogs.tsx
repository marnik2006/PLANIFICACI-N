import { useState, type ChangeEvent } from 'react'
import { Modal, Field } from '../ui'
import { MathView } from './MathView'
import { EquationBuilder } from './EquationBuilder'
import { PRESETS } from '../lib/ecuaciones'
import { resizeImage } from '../lib/image'
import type { ActividadFase, Visual } from '../types'

export interface Destino {
  fase: string
  actividades: ActividadFase[]
  semanas: { value: string; label: string }[]
}

function Tamano({ valor, onChange, tipo }: { valor: number; onChange: (v: number) => void; tipo: 'img' | 'formula' }) {
  const ops = tipo === 'img' ? [[25, 'Pequeña'], [45, 'Normal'], [70, 'Grande'], [100, 'Ancho completo']] : [[80, 'Pequeña'], [100, 'Normal'], [130, 'Grande'], [170, 'Muy grande']]
  return (
    <Field label={tipo === 'img' ? 'Tamaño en el documento' : 'Tamaño de la fórmula'}>
      <div className="seg wrap">
        {ops.map(([v, l]) => <button key={v} className={valor === v ? 'on' : ''} onClick={() => onChange(v as number)}>{l}</button>)}
      </div>
    </Field>
  )
}

function Colocacion({ d, semana, setSemana, act, setAct }: { d: Destino; semana: string; setSemana: (v: string) => void; act: number; setAct: (v: number) => void }) {
  return (
    <>
      <Field label="¿En qué subtema o semana aparece?" hint="Si lo deja en «Todas», se imprime en cada semana del plan.">
        <select value={semana} onChange={(e) => setSemana(e.target.value)}>
          <option value="todos">Todas las semanas</option>
          {d.semanas.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </Field>
      <Field label="¿A qué actividad acompaña?">
        <select value={act} onChange={(e) => setAct(Number(e.target.value))}>
          <option value={-1}>A toda la fase</option>
          {d.actividades.map((a, i) => <option key={a.id} value={i}>{i + 1}. {a.texto.slice(0, 60)}</option>)}
        </select>
      </Field>
    </>
  )
}

type NuevoVisual = Omit<Visual, 'id'>

export function FormulaDialog({ destino, onAdd, onClose }: { destino: Destino; onAdd: (v: NuevoVisual) => void; onClose: () => void }) {
  const [latex, setLatex] = useState('')
  const [tab, setTab] = useState('Física')
  const [pie, setPie] = useState('')
  const [semana, setSemana] = useState('todos')
  const [act, setAct] = useState(-1)
  const [builder, setBuilder] = useState(false)
  const [escala, setEscala] = useState(100)
  return (
    <>
      <Modal title="Fórmula" onClose={onClose}>
        <Field label="Fórmula" hint="Escriba LaTeX y se convierte solo: \frac{1}{2}, x^{2}, \sqrt{x}, \Delta, \rightleftharpoons. También acepta texto simple como v = d / t.">
          <textarea rows={2} className="mono" value={latex} onChange={(e) => setLatex(e.target.value)} placeholder="Ej.: v = d / t   ·   a² + b² = c²" />
        </Field>
        <div className="eq-preview">{latex.trim() ? <MathView latex={latex} /> : <span className="muted">La fórmula se verá aquí</span>}</div>
        <button className="btn" onClick={() => setBuilder(true)}>Σ Ecuaciones, matrices e integrales…</button>
        <div className="seg wrap">
          {Object.keys(PRESETS).map((t) => <button key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t}</button>)}
        </div>
        <div className="chips-eq">
          {PRESETS[tab].map((p) => <button key={p.label} className="btn small" onClick={() => setLatex((l) => l + p.tex)}>{p.label}</button>)}
        </div>
        <Tamano tipo="formula" valor={escala} onChange={setEscala} />
        <Field label="Pie o descripción"><input value={pie} onChange={(e) => setPie(e.target.value)} /></Field>
        <Colocacion d={destino} semana={semana} setSemana={setSemana} act={act} setAct={setAct} />
        <div className="row end">
          <button className="btn ghost" onClick={onClose}>Cancelar</button>
          <button className="btn primary" disabled={!latex.trim()} onClick={() => onAdd({ tipo: 'formula', src: '', latex: latex.trim(), pie, semana, fase: destino.fase, actividad: act, escala })}>Agregar</button>
        </div>
      </Modal>
      {builder && <EquationBuilder inicial={latex} onClose={() => setBuilder(false)} onInsert={(t) => { setLatex(t); setBuilder(false) }} />}
    </>
  )
}

export function ImageDialog({ destino, onAdd, onClose }: { destino: Destino; onAdd: (v: NuevoVisual) => void; onClose: () => void }) {
  const [src, setSrc] = useState('')
  const [err, setErr] = useState('')
  const [escala, setEscala] = useState(45)
  const [pie, setPie] = useState('')
  const [semana, setSemana] = useState('todos')
  const [act, setAct] = useState(-1)
  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    try { setSrc(await resizeImage(f, 900)); setErr('') } catch { setErr('No se pudo leer la imagen. Usa PNG, JPG o SVG.') }
  }
  return (
    <Modal title="Imagen o esquema" onClose={onClose}>
      <div className="row">
        <label className="btn primary">Elegir imagen<input type="file" accept="image/*" hidden onChange={(e) => void onFile(e)} /></label>
        {err && <span className="alert">{err}</span>}
      </div>
      {src && <div className="eq-preview"><img src={src} alt="Vista previa" style={{ width: `${escala}%`, maxWidth: '100%' }} /></div>}
      <Tamano tipo="img" valor={escala} onChange={setEscala} />
      <Field label="Pie o descripción"><input value={pie} onChange={(e) => setPie(e.target.value)} /></Field>
      <Colocacion d={destino} semana={semana} setSemana={setSemana} act={act} setAct={setAct} />
      <div className="row end">
        <button className="btn ghost" onClick={onClose}>Cancelar</button>
        <button className="btn primary" disabled={!src} onClick={() => onAdd({ tipo: 'img', src, latex: '', pie, semana, fase: destino.fase, actividad: act, escala })}>Agregar</button>
      </div>
    </Modal>
  )
}

export function PasteDialog({ fase, onAdd, onClose }: { fase: string; onAdd: (lines: string[]) => void; onClose: () => void }) {
  const [t, setT] = useState('')
  const lines = t.split('\n').map((l) => l.replace(/^\s*(?:[-•*·]|\d+[.)])\s*/, '').trim()).filter(Boolean)
  return (
    <Modal title={`Pegar lista — ${fase || 'todas las fases'}`} onClose={onClose}>
      <p className="hint">Una actividad por línea. Se quitan viñetas y numeración.</p>
      <textarea rows={8} value={t} onChange={(e) => setT(e.target.value)} placeholder={'- Dialogar en parejas sobre…\n- Observar un video del entorno…'} />
      <div className="row end">
        <button className="btn ghost" onClick={onClose}>Cancelar</button>
        <button className="btn primary" disabled={!lines.length} onClick={() => onAdd(lines)}>Agregar {lines.length || ''} actividad(es)</button>
      </div>
    </Modal>
  )
}
