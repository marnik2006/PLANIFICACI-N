import type { Estrategia, ColumnaCfg, Extension, MetodologiaId, TipoPlan } from './types'

export const CREDITO = 'MSc. Marco Perugachi Salazar'

/* ---------- iconos (SVG vectoriales: sirven igual en pantalla, PDF y Word) ---------- */

export interface IconDef { key: string; tipo: 'comp' | 'ins'; id: string; nombre: string; svg: string }

const S = {
  comunicacionales:
    '<path fill="#2540b8" d="M4 4h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H10l-5 4v-4H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><circle cx="8" cy="10.5" r="1.3" fill="#fff"/><circle cx="12" cy="10.5" r="1.3" fill="#fff"/><circle cx="16" cy="10.5" r="1.3" fill="#fff"/>',
  matematicas:
    '<rect x="3" y="3" width="18" height="18" rx="3" fill="#7a4bc4"/><path d="M12 7v10M7 12h10" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/>',
  digitales:
    '<rect x="2" y="4" width="20" height="13" rx="2" fill="#0f766e"/><rect x="4" y="6" width="16" height="9" rx="1" fill="#99f6e4"/><path d="M8 21h8M12 17v4" stroke="#0f766e" stroke-width="2" stroke-linecap="round" fill="none"/>',
  socioemocionales:
    '<circle cx="8" cy="8" r="3.2" fill="#c0392b"/><circle cx="16.5" cy="9" r="2.6" fill="#f2b134"/><path d="M2 20c0-3.6 2.7-6 6-6s6 2.4 6 6z" fill="#c0392b"/><path d="M13 20c0-2.6 1.6-4.6 3.8-4.6S22 17.4 22 20z" fill="#f2b134"/>',
  civica:
    '<path d="M12 2.5 2.5 8h19z" fill="#14213d"/><rect x="4.5" y="9.5" width="3" height="8" fill="#14213d"/><rect x="10.5" y="9.5" width="3" height="8" fill="#14213d"/><rect x="16.5" y="9.5" width="3" height="8" fill="#14213d"/><rect x="2.5" y="18.5" width="19" height="3" rx="1" fill="#14213d"/>',
  socioemocional:
    '<path d="M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z" fill="#d6336c"/>',
  vial:
    '<rect x="7" y="2" width="10" height="20" rx="3" fill="#374151"/><circle cx="12" cy="7" r="2.2" fill="#ef4444"/><circle cx="12" cy="12" r="2.2" fill="#f59e0b"/><circle cx="12" cy="17" r="2.2" fill="#22c55e"/>',
  sostenible:
    '<path d="M20 3C10 3 4 9 4 16c0 1.2.2 2.2.6 3.2 1 .4 2 .6 3.2.6C15 19.8 20 14 20 3z" fill="#2e9e5b"/><path d="M4.5 20.5C8 14 12 10.5 16 8.5" stroke="#fff" stroke-width="1.5" fill="none" stroke-linecap="round"/>',
  financiera:
    '<circle cx="12" cy="12" r="10" fill="#f2b134"/><circle cx="12" cy="12" r="7.5" fill="none" stroke="#b7791f" stroke-width="1.2"/><path d="M12 6.5v11M9.2 9.2c0-1.8 5.6-1.8 5.6 0s-5.6 1.6-5.6 3.4 5.6 1.8 5.6 0" stroke="#7a4b00" stroke-width="1.6" fill="none" stroke-linecap="round"/>',
  seguridad:
    '<path d="M12 2l8 3v6c0 5-3.5 9.4-8 11-4.5-1.6-8-6-8-11V5z" fill="#2540b8"/><path d="M8 12l3 3 5-6" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
}

export const COMPETENCIAS: IconDef[] = [
  { key: 'comp:comunicacionales', tipo: 'comp', id: 'comunicacionales', nombre: 'Comunicacionales', svg: S.comunicacionales },
  { key: 'comp:matematicas', tipo: 'comp', id: 'matematicas', nombre: 'Matemáticas/Disciplinares', svg: S.matematicas },
  { key: 'comp:digitales', tipo: 'comp', id: 'digitales', nombre: 'Digitales', svg: S.digitales },
  { key: 'comp:socioemocionales', tipo: 'comp', id: 'socioemocionales', nombre: 'Socioemocionales', svg: S.socioemocionales },
]

export const INSERCIONES: IconDef[] = [
  { key: 'ins:civica', tipo: 'ins', id: 'civica', nombre: 'Educación cívica, ética e integridad', svg: S.civica },
  { key: 'ins:socioemocional', tipo: 'ins', id: 'socioemocional', nombre: 'Educación socioemocional', svg: S.socioemocional },
  { key: 'ins:vial', tipo: 'ins', id: 'vial', nombre: 'Educación para la seguridad vial y movilidad sostenible', svg: S.vial },
  { key: 'ins:sostenible', tipo: 'ins', id: 'sostenible', nombre: 'Educación para el desarrollo sostenible', svg: S.sostenible },
  { key: 'ins:financiera', tipo: 'ins', id: 'financiera', nombre: 'Educación financiera', svg: S.financiera },
  { key: 'ins:seguridad', tipo: 'ins', id: 'seguridad', nombre: 'Educación para la Seguridad Integral', svg: S.seguridad },
]

export const ICON_CATALOG: IconDef[] = [...COMPETENCIAS, ...INSERCIONES]

/* ---------- ¿Qué deseas planificar? ---------- */

export const TIPOS: { id: Exclude<TipoPlan, ''>; nombre: string; corto: string; desc: string; icon: string }[] = [
  { id: 'pud', nombre: 'Plan de Unidad Didáctica (PUD)', corto: 'PUD', desc: 'Planificación por unidad con destrezas, metodología y evaluación', icon: '📘' },
  { id: 'micro', nombre: 'Planificación Micro-curricular por Unidad de Aprendizaje', corto: 'Micro', desc: 'Círculos de conocimiento, semanas por fases y adaptaciones NEE', icon: '🧩' },
  { id: 'pca', nombre: 'Plan Curricular Anual (PCA)', corto: 'PCA', desc: 'Visión anual de unidades, objetivos y tiempos', icon: '📅' },
  { id: 'clase', nombre: 'Planificación de Clase / Diaria', corto: 'Clase', desc: 'Una clase con momentos pedagógicos y tiempos por fase', icon: '🕒' },
  { id: 'recuperacion', nombre: 'Plan de Recuperación Pedagógica', corto: 'Recuperación', desc: 'Refuerzo para estudiantes con promedio bajo 7', icon: '🛟' },
  { id: 'cnc', nombre: 'Planificación por Competencias (CNC)', corto: 'CNC', desc: 'Nuevo currículo: competencias clave, saberes, experiencia de aprendizaje', icon: '🌟' },
]

/* ---------- metodologías de aprendizaje (fases) ---------- */

export type Rol = 'activar' | 'reflexionar' | 'construir' | 'aplicar' | 'crear' | 'socializar'
export interface FaseDef { nombre: string; rol: Rol; desc: string }
export interface MetodologiaDef { id: MetodologiaId; nombre: string; resumen: string; detalle: string; fases: FaseDef[] }

export const METODOLOGIAS: MetodologiaDef[] = [
  {
    id: 'ia',
    nombre: 'Que la IA elija',
    resumen: 'La IA escoge la más adecuada según destreza e indicador',
    detalle:
      'La IA selecciona, para cada destreza e indicador, la metodología más pertinente entre las oficiales y activas del sistema educativo ecuatoriano, y organiza las actividades por las fases de la elegida. Aquí podrás agregar imágenes, esquemas y fórmulas; las actividades por fase las propone la IA.',
    fases: [],
  },
  {
    id: 'erca',
    nombre: 'ERCA',
    resumen: 'Experiencia → Reflexión → Conceptualización → Aplicación',
    detalle:
      'Metodología recomendada por el Ministerio de Educación para el desarrollo de destrezas. Se basa en el ciclo de aprendizaje experiencial de Kolb: el estudiante parte de su experiencia concreta, reflexiona sobre ella, construye el concepto y lo transfiere a situaciones nuevas.',
    fases: [
      { nombre: 'Experiencia', rol: 'activar', desc: 'Activación de saberes previos a partir de vivencias y situaciones del contexto.' },
      { nombre: 'Reflexión', rol: 'reflexionar', desc: 'Análisis crítico de la experiencia: confrontar lo que se sabe con lo que falta por aprender.' },
      { nombre: 'Conceptualización', rol: 'construir', desc: 'Construcción del concepto, modelo o principio con la guía del docente y ejemplos resueltos.' },
      { nombre: 'Aplicación', rol: 'aplicar', desc: 'Transferencia a situaciones nuevas; el estudiante elige el formato para demostrar lo aprendido.' },
    ],
  },
  {
    id: 'acc',
    nombre: 'ACC',
    resumen: 'Anticipación → Construcción del conocimiento → Consolidación',
    detalle:
      'Tres momentos. Equivale al ERCA condensado: Anticipación = Experiencia; Construcción = Reflexión + Conceptualización; Consolidación = Aplicación. Es el formato clásico de la planificación microcurricular.',
    fases: [
      { nombre: 'Anticipación', rol: 'activar', desc: 'Activa conocimientos previos, motiva y genera conflicto cognitivo o pregunta generadora.' },
      { nombre: 'Construcción del conocimiento', rol: 'construir', desc: 'El docente modela, explica y guía el análisis paso a paso con ejemplos resueltos.' },
      { nombre: 'Consolidación', rol: 'aplicar', desc: 'Práctica autónoma o grupal, resolución de problemas nuevos, argumentación y transferencia.' },
    ],
  },
  {
    id: 'saberes',
    nombre: 'Saberes y conocimientos (MOSEIB)',
    resumen: 'Dominio → Aplicación → Creación → Socialización del conocimiento',
    detalle:
      'Ciclo de saberes y conocimientos del Modelo del Sistema de Educación Intercultural Bilingüe. Recomendado para instituciones bilingües interculturales: valora los saberes de la comunidad y cierra con la socialización.',
    fases: [
      { nombre: 'Dominio del conocimiento', rol: 'activar', desc: 'Se recuperan los saberes de la comunidad y se domina el conocimiento básico.' },
      { nombre: 'Aplicación del conocimiento', rol: 'aplicar', desc: 'El conocimiento se usa en situaciones concretas del entorno.' },
      { nombre: 'Creación del conocimiento', rol: 'crear', desc: 'Los estudiantes producen algo nuevo: un modelo, texto, propuesta o producto.' },
      { nombre: 'Socialización del conocimiento', rol: 'socializar', desc: 'Se comparte lo creado con la comunidad educativa y se retroalimenta.' },
    ],
  },
  {
    id: 'abp',
    nombre: 'ABP',
    resumen: 'Problema → Análisis e investigación → Soluciones → Socialización y evaluación',
    detalle: 'Aprendizaje Basado en Problemas: parte de un problema real del entorno que los estudiantes investigan y resuelven en equipo.',
    fases: [
      { nombre: 'Presentación del problema', rol: 'activar', desc: 'Se plantea un problema real y cercano que genera interés.' },
      { nombre: 'Análisis e investigación', rol: 'construir', desc: 'Los equipos investigan, contrastan fuentes y analizan causas.' },
      { nombre: 'Construcción de soluciones', rol: 'crear', desc: 'Se diseñan y argumentan propuestas de solución.' },
      { nombre: 'Socialización y evaluación', rol: 'socializar', desc: 'Se presentan las soluciones y se evalúa el proceso y el producto.' },
    ],
  },
  {
    id: 'proyectos',
    nombre: 'Proyectos',
    resumen: 'Pregunta o reto → Planificación → Ejecución y creación → Presentación y evaluación',
    detalle: 'Aprendizaje Basado en Proyectos: producto final interdisciplinar que responde a un reto del contexto.',
    fases: [
      { nombre: 'Pregunta o reto', rol: 'activar', desc: 'Se define la pregunta motriz o el reto del proyecto.' },
      { nombre: 'Planificación', rol: 'reflexionar', desc: 'Los equipos organizan roles, tareas, recursos y tiempos.' },
      { nombre: 'Ejecución y creación', rol: 'crear', desc: 'Se desarrolla el producto aplicando la destreza.' },
      { nombre: 'Presentación y evaluación', rol: 'socializar', desc: 'Se presenta el producto y se evalúa con rúbrica.' },
    ],
  },
  {
    id: 'indagacion',
    nombre: 'Indagación',
    resumen: 'Pregunta orientadora → Diseño → Recolección y análisis → Comunicación',
    detalle: 'Aprendizaje por indagación: los estudiantes formulan preguntas, recogen y analizan datos y comunican resultados.',
    fases: [
      { nombre: 'Pregunta orientadora', rol: 'activar', desc: 'Se formula una pregunta investigable a partir de una situación del entorno.' },
      { nombre: 'Diseño de la indagación', rol: 'reflexionar', desc: 'Se plantean hipótesis y se diseña cómo recoger la información.' },
      { nombre: 'Recolección y análisis', rol: 'construir', desc: 'Se recogen datos, se organizan y se interpretan.' },
      { nombre: 'Comunicación de resultados', rol: 'socializar', desc: 'Se comunican conclusiones con evidencias.' },
    ],
  },
  {
    id: 'dua',
    nombre: 'DUA',
    resumen: 'Representación → Acción y expresión → Implicación',
    detalle: 'Diseño Universal para el Aprendizaje: la secuencia se organiza ofreciendo múltiples formas de representación, de acción y expresión, y de implicación.',
    fases: [
      { nombre: 'Múltiples formas de representación', rol: 'construir', desc: 'El contenido se presenta en texto, imagen, audio, material concreto y símbolos.' },
      { nombre: 'Múltiples formas de acción y expresión', rol: 'aplicar', desc: 'El estudiante elige cómo practicar y demostrar lo aprendido.' },
      { nombre: 'Múltiples formas de implicación', rol: 'activar', desc: 'Se sostiene la motivación con opciones, relevancia y autorregulación.' },
    ],
  },
  {
    id: 'invertida',
    nombre: 'Aula invertida',
    resumen: 'Antes de la clase → Durante la clase → Después de la clase',
    detalle: 'La teoría se revisa en casa (videos, lecturas) y el aula se usa para debatir, resolver problemas y recibir tutoría.',
    fases: [
      { nombre: 'Antes de la clase', rol: 'activar', desc: 'Revisión autónoma de videos o lecturas con una guía de preguntas.' },
      { nombre: 'Durante la clase', rol: 'aplicar', desc: 'Debate, resolución de problemas y tutoría docente.' },
      { nombre: 'Después de la clase', rol: 'socializar', desc: 'Refuerzo, autoevaluación y extensión del aprendizaje.' },
    ],
  },
]

export const metodologiaDe = (id: MetodologiaId) => METODOLOGIAS.find((m) => m.id === id) ?? METODOLOGIAS[1]
/** Fases para el cronograma: si la IA elige, se usa ACC como base. */
export const fasesParaCronograma = (id: MetodologiaId) => (id === 'ia' ? metodologiaDe('acc') : metodologiaDe(id)).fases.map((f) => f.nombre)

/* ---------- estrategias activas, extensión, columnas ---------- */

export const ESTRATEGIAS: { id: Estrategia; nombre: string; desc: string }[] = [
  { id: 'ia', nombre: 'Que la IA elija', desc: 'La IA selecciona la estrategia más adecuada según la destreza y el indicador de evaluación.' },
  { id: 'abp', nombre: 'Aprendizaje Basado en Proyectos (ABP)', desc: 'Eje central y prioritario de la política pedagógica del país. Proyectos interdisciplinares que resuelven problemas del entorno real mediante trabajo en equipo y argumentación.' },
  { id: 'cooperativo', nombre: 'Aprendizaje Cooperativo y Colaborativo', desc: 'Pequeños equipos con roles definidos. El éxito se mide de forma colectiva e impulsa la socialización y las habilidades blandas.' },
  { id: 'invertida', nombre: 'Aula Invertida (Flipped Classroom)', desc: 'Los estudiantes revisan la teoría en casa (videos o lecturas) y el aula se libera para debates, resolución de problemas y tutoría docente.' },
  { id: 'gamificacion', nombre: 'Gamificación', desc: 'Mecánicas de juego en asignaturas troncales, con herramientas tecnológicas e IA, para dinamizar las clases y elevar la motivación.' },
  { id: 'rutinas', nombre: 'Rutinas de Pensamiento', desc: 'Estructuras breves que hacen visible el razonamiento del estudiante y facilitan la comprensión lectora y el pensamiento analítico.' },
]

export const EXTENSIONES: { id: Extension; nombre: string; desc: string; regla: string; n: number }[] = [
  { id: 'breve', nombre: 'Breve', n: 2, desc: '2 actividades por fase, 1–2 líneas cada una', regla: '2 actividades por fase; cada actividad en 1 a 2 líneas; orientaciones metodológicas sintéticas; evaluación en 4 líneas.' },
  { id: 'medio', nombre: 'Medio', n: 3, desc: '2–3 actividades por fase, 2–3 líneas cada una', regla: '2 a 3 actividades por fase; cada actividad en 2 a 3 líneas con un ejemplo concreto; evaluación en 4 a 5 líneas.' },
  { id: 'extenso', nombre: 'Extenso', n: 3, desc: '3 actividades por fase, 3–5 líneas cada una', regla: '3 actividades por fase; cada actividad en 3 a 5 líneas con pregunta guía, ejemplo resuelto y producto esperado; evaluación en 5 líneas.' },
  { id: 'muy_extenso', nombre: 'Muy extenso', n: 4, desc: '3 o más actividades, paso a paso detallado', regla: 'mínimo 3 actividades por fase; cada actividad en 5 a 8 líneas con paso a paso, tiempos parciales, preguntas guía, ejemplos resueltos, roles, materiales y criterios de logro; evaluación detallada.' },
]

export const COLUMNAS_DEFAULT: ColumnaCfg[] = [
  { id: 'destreza', label: 'DESTREZA CON CRITERIO DE DESEMPEÑO', on: true },
  { id: 'indicador', label: 'INDICADOR DE EVALUACIÓN', on: true },
  { id: 'orientaciones', label: 'ORIENTACIONES METODOLÓGICAS PARA LA ENSEÑANZA APRENDIZAJE', on: true },
  { id: 'recursos', label: 'RECURSOS', on: true },
  { id: 'evaluacion', label: 'EVALUACIÓN', on: true },
  { id: 'criterio', label: 'CRITERIO DE EVALUACIÓN', on: false },
  { id: 'tiempo', label: 'TIEMPO', on: false },
]

export const EVAL_SEMANA = 'Evaluación sumativa + retroalimentación'
export const GRADOS_NEE = ['G1', 'G2', 'G3']

/* ---------- iconografía de la metodología (DUA 3.0 + fases) ---------- */

export const DUA_PRINC = [
  { key: 'dua:compromiso', bit: 0, nombre: 'Compromiso', color: '#2e9e5b', emoji: '🟩' },
  { key: 'dua:representacion', bit: 1, nombre: 'Representación', color: '#7a4bc4', emoji: '🟪' },
  { key: 'dua:accion', bit: 2, nombre: 'Acción y Expresión', color: '#2f6fdb', emoji: '🟦' },
]
export const FASES_ICONO = [
  { key: 'fase:anticipacion', nombre: 'Anticipación' },
  { key: 'fase:construccion', nombre: 'Construcción' },
  { key: 'fase:consolidacion', nombre: 'Consolidación' },
]
export const COMBOS_DUA = [
  { bits: '100', nombre: 'Solo Compromiso (1.er color)' },
  { bits: '010', nombre: 'Solo Representación (color del medio)' },
  { bits: '001', nombre: 'Solo Acción y Expresión (3.er color)' },
  { bits: '110', nombre: 'Compromiso + Representación (1.er y 2.º)' },
  { bits: '011', nombre: 'Representación + Acción (2.º y 3.er)' },
  { bits: '101', nombre: 'Compromiso + Acción (1.er y 3.er)' },
  { bits: '111', nombre: 'Los tres principios' },
].map((c) => ({ ...c, key: `duac:${c.bits}` }))

/** Icono de fase que corresponde a cada rol de fase (ERCA/ACC y demás metodologías). */
export const faseIconoKey = (rol: Rol) => (rol === 'activar' ? 'fase:anticipacion' : rol === 'reflexionar' || rol === 'construir' ? 'fase:construccion' : 'fase:consolidacion')
