import type { AppState, Institucion, LayoutOpts, Plan } from './types'
import { COLUMNAS_DEFAULT } from './constants'

export const defaultLayout: LayoutOpts = {
  modo: 'auto',
  orientacion: 'landscape',
  papel: 'A4',
  margenMm: 12,
  fuentePt: 9,
  saltoPorSeccion: false,
  evitarCortarFilas: false,
  mostrarCredito: true,
}

export function defaultPlan(): Plan {
  const y = new Date().getFullYear()
  return {
    tipo: '',
    metodologia: 'erca',
    actividades: [],
    visuales: [],
    columnas: COLUMNAS_DEFAULT.map((c) => ({ ...c })),
    numUnidades: 6,
    refuerzo: [],
    firmas: ['docente', 'comision', 'vicerrector'],
    fechaDocumento: '',
    curriculoId: '',
    unidad: '',
    tema: '',
    grado: '',
    paralelos: '',
    jornada: 'Matutina',
    anioLectivo: `${y}-${y + 1}`,
    inicio: '',
    fin: '',
    periodosSemana: 5,
    minutosPeriodo: 45,
    diasClase: [1, 2, 3, 4, 5],
    feriados: [],
    objetivos: [],
    criterios: [],
    destrezas: [],
    extension: 'medio',
    estrategia: 'ia',
    cronograma: [],
    nee12: [],
    nee3: [],
    instrucciones: '',
    trimestre: 1,
    parcial: 1,
    respuesta: '',
    layout: { ...defaultLayout },
  }
}

export function defaultInstitucion(): Institucion {
  return {
    nombre: '',
    linea: '',
    logo: '',
    mostrarMinisterio: true,
    docente: '',
    tutor: '',
    vicerrector: '',
    comision: '',
    rector: '',
    secretario: '',
    inspector: '',
    extras: [],
  }
}

export function defaultState(): AppState {
  return {
    version: 1,
    institucion: defaultInstitucion(),
    curriculos: [],
    plan: defaultPlan(),
    planActualId: null,
    iconos: {},
    duaModo: 'cuadros',
    guardados: [],
  }
}
