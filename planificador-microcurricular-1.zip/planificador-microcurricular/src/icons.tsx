import { ICON_CATALOG } from './constants'
import { useApp } from './store'
import { iconSrc } from './lib/icons'

/** Muestra el icono subido por el docente o, si no hay, el vectorial por defecto. */
export function IconView({ k, size = 20 }: { k: string; size?: number }) {
  const { state } = useApp()
  const def = ICON_CATALOG.find((i) => i.key === k)
  return <img src={iconSrc(k, state.iconos)} alt={def?.nombre ?? k} width={size} height={size} style={{ objectFit: 'contain' }} />
}
