import type { ActividadFase, FaseActs, Plan } from '../types'
import { EXTENSIONES, metodologiaDe, type Rol } from '../constants'
import { uid } from './util'

const BANCO: Record<Rol, string[]> = {
  activar: [
    'Dialogar en parejas sobre experiencias cotidianas relacionadas con {tema} mediante preguntas generadoras.',
    'Registrar una lluvia de ideas con los saberes previos sobre {tema} en la pizarra o en un organizador gráfico.',
    'Observar una situación real, imagen o video del entorno de la comunidad vinculado con {tema} y formular dos preguntas.',
    'Plantear un dilema o problema cercano a la vida de los estudiantes que genere conflicto cognitivo sobre {tema}.',
    'Explorar material concreto del entorno (objetos, textos o recursos locales) y describir lo que se observa sobre {tema}.',
    'Compartir relatos o saberes de la familia y la comunidad relacionados con {tema}, valorando la diversidad cultural.',
  ],
  reflexionar: [
    'Plantear preguntas problematizadoras: ¿qué sabemos y qué necesitamos aprender sobre {tema}?',
    'Trabajar en parejas: comparar las ideas previas con la situación presentada y registrar conclusiones.',
    'Formular hipótesis o predicciones sobre {tema} para contrastarlas al cierre de la clase.',
    'Debatir en grupos pequeños dos posturas distintas sobre {tema}, argumentando con ejemplos del entorno.',
    'Completar una rutina de pensamiento (Veo–Pienso–Me pregunto) sobre la experiencia vivida.',
    'Identificar con un organizador gráfico qué se conoce, qué se quiere saber y qué se aprendió de {tema}.',
  ],
  construir: [
    'Explicar el concepto o procedimiento central de {tema} con el modelado del docente y un ejemplo resuelto paso a paso.',
    'Analizar en equipos un texto, caso o esquema sobre {tema} con una guía de preguntas.',
    'Elaborar un organizador gráfico (mapa conceptual o cuadro comparativo) que sistematice las ideas de {tema}.',
    'Resolver dos ejemplos guiados de {tema} y verificar los resultados con el docente.',
    'Construir en grupo un glosario ilustrado con los términos clave de {tema}.',
    'Revisar un video o lectura breve sobre {tema} y registrar tres ideas principales con evidencias.',
  ],
  aplicar: [
    'Resolver de forma autónoma problemas nuevos de {tema} y argumentar el procedimiento seguido.',
    'Aplicar lo aprendido a una situación real de la comunidad y presentar la solución en el formato que cada estudiante elija (informe, cartel, dramatización o exposición).',
    'Practicar en equipos una ficha de ejercicios graduados sobre {tema} y coevaluar los resultados.',
    'Transferir el concepto de {tema} a un caso distinto mediante un reto de pocas líneas.',
    'Elaborar un producto breve (infografía, audio o ficha) que demuestre la comprensión de {tema}.',
    'Autoevaluar el aprendizaje con una lista de cotejo y plantear una meta de mejora.',
  ],
  crear: [
    'Diseñar en equipos una propuesta, modelo o prototipo que aplique {tema} a un problema del entorno.',
    'Producir un texto, esquema o material original sobre {tema} usando recursos disponibles en la comunidad.',
    'Planificar y elaborar un producto final con roles definidos, cronograma y criterios de calidad.',
    'Elaborar una campaña o recurso digital sencillo que comunique lo aprendido sobre {tema}.',
    'Construir una solución al reto planteado y justificar las decisiones tomadas.',
    'Crear preguntas y ejercicios para que otro equipo ponga a prueba lo aprendido sobre {tema}.',
  ],
  socializar: [
    'Presentar el producto ante el curso y recibir retroalimentación con una rúbrica sencilla.',
    'Realizar una galería de aprendizajes donde cada equipo explique su trabajo sobre {tema}.',
    'Compartir los resultados con la comunidad educativa (otro curso, familias o autoridades) y registrar comentarios.',
    'Coevaluar los productos con una lista de cotejo y proponer mejoras concretas.',
    'Redactar una conclusión individual sobre lo aprendido de {tema} y cómo lo usará en su vida diaria.',
    'Cerrar con un diálogo socrático: ¿qué cambió en mi forma de entender {tema}?',
  ],
}

function pick<T>(arr: T[], n: number): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a.slice(0, Math.min(n, a.length))
}

const temaDe = (plan: Plan, asignatura: string) => plan.tema.trim() || plan.unidad.trim() || asignatura || 'el tema'

export function generarFase(plan: Plan, asignatura: string, rol: Rol): ActividadFase[] {
  const n = EXTENSIONES.find((e) => e.id === plan.extension)?.n ?? 3
  const tema = temaDe(plan, asignatura)
  return pick(BANCO[rol], n).map((t) => ({ id: uid(), texto: t.replace(/\{tema\}/g, tema) }))
}

export function generarActividades(plan: Plan, asignatura: string): FaseActs[] {
  return metodologiaDe(plan.metodologia).fases.length && plan.metodologia !== 'ia'
    ? metodologiaDe(plan.metodologia).fases.map((f) => ({ fase: f.nombre, items: generarFase(plan, asignatura, f.rol) }))
    : []
}
