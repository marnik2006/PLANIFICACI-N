import type { Criterio, Curriculo, Destreza, Indicador, Objetivo } from '../types'
import { uid } from './util'

/* ---------- lectura del JSON curricular ---------- */

const str = (v: unknown) => (v == null ? '' : String(v))

function toCurriculo(o: any): Curriculo | null {
  const crits = o?.criterios ?? o?.criterios_evaluacion ?? []
  if (!Array.isArray(crits) || !crits.length) return null
  const objetivos: Objetivo[] = (Array.isArray(o.objetivos) ? o.objetivos : []).map((x: any) => ({
    codigo: str(x.codigo),
    descripcion: str(x.descripcion ?? x.texto),
  }))
  const criterios: Criterio[] = crits.map((c: any) => ({
    codigo: str(c.codigo),
    descripcion: str(c.descripcion ?? c.texto),
    destrezas: (c.destrezas_con_criterios_de_desempeno ?? c.destrezas ?? []).map(
      (d: any): Destreza => ({ codigo: str(d.codigo), descripcion: str(d.descripcion ?? d.texto) }),
    ),
    indicadores: (c.indicadores_evaluacion ?? c.indicadores ?? []).map(
      (i: any): Indicador => ({ codigo: str(i.codigo), descripcion: str(i.descripcion ?? i.texto) }),
    ),
  }))
  return {
    id: uid(),
    asignatura: str(o.asignatura) || 'Sin asignatura',
    nivel: str(o.nivel),
    objetivos,
    criterios,
  }
}

export function parseCurriculos(text: string): Curriculo[] {
  let data: any
  try {
    data = JSON.parse(text)
  } catch {
    throw new Error('el archivo no es un JSON válido.')
  }
  const arr = Array.isArray(data) ? data : [data]
  const out = arr.map(toCurriculo).filter((x): x is Curriculo => !!x)
  if (!out.length) throw new Error('no contiene criterios de evaluación reconocibles.')
  return out
}

/* ---------- búsqueda inteligente local (BM25 + raíces de palabras) ---------- */

export const norm = (s: string) =>
  s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')

const STOP = new Set(
  'de la el los las un una unos unas y o u en a al del por para con sin sobre entre que se su sus como mas menos es son ser este esta estos estas lo le les ya muy tambien desde hasta segun mediante partir funcion cual cuales'.split(
    ' ',
  ),
)

const SUFIJOS = [
  'amiento', 'imiento', 'aciones', 'iciones', 'acion', 'icion', 'idades', 'idad', 'mente',
  'ismos', 'ismo', 'istas', 'ista', 'ando', 'iendo', 'ados', 'adas', 'idos', 'idas', 'ado',
  'ada', 'ido', 'ida', 'ales', 'al', 'ivos', 'ivas', 'ivo', 'iva', 'ores', 'or', 'es', 's',
  'ar', 'er', 'ir',
]

function stem(w: string): string {
  if (w.length <= 4) return w
  let r = w
  for (const suf of SUFIJOS) {
    if (r.endsWith(suf) && r.length - suf.length >= 4) {
      r = r.slice(0, r.length - suf.length)
      break
    }
  }
  if (r.length > 5) r = r.replace(/[aeo]$/, '')
  return r
}

export function tokenize(s: string): string[] {
  return norm(s)
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length > 1 && !STOP.has(w))
    .map(stem)
}

interface Doc {
  criterio: Criterio
  destreza: Destreza
  tf: Map<string, number>
  len: number
}
export interface Index {
  docs: Doc[]
  df: Map<string, number>
  avg: number
}

export function buildIndex(c: Curriculo): Index {
  const docs: Doc[] = []
  const df = new Map<string, number>()
  for (const criterio of c.criterios) {
    for (const destreza of criterio.destrezas) {
      const toks = [...tokenize(destreza.descripcion), ...tokenize(destreza.descripcion), ...tokenize(criterio.descripcion)]
      const tf = new Map<string, number>()
      toks.forEach((t) => tf.set(t, (tf.get(t) ?? 0) + 1))
      tf.forEach((_, t) => df.set(t, (df.get(t) ?? 0) + 1))
      docs.push({ criterio, destreza, tf, len: toks.length })
    }
  }
  const avg = docs.reduce((a, d) => a + d.len, 0) / Math.max(1, docs.length)
  return { docs, df, avg }
}

export interface Hit {
  destreza: Destreza
  criterio: Criterio
  score: number
  indicador?: Indicador
  objetivo?: Objetivo
}

function overlap(a: string[], b: Set<string>) {
  let n = 0
  for (const t of new Set(a)) if (b.has(t)) n++
  return n
}

/** Indicador del criterio que mejor evalúa la destreza (y el tema escrito, si lo hay). */
export function bestIndicador(criterio: Criterio, destreza: Destreza, query = ''): Indicador | undefined {
  if (!criterio.indicadores.length) return undefined
  const dt = tokenize(destreza.descripcion)
  const qt = tokenize(query)
  let best = criterio.indicadores[0]
  let bestScore = -1
  for (const ind of criterio.indicadores) {
    const it = new Set(tokenize(ind.descripcion))
    const s = overlap(dt, it) + 2 * overlap(qt, it)
    if (s > bestScore) {
      bestScore = s
      best = ind
    }
  }
  return best
}

export function bestObjetivo(c: Curriculo, texto: string): Objetivo | undefined {
  if (!c.objetivos.length) return undefined
  const tt = tokenize(texto)
  let best = c.objetivos[0]
  let bestScore = -1
  for (const o of c.objetivos) {
    const ot = new Set(tokenize(o.descripcion))
    const s = overlap(tt, ot) / Math.sqrt(ot.size + 1)
    if (s > bestScore) {
      bestScore = s
      best = o
    }
  }
  return best
}

export function search(c: Curriculo, idx: Index, query: string, limit = 8): Hit[] {
  const q = query.trim()
  if (!q) return []
  const nq = norm(q)
  const qt = tokenize(q)
  const N = idx.docs.length
  const k1 = 1.5
  const b = 0.75
  const scored: { doc: Doc; score: number }[] = []
  for (const doc of idx.docs) {
    let score = 0
    for (const t of qt) {
      let f = doc.tf.get(t) ?? 0
      if (!f && t.length >= 4) {
        // coincidencia parcial por prefijo: «mito» ↔ «mítico», «argument» ↔ «argumentación»
        doc.tf.forEach((v, k) => {
          if (k.length < 4) return
          const m = Math.min(k.length, t.length)
          let c = 0
          while (c < m && k[c] === t[c]) c++
          if (c >= 3 && c >= Math.ceil(0.75 * m)) f += 0.5 * v
        })
      }
      if (!f) continue
      const n = idx.df.get(t) ?? 1
      const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5))
      score += (idf * (f * (k1 + 1))) / (f + k1 * (1 - b + (b * doc.len) / idx.avg))
    }
    const code = norm(doc.destreza.codigo)
    if (nq.length >= 2 && code.includes(nq)) score += 10
    if (!qt.length && norm(doc.destreza.descripcion).includes(nq)) score += 1
    if (score > 0) scored.push({ doc, score })
  }
  scored.sort((a, b2) => b2.score - a.score)
  return scored.slice(0, limit).map(({ doc, score }) => ({
    destreza: doc.destreza,
    criterio: doc.criterio,
    score,
    indicador: bestIndicador(doc.criterio, doc.destreza, q),
    objetivo: bestObjetivo(c, `${q} ${doc.destreza.descripcion} ${doc.criterio.descripcion}`),
  }))
}

/* ---------- sugerencia de competencias e inserciones ---------- */

export function suggestTags(texto: string, asignatura: string): { competencias: string[]; inserciones: string[] } {
  const t = norm(`${texto} ${asignatura}`)
  const competencias = new Set<string>()
  const inserciones = new Set<string>()
  if (/matemat|calcul|algebra|geometr|numer|ecuacion|funcion|estadist|probabil|fisica|quimica/.test(t)) competencias.add('comp:matematicas')
  if (/comunic|argument|discurs|lectura|texto|dialog|debat|oral|escrit|ensayo|analiz|discut/.test(t)) competencias.add('comp:comunicacionales')
  if (/digital|tecnolog|internet|software|computad|virtual|datos|informatic/.test(t)) competencias.add('comp:digitales')
  if (/emocion|empat|convivenc|respeto|identidad|bienestar|igualdad|violencia/.test(t)) competencias.add('comp:socioemocionales')
  if (!competencias.size) competencias.add('comp:comunicacionales')
  if (/democra|ciudadan|polit|etic|derecho|integridad|poder|justicia|tolerancia/.test(t)) inserciones.add('ins:civica')
  if (/emocion|empat|igualdad|violencia|masculinidad|acoso|bienestar/.test(t)) inserciones.add('ins:socioemocional')
  if (/casco|vial|transporte|movilidad|transito/.test(t)) inserciones.add('ins:vial')
  if (/ambient|sostenib|energia|ecolog|recursos|cosmos|naturaleza/.test(t)) inserciones.add('ins:sostenible')
  if (/financ|consumo|ahorro|economi|mercado/.test(t)) inserciones.add('ins:financiera')
  if (/seguridad|proteccion|riesgo|prevencion/.test(t)) inserciones.add('ins:seguridad')
  return { competencias: [...competencias], inserciones: [...inserciones] }
}
