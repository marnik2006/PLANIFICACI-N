import { marked } from 'marked'
import DOMPurify from 'dompurify'
import type { Institucion, LayoutOpts, Plan, Visual } from '../types'
import { CREDITO, ICON_CATALOG } from '../constants'
import { safeName } from './util'
import { iconSrc } from './icons'
import { latexToSvg, normalizeLatex, rasterizeSvg } from './math'
import { fechaLarga, firmantesElegidos } from './firmas'
import { decorarMetodologia } from './duaDecor'

export type ResolvedLayout = LayoutOpts

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

/* ---------- cuerpo: Markdown/HTML de la IA → HTML seguro con iconos, imágenes y fórmulas ---------- */

function quitarLegalizacion(md: string): string {
  const lines = md.split('\n')
  const i = lines.findIndex((l) => /^\s{0,3}(#{1,6}\s*|\*\*)?\s*([A-Z]\.\s*)?(\d+\.\s*)?LEGALIZACI[ÓO]N/i.test(l))
  if (i < 0) return md
  const hayOtra = lines.slice(i + 1).some((l) => /^\s{0,3}#{1,2}\s/.test(l))
  return hayOtra ? md : lines.slice(0, i).join('\n').trimEnd()
}

async function visualHtml(v: Visual): Promise<string> {
  const pie = v.pie ? `<div class="cap">${esc(v.pie)}</div>` : ''
  const esc100 = Math.min(100, Math.max(10, v.escala ?? (v.tipo === 'img' ? 45 : 100)))
  if (v.tipo === 'img') return `<div class="vis"><img src="${v.src}" alt="${esc(v.pie)}" data-escala="${esc100}" style="width:${esc100}%">${pie}</div>`
  const r = await latexToSvg(normalizeLatex(v.latex), true).catch(() => null)
  if (!r || !r.ok || !r.svg) return `<div class="vis"><div class="cap"><code>${esc(v.latex)}</code> (no se pudo dibujar la fórmula)</div>${pie}</div>`
  return `<div class="vis"><div class="eq" data-latex="${esc(v.latex)}" data-escala="${esc100}">${r.svg}</div>${pie}</div>`
}

interface Mate { tex: string; display: boolean }

/** Extrae $$…$$, \[…\], \(…\) y $…$ (fuera de bloques de código) y deja marcadores {{mj:N}}. */
function extraerMatematica(src: string): { texto: string; mates: Mate[] } {
  const mates: Mate[] = []
  const guardar = (tex: string, display: boolean) => `{{mj:${mates.push({ tex: tex.trim(), display }) - 1}}}`
  const partes = src.split(/(```[\s\S]*?```|`[^`\n]*`)/)
  const texto = partes
    .map((p, i) => {
      if (i % 2 === 1) return p
      return p
        .replace(/\$\$([\s\S]+?)\$\$/g, (_m, t: string) => guardar(t, true))
        .replace(/\\\[([\s\S]+?)\\\]/g, (_m, t: string) => guardar(t, true))
        .replace(/\\\(([\s\S]+?)\\\)/g, (_m, t: string) => guardar(t, false))
        .replace(/(?<![\\$\w])\$(?!\s)([^$\n]+?)(?<![\s\\])\$(?![\w$])/g, (m, t: string) => (/[\\^_{}=+\-*/<>]|[a-zA-Z]/.test(t) && !/^\d+([.,]\d+)?$/.test(t) ? guardar(t, false) : m))
    })
    .join('')
  return { texto, mates }
}

async function mateHtml(m: Mate): Promise<string> {
  const r = await latexToSvg(normalizeLatex(m.tex), m.display).catch(() => null)
  if (!r || !r.ok || !r.svg) return m.display ? `<div class="vis"><div class="cap"><code>${esc(m.tex)}</code></div></div>` : `<code>${esc(m.tex)}</code>`
  return m.display ? `<div class="vis"><div class="eq" data-latex="${esc(m.tex)}">${r.svg}</div></div>` : `<span class="eqi" data-latex="${esc(m.tex)}">${r.svg}</span>`
}

export async function renderBody(raw: string, iconos: Record<string, string>, visuales: Visual[], duaModo: 'cuadros' | 'iconos' = 'cuadros'): Promise<string> {
  let md = raw.trim()
  if (/^```(?:markdown|md|html)?\s*\n/i.test(md)) md = md.replace(/^```(?:markdown|md|html)?\s*\n/i, '').replace(/\n```\s*$/i, '') // solo si toda la respuesta venía envuelta
  const esHtml = /^\s*<(!doctype|html|table|div|h[1-6]|p|section)\b/i.test(md)
  if (!esHtml) md = quitarLegalizacion(md)
  const { texto, mates } = extraerMatematica(md)
  md = texto
  let html = esHtml ? md : (marked.parse(md, { gfm: true, breaks: true }) as string)
  html = DOMPurify.sanitize(html, { ADD_ATTR: ['colspan', 'rowspan'] })

  html = html.replace(/\{\{\s*(comp|ins)\s*:\s*([a-z_]+)\s*\}\}/gi, (_m, t: string, id: string) => {
    const key = `${t.toLowerCase()}:${id.toLowerCase()}`
    const nombre = esc(ICON_CATALOG.find((i) => i.key === key)?.nombre ?? key)
    return `<img class="ico" src="${iconSrc(key, iconos)}" alt="${nombre}" title="${nombre}" width="16" height="16">`
  })

  // iconos de fase, barra DUA e indicadores por actividad
  try {
    html = decorarMetodologia(html, iconos, duaModo)
  } catch {
    /* si algo falla se conserva el texto original */
  }

  // fórmulas escritas en LaTeX dentro de la respuesta de la IA
  for (let i = 0; i < mates.length; i++) {
    const tag = `{{mj:${i}}}`
    if (html.includes(tag)) html = html.split(tag).join(await mateHtml(mates[i]))
  }

  const usados = new Set<string>()
  const marcadores = [...html.matchAll(/\{\{\s*(fig|eq)\s*:\s*([a-z0-9]+)\s*\}\}/gi)]
  const reemplazos = new Map<string, string>()
  for (const m of marcadores) {
    const v = visuales.find((x) => x.id === m[2].toLowerCase())
    if (v && !reemplazos.has(m[0])) {
      reemplazos.set(m[0], await visualHtml(v))
      usados.add(v.id)
    }
  }
  reemplazos.forEach((val, key) => {
    html = html.split(key).join(val)
  })
  html = html.replace(/\{\{\s*(fig|eq)\s*:\s*[a-z0-9]+\s*\}\}/gi, '')

  const sueltos = visuales.filter((v) => !usados.has(v.id))
  if (sueltos.length) {
    const partes = await Promise.all(sueltos.map(visualHtml))
    html += `<h2>Anexo: material visual</h2>${partes.join('')}`
  }
  return html
}

/* ---------- diseño automático ---------- */

export function resolveLayout(l: LayoutOpts, bodyHtml: string): ResolvedLayout {
  if (l.modo === 'manual') return l
  let maxCols = 0
  try {
    const doc = new DOMParser().parseFromString(bodyHtml, 'text/html')
    doc.querySelectorAll('tr').forEach((tr) => {
      let n = 0
      Array.from(tr.children).forEach((c) => (n += Number((c as HTMLTableCellElement).colSpan) || 1))
      maxCols = Math.max(maxCols, n)
    })
  } catch {
    /* horizontal por defecto */
  }
  const wide = maxCols === 0 || maxCols >= 5
  return { ...l, orientacion: wide ? 'landscape' : 'portrait', fuentePt: wide ? 9 : 10, margenMm: 12, saltoPorSeccion: false, evitarCortarFilas: false }
}

export function docTitle(inst: Institucion, asignatura: string, unidad: string): string {
  return safeName([inst.nombre, asignatura, unidad || 'Planificación'].filter(Boolean).join(' - '))
}

/* ---------- legalización (firmas) ---------- */

export function legalizacionHtml(inst: Institucion, plan: Plan): string {
  const f = firmantesElegidos(inst, plan.firmas)
  if (!f.length) return ''
  const fecha = esc(fechaLarga(plan.fechaDocumento))
  const filas = f
    .map((s) => `<tr><td style="height:46px"></td><td>${esc(s.nombre || '—')}</td><td>${esc(s.cargo)}</td><td>${fecha}</td><td></td></tr>`)
    .join('')
  return `<h2>Legalización</h2><table><thead><tr><th>Firma</th><th>Nombre</th><th>Cargo</th><th>Fecha</th><th>Sello</th></tr></thead><tbody>${filas}</tbody></table>`
}

/* ---------- vista previa ---------- */

function headerHtml(inst: Institucion): string {
  const logo = inst.logo ? `<img src="${inst.logo}" alt="Logo" style="max-height:62px;max-width:90px">` : ''
  return `<table class="hdr"><tr><td class="hdr-l">${logo}</td><td class="hdr-c">
    ${inst.mostrarMinisterio ? '<div class="rep">REPÚBLICA DEL ECUADOR · MINISTERIO DE EDUCACIÓN</div>' : ''}
    <div class="inst">${esc(inst.nombre || 'NOMBRE DE LA UNIDAD EDUCATIVA').toUpperCase()}</div>
    ${inst.linea ? `<div class="sub">${esc(inst.linea)}</div>` : ''}</td><td class="hdr-l"></td></tr></table><div class="hdr-line"></div>`
}

function footerHtml(inst: Institucion, plan: Plan, l: LayoutOpts): string {
  const partes = [inst.docente ? `Docente: <b>${esc(inst.docente)}</b>` : '', inst.tutor ? `Tutor/a: <b>${esc(inst.tutor)}</b>` : ''].filter(Boolean).join(' &nbsp;·&nbsp; ')
  return `<div class="ftr-line"></div><div class="ftr"><span>${partes || '&nbsp;'}</span><span>${esc(inst.nombre)}${plan.anioLectivo ? ' · ' + esc(plan.anioLectivo) : ''}</span></div>${l.mostrarCredito ? `<div class="cred">Sistema elaborado por: ${esc(CREDITO)}</div>` : ''}`
}

export function buildPreviewHtml(o: { inst: Institucion; plan: Plan; body: string; layout: ResolvedLayout; title: string }): string {
  const l = o.layout
  const w = l.papel === 'A4' ? (l.orientacion === 'landscape' ? 297 : 210) : l.orientacion === 'landscape' ? 279 : 216
  const css = `*{box-sizing:border-box}body{margin:0;background:#cfd5e3;padding:14px;font-family:'Segoe UI',Calibri,Arial,sans-serif;font-size:${l.fuentePt}pt;color:#111;line-height:1.35}
.sheet{background:#fff;width:${w}mm;max-width:100%;margin:0 auto;padding:${l.margenMm}mm;box-shadow:0 2px 14px rgba(20,33,61,.25)}
table.hdr{width:100%;border-collapse:collapse}table.hdr td{border:0;padding:0 4px;vertical-align:middle}.hdr-l{width:90px}.hdr-c{text-align:center}
.rep{font-size:.78em;letter-spacing:.12em;color:#444}.inst{font-family:Georgia,serif;font-size:1.7em;font-weight:700;color:#14213d}.sub{font-size:.8em;color:#444}
.hdr-line{border-top:2px solid #14213d;margin:4px 0 8px}.ftr-line{border-top:1px solid #14213d;margin-top:14px}.ftr{display:flex;justify-content:space-between;font-size:.85em;padding-top:3px}.cred{font-size:.7em;color:#777;text-align:right}
.content h1{text-align:center;font-family:Georgia,serif;color:#14213d}.content h2{font-family:Georgia,serif;text-transform:uppercase;color:#14213d;border-bottom:2px solid #14213d;margin:14px 0 6px;font-size:1.15em}
.content table{width:100%;border-collapse:collapse;margin:6px 0}.content th,.content td{border:1px solid #6b7280;padding:3px 5px;vertical-align:top;overflow-wrap:anywhere}.content th{background:#14213d;color:#fff;text-align:left}
.content blockquote{margin:6px 0;padding:4px 10px;border-left:4px solid #6b7280;background:#f3f4f6}.ico{vertical-align:middle;margin:0 2px}
.fase-t{display:inline-flex;align-items:center;gap:6px;font-weight:700;margin:4px 0 2px}.fase-ico{height:18px;width:auto}.dua-combo{vertical-align:middle;margin-left:4px}.dua-bar{margin-left:4px}.vis{text-align:center;margin:6px 0}.vis img{max-width:100%;height:auto}.cap{font-style:italic;font-size:.9em;color:#444}.eq svg{max-width:100%;font-size:1.25em}`
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>${esc(o.title)}</title><style>${css}</style></head><body><div class="sheet">${headerHtml(o.inst)}<div class="content">${o.body}${legalizacionHtml(o.inst, o.plan)}</div>${footerHtml(o.inst, o.plan, l)}</div></body></html>`
}

/* ---------- Word (.doc en MHTML) ---------- */

function utf8ToB64(s: string): string {
  const bytes = new TextEncoder().encode(s)
  let bin = ''
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000))
  return btoa(bin)
}
const wrap76 = (b: string) => b.replace(/(.{76})/g, '$1\r\n')

async function aPngParaWord(html: string): Promise<string> {
  let out = html
  const svgs = [...new Set(html.match(/<svg[\s\S]*?<\/svg>/g) ?? [])]
  for (const s of svgs) {
    const wEx = parseFloat(/width="([\d.]+)ex"/.exec(s)?.[1] ?? '8')
    const hEx = parseFloat(/height="([\d.]+)ex"/.exec(s)?.[1] ?? '2')
    const w = Math.round(wEx * 8)
    const h = Math.round(hEx * 8)
    try {
      const png = await rasterizeSvg(s, w, h, 3)
      out = out.split(s).join(`<img src="${png}" width="${w}" height="${h}">`)
    } catch {
      /* se deja sin fórmula */
    }
  }
  const icons = [...new Set([...out.matchAll(/src="(data:image\/svg\+xml[^"]+)"/g)].map((m) => m[1]))]
  for (const uri of icons) {
    try {
      const svg = decodeURIComponent(uri.split(',').slice(1).join(','))
      const wi = parseFloat(/<svg[^>]*\swidth="([\d.]+)"/.exec(svg)?.[1] ?? '24')
      const hi = parseFloat(/<svg[^>]*\sheight="([\d.]+)"/.exec(svg)?.[1] ?? '24')
      const png = await rasterizeSvg(svg, wi, hi, 4)
      out = out.split(uri).join(png)
    } catch {
      /* ignorar */
    }
  }
  return out
}

export async function buildWordBlob(o: { inst: Institucion; plan: Plan; body: string; layout: ResolvedLayout; title: string }): Promise<Blob> {
  const { inst, plan, layout: l } = o
  const cm = (l.margenMm / 10).toFixed(2)
  const [w, h] = l.papel === 'A4' ? ['21.0cm', '29.7cm'] : ['21.59cm', '27.94cm']
  const size = l.orientacion === 'landscape' ? `${h} ${w}` : `${w} ${h}`
  const logo = inst.logo ? `<img src="${inst.logo}" width="70" alt="Logo">` : ''
  const partes = [inst.docente ? `Docente: <b>${esc(inst.docente)}</b>` : '', inst.tutor ? `Tutor/a: <b>${esc(inst.tutor)}</b>` : ''].filter(Boolean).join(' &nbsp;·&nbsp; ')
  const cuerpo = await aPngParaWord(o.body + legalizacionHtml(inst, plan))

  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>${esc(o.title)}</title>
<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->
<style>
@page WordSection1{size:${size};mso-page-orientation:${l.orientacion};margin:${cm}cm ${cm}cm ${(Number(cm) + 0.8).toFixed(2)}cm ${cm}cm;mso-header-margin:.5cm;mso-footer-margin:.5cm;mso-header:h1;mso-footer:f1}
div.WordSection1{page:WordSection1}
body{font-family:Calibri,Arial,sans-serif;font-size:${l.fuentePt}pt;color:#111}
h1{text-align:center;font-family:Georgia,serif;font-size:16pt;color:#14213d}
h2{font-family:Georgia,serif;font-size:12pt;color:#14213d;border-bottom:2px solid #14213d;text-transform:uppercase}
table{border-collapse:collapse;width:100%}td,th{border:1px solid #6b7280;padding:3pt;vertical-align:top}
th{background:#14213d;color:#ffffff;text-align:left}p{margin:3pt 0}
.vis{text-align:center}.cap{font-style:italic;text-align:center}
</style></head>
<body><div class="WordSection1">${cuerpo}</div>
<div style="mso-element:header" id="h1">
<table style="border:none;width:100%"><tr><td style="border:none;width:80pt">${logo}</td><td style="border:none;text-align:center">
${inst.mostrarMinisterio ? '<p style="text-align:center;font-size:8pt;margin:0">REPÚBLICA DEL ECUADOR · MINISTERIO DE EDUCACIÓN</p>' : ''}
<p style="text-align:center;font-family:Georgia,serif;font-size:16pt;font-weight:bold;color:#14213d;margin:0">${esc(inst.nombre || 'NOMBRE DE LA UNIDAD EDUCATIVA').toUpperCase()}</p>
${inst.linea ? `<p style="text-align:center;font-size:8pt;margin:0">${esc(inst.linea)}</p>` : ''}
</td><td style="border:none;width:80pt"></td></tr></table><p style="border-top:2px solid #14213d;margin:0;font-size:2pt">&nbsp;</p></div>
<div style="mso-element:footer" id="f1"><p style="border-top:1px solid #14213d;margin:0;font-size:2pt">&nbsp;</p>
<table style="border:none;width:100%"><tr><td style="border:none;font-size:8.5pt">${partes || '&nbsp;'}</td>
<td style="border:none;font-size:8.5pt;text-align:right">${esc(inst.nombre)}${plan.anioLectivo ? ' · ' + esc(plan.anioLectivo) : ''} · Pág. <span style="mso-field-code:' PAGE '"></span></td></tr></table>
${l.mostrarCredito ? `<p style="text-align:right;font-size:7pt;color:#777;margin:0">Sistema elaborado por: ${esc(CREDITO)}</p>` : ''}</div></body></html>`

  const imgs = new Map<string, { name: string; mime: string; b64: string }>()
  let n = 0
  const base = 'file:///C:/planificacion/'
  const finalHtml = html.replace(/src=(["'])data:(image\/[a-z0-9.+-]+);base64,([^"']+)\1/gi, (_m, _q, mime: string, b64: string) => {
    let e = imgs.get(b64)
    if (!e) {
      n++
      e = { name: `img${n}.${mime.split('/')[1].replace('jpeg', 'jpg')}`, mime, b64 }
      imgs.set(b64, e)
    }
    return `src="${base}${e.name}"`
  })
  const B = '----=_NextPart_planificador'
  const parts = [
    `MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary="${B}"; type="text/html"\r\n\r\n`,
    `--${B}\r\nContent-Type: text/html; charset="utf-8"\r\nContent-Transfer-Encoding: base64\r\nContent-Location: ${base}documento.htm\r\n\r\n${wrap76(utf8ToB64(finalHtml))}\r\n`,
  ]
  imgs.forEach((e) => parts.push(`--${B}\r\nContent-Type: ${e.mime}\r\nContent-Transfer-Encoding: base64\r\nContent-Location: ${base}${e.name}\r\n\r\n${wrap76(e.b64)}\r\n`))
  parts.push(`--${B}--`)
  return new Blob([parts.join('')], { type: 'application/msword' })
}
