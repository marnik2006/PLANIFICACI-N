import { DUA_PRINC, FASES_ICONO, METODOLOGIAS, faseIconoKey, type Rol } from '../constants'

export const DUA_EMOJI = DUA_PRINC.map((p) => p.emoji)

export const unirBits = (a: string, b: string) => [0, 1, 2].map((i) => (a[i] === '1' || b[i] === '1' ? '1' : '0')).join('')
export const bitsATriple = (bits: string) => [...bits].map((b, i) => (b === '1' ? DUA_EMOJI[i] : '⬜')).join('')
export const svgUri = (svg: string) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`

/** Tira de tres rectángulos unidos y con borde: Compromiso · Representación · Acción y expresión (no aplicados, en blanco). */
export function stripSvg(bits: string, w: number, h: number): string {
  const cw = (w - 1) / 3
  const r = [0, 1, 2]
    .map((i) => `<rect x="${(0.5 + i * cw).toFixed(2)}" y="0.5" width="${cw.toFixed(2)}" height="${h - 1}" fill="${bits[i] === '1' ? DUA_PRINC[i].color : '#ffffff'}" stroke="#374151" stroke-width="0.8"/>`)
    .join('')
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${r}</svg>`
}
export const comboSvg = (bits: string) => stripSvg(bits, 30, 9)
export const barSvg = (bits = '111') => stripSvg(bits, 56, 12)

/** Tamaño de un PNG en data URL (lee la cabecera IHDR). */
export function dataUrlSize(u: string): { w: number; h: number } | null {
  try {
    const b64 = u.split(',')[1]
    const bin = atob(b64.slice(0, 48))
    if (bin.charCodeAt(1) !== 0x50) return null
    const n = (o: number) => (bin.charCodeAt(o) << 24) | (bin.charCodeAt(o + 1) << 16) | (bin.charCodeAt(o + 2) << 8) | bin.charCodeAt(o + 3)
    return { w: n(16), h: n(20) }
  } catch {
    return null
  }
}

export interface Pic { src: string; w: number; h: number }
/** Imagen subida escalada a una altura dada (sin deformarla). */
export function picSubida(iconos: Record<string, string>, key: string, alto: number): Pic | null {
  const u = iconos[key]
  if (!u) return null
  const d = dataUrlSize(u)
  const asp = d && d.h ? d.w / d.h : 1
  return { src: u, w: Math.round(alto * asp * 10) / 10, h: alto }
}
export const picCombo = (iconos: Record<string, string>, bits: string): Pic =>
  picSubida(iconos, `duac:${bits}`, 10) ?? { src: svgUri(comboSvg(bits)), w: 30, h: 9 }
/** Barra junto al título de la fase: suma de los principios de sus actividades. */
export const picBarra = (iconos: Record<string, string>, bits = '111'): Pic => picSubida(iconos, `duac:${bits}`, 14) ?? { src: svgUri(barSvg(bits)), w: 56, h: 12 }

export function nombreAFaseRol(): Map<string, Rol> {
  const m = new Map<string, Rol>()
  METODOLOGIAS.forEach((x) => x.fases.forEach((f) => m.set(f.nombre.toLowerCase(), f.rol)))
  // nombres cortos con los que la IA suele titular las fases
  m.set('anticipación', 'activar')
  m.set('anticipación del conocimiento', 'activar')
  m.set('construcción', 'construir')
  m.set('consolidación', 'aplicar')
  return m
}
export const iconoDeFase = (rol: Rol) => FASES_ICONO.find((f) => f.key === faseIconoKey(rol))!

/* ---------- sugerencia local de principios DUA por actividad ---------- */

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const KW: string[][] = [
  ['dialog', 'conversator', 'compart', 'experienc', 'vivencia', 'motiv', 'interes', 'eleg', 'decid', 'opcion', 'comunidad', 'relat', 'generadora', 'reto', 'dilema', 'autoevalu', 'meta', 'valor', 'cooperativ', 'equipo', 'pareja', 'debat', 'familia', 'cotidian', 'curios', 'juego', 'gamific', 'lluvia de ideas', 'hipotesis'],
  ['observ', 'video', 'imagen', 'esquema', 'organizador', 'mapa', 'grafic', 'concret', 'glosario', 'lectura', 'model', 'ejemplo', 'explic', 'infograf', 'audio', 'ilustr', 'cartel', 'tabla', 'diagrama', 'texto', 'demostr', 'simbolo', 'visual', 'material', 'sistematiz'],
  ['resolv', 'elabor', 'produc', 'crear', 'creac', 'disen', 'argument', 'expon', 'informe', 'dramatiz', 'escrib', 'redact', 'construir', 'aplic', 'practic', 'comunic', 'sintetiz', 'formul', 'calcul', 'complet', 'respond', 'justific', 'propon', 'ejercicio', 'problema', 'producto', 'transfer'],
]
const BIAS: Record<Rol, number[]> = { activar: [1.2, 0, 0], reflexionar: [0.8, 0.4, 0], construir: [0, 1.2, 0], aplicar: [0, 0, 1.2], crear: [0, 0.2, 1], socializar: [0.5, 0, 1] }

/** Combinación pertinente de principios DUA: nunca asigna los tres por defecto. */
export function sugerirDua(texto: string, rol: Rol | null): string {
  const t = norm(texto)
  const s = KW.map((lista, i) => lista.reduce((a, k) => a + (t.includes(k) ? 1 : 0), 0) + (rol ? BIAS[rol][i] : 0))
  const max = Math.max(...s)
  if (max <= 0) return rol ? ['100', '010', '001', '010', '001', '001'][['activar', 'reflexionar', 'construir', 'aplicar', 'crear', 'socializar'].indexOf(rol)] : '100'
  let sel: number[] = s.map((v) => (v >= 1 && v >= 0.6 * max ? 1 : 0))
  if (sel.reduce((a, b) => a + b, 0) === 3 && Math.min(...s) < 2) {
    sel = sel.map((v, i) => (i === s.indexOf(Math.min(...s)) ? 0 : v))
  }
  if (!sel.some(Boolean)) sel[s.indexOf(max)] = 1
  return sel.join('')
}
