/* Decora el HTML del documento: icono + barra de colores en cada fase, e indicadores DUA por actividad. */
import { DUA_PRINC, METODOLOGIAS, faseIconoKey, type Rol } from '../constants'
import { nombreAFaseRol, picBarra, picCombo, picSubida, sugerirDua, svgUri, comboSvg, unirBits, type Pic } from './dua'

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
const BLOQUES = new Set(['P', 'LI', 'TD', 'TH', 'DIV', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'BLOCKQUOTE', 'TR', 'BODY', 'TABLE', 'UL', 'OL'])

const NOMBRES = [...new Set([...METODOLOGIAS.flatMap((m) => m.fases.map((f) => f.nombre)), 'Anticipación del conocimiento', 'Anticipación', 'Construcción', 'Consolidación'])].sort((a, b) => b.length - a.length)
const RE_FASE = new RegExp(`^\\s*(${NOMBRES.map((n) => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})(?![\\p{L}])`, 'iu')
const RE_TOK = /(🟩|⬜)\s*(🟪|⬜)\s*(🟦|⬜)|(🟩|🟪|🟦)(?=\s*(?:=|:|-|–)?\s*(?:compromiso|representaci|acci))|\(\d+\.\d+\)/giu
const RE_TRIPLE_INI = /^\s*(?:🟩|⬜)\s*(?:🟪|⬜)\s*(?:🟦|⬜)/u

const imgHtml = (p: Pic, cls: string, alt: string) => `<img class="ico ${cls}" src="${p.src}" width="${p.w}" height="${p.h}" alt="${esc(alt)}">`

function inicioDeLinea(n: Node): boolean {
  let cur: Node = n
  for (let k = 0; k < 20; k++) {
    let prev = cur.previousSibling
    while (prev && prev.nodeType === 3 && !(prev.textContent || '').trim()) prev = prev.previousSibling
    if (prev) return prev.nodeType === 1 && ((prev as Element).tagName === 'BR' || BLOQUES.has((prev as Element).tagName))
    const par = cur.parentNode
    if (!par || par.nodeType !== 1) return true
    if (BLOQUES.has((par as Element).tagName)) return true
    cur = par
  }
  return false
}

function indicador(bits: string, iconos: Record<string, string>, modo: 'cuadros' | 'iconos'): string {
  if (modo === 'iconos') {
    return [...bits]
      .map((b, i) => {
        if (b !== '1') return ''
        const p = picSubida(iconos, DUA_PRINC[i].key, 12)
        return p ? imgHtml(p, 'dua-combo', DUA_PRINC[i].nombre) : imgHtml({ src: svgUri(comboSvg(['100', '010', '001'][i])), w: 30, h: 9 }, 'dua-combo', DUA_PRINC[i].nombre)
      })
      .join('')
  }
  return imgHtml(picCombo(iconos, bits), 'dua-combo', `DUA ${bits}`)
}

export function decorarMetodologia(html: string, iconos: Record<string, string>, modo: 'cuadros' | 'iconos' = 'cuadros', inferir = true): string {
  if (!/Anticipaci|Experiencia|Reflexi|Conceptualizaci|Construcci|Consolidaci|Aplicaci|🟩|🟪|🟦|⬜|[A-Za-zÁ-ú]/.test(html)) return html
  const doc = new DOMParser().parseFromString(`<body>${html}</body>`, 'text/html')
  const walker = doc.createTreeWalker(doc.body, 4)
  const nodos: Text[] = []
  while (walker.nextNode()) nodos.push(walker.currentNode as Text)
  const roles = nombreAFaseRol()
  let rolActual: Rol | null = null
  let cambios = 0
  const uniones: string[] = [] // principios acumulados por fase, en orden de aparición
  const sumar = (bits: string) => { if (uniones.length) uniones[uniones.length - 1] = unirBits(uniones[uniones.length - 1], bits) }

  for (const n of nodos) {
    if ((n.parentElement as Element | null)?.closest('svg,code,pre,script,style')) continue
    const original = n.textContent || ''
    if (!original.trim()) continue
    let resto = original
    let out = ''
    const fm = inicioDeLinea(n) ? RE_FASE.exec(resto) : null
    if (fm) {
      const nombre = fm[1]
      const rol = roles.get(nombre.toLowerCase()) ?? 'activar'
      rolActual = rol
      const ico = picSubida(iconos, faseIconoKey(rol), 18)
      uniones.push('000')
      out += `<span class="fase-t">${ico ? imgHtml(ico, 'fase-ico', nombre) : ''}<b>${esc(nombre)}</b><img class="ico dua-bar" src="@@BARRA${uniones.length - 1}@@" alt="Principios DUA"></span>`
      resto = resto.slice(fm[0].length)
    }
    let last = 0
    let m: RegExpExecArray | null
    RE_TOK.lastIndex = 0
    const re = new RegExp(RE_TOK.source, RE_TOK.flags)
    while ((m = re.exec(resto))) {
      out += esc(resto.slice(last, m.index))
      if (m[1]) {
        const bits = [m[1], m[2], m[3]].map((x) => (x === '⬜' ? '0' : '1')).join('')
        out += indicador(bits, iconos, modo)
        sumar(bits)
        cambios++
      } else if (m[4]) {
        const i = DUA_PRINC.findIndex((p) => p.emoji === m![4])
        const p = picSubida(iconos, DUA_PRINC[i].key, 14)
        out += p ? imgHtml(p, '', DUA_PRINC[i].nombre) : esc(m[4])
        if (p) cambios++
      } else {
        out += esc(m[0])
        const despues = resto.slice(m.index + m[0].length)
        if (inferir && !RE_TRIPLE_INI.test(despues)) {
          const antes = resto.slice(last, m.index)
          const sig = despues.split(/\(\d+\.\d+\)/)[0]
          const txt = antes.trim().length >= 15 ? antes : `${antes} ${sig}`
          const sug = sugerirDua(txt, rolActual)
          out += ' ' + indicador(sug, iconos, modo)
          sumar(sug)
          cambios++
        }
      }
      last = m.index + m[0].length
    }
    out += esc(resto.slice(last))
    if (fm || out !== esc(original)) {
      const t = doc.createElement('template')
      t.innerHTML = out
      n.replaceWith(t.content)
      cambios++
    }
  }
  if (!cambios) return html
  let res = doc.body.innerHTML
  res = res.replace(/<img class="ico dua-bar" src="@@BARRA(\d+)@@" alt="Principios DUA">/g, (_m, i: string) => {
    const u = uniones[Number(i)] ?? '000'
    return imgHtml(picBarra(iconos, u === '000' ? '111' : u), 'dua-bar', 'Principios DUA')
  })
  return res
}
