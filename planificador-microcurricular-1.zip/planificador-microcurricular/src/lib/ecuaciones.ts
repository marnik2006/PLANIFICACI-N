export interface Pieza { label: string; tex: string }

export const CATEGORIAS: { id: string; nombre: string; piezas: Pieza[] }[] = [
  { id: 'basico', nombre: 'Básico', piezas: [
    { label: 'Fracción', tex: '\\frac{a}{b}' }, { label: 'Exponente', tex: 'x^{2}' }, { label: 'Subíndice', tex: 'x_{i}' },
    { label: 'Raíz cuadrada', tex: '\\sqrt{x}' }, { label: 'Raíz n-ésima', tex: '\\sqrt[n]{x}' }, { label: 'Paréntesis', tex: '\\left( x \\right)' },
    { label: 'Más/menos', tex: '\\pm' }, { label: 'Por', tex: '\\times' }, { label: 'Dividido', tex: '\\div' }, { label: 'Distinto', tex: '\\neq' },
    { label: 'Menor o igual', tex: '\\leq' }, { label: 'Mayor o igual', tex: '\\geq' }, { label: 'Aproximado', tex: '\\approx' }, { label: 'Grados', tex: '^{\\circ}' },
  ] },
  { id: 'ecuaciones', nombre: 'Ecuaciones', piezas: [
    { label: 'Cuadrática', tex: 'x=\\frac{-b\\pm\\sqrt{b^{2}-4ac}}{2a}' }, { label: 'Pitágoras', tex: 'a^{2}+b^{2}=c^{2}' }, { label: 'Recta', tex: 'y=mx+b' },
    { label: 'Pendiente', tex: 'm=\\frac{y_2-y_1}{x_2-x_1}' }, { label: 'Distancia', tex: 'd=\\sqrt{(x_2-x_1)^2+(y_2-y_1)^2}' },
    { label: 'Binomio', tex: '(a+b)^{2}=a^{2}+2ab+b^{2}' }, { label: 'Dif. de cuadrados', tex: 'a^{2}-b^{2}=(a-b)(a+b)' },
  ] },
  { id: 'sistemas', nombre: 'Sistemas', piezas: [
    { label: 'Sistema 2×2', tex: '\\begin{cases} a_1x+b_1y=c_1 \\\\ a_2x+b_2y=c_2 \\end{cases}' },
    { label: 'Sistema 3×3', tex: '\\begin{cases} a_1x+b_1y+c_1z=d_1 \\\\ a_2x+b_2y+c_2z=d_2 \\\\ a_3x+b_3y+c_3z=d_3 \\end{cases}' },
  ] },
  { id: 'matrices', nombre: 'Matrices', piezas: [
    { label: 'Matriz 2×2', tex: '\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}' },
    { label: 'Matriz 3×3', tex: '\\begin{pmatrix} a & b & c \\\\ d & e & f \\\\ g & h & i \\end{pmatrix}' },
    { label: 'Determinante', tex: '\\begin{vmatrix} a & b \\\\ c & d \\end{vmatrix}' },
    { label: 'Corchetes', tex: '\\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix}' },
  ] },
  { id: 'calculo', nombre: 'Cálculo', piezas: [
    { label: 'Integral', tex: '\\int_{a}^{b} f(x)\\,dx' }, { label: 'Derivada', tex: '\\frac{dy}{dx}' }, { label: 'Límite', tex: '\\lim_{x\\to a} f(x)' },
    { label: 'Sumatoria', tex: '\\sum_{i=1}^{n} a_i' }, { label: 'Productoria', tex: '\\prod_{i=1}^{n} a_i' }, { label: 'Parcial', tex: '\\frac{\\partial f}{\\partial x}' },
    { label: 'Integral doble', tex: '\\iint f(x,y)\\,dA' }, { label: 'Infinito', tex: '\\infty' },
  ] },
  { id: 'griegas', nombre: 'Griegas', piezas: ['alpha', 'beta', 'gamma', 'delta', 'epsilon', 'theta', 'lambda', 'mu', 'pi', 'rho', 'sigma', 'tau', 'varphi', 'omega', 'Delta', 'Omega', 'Sigma'].map((n) => ({ label: n, tex: `\\${n}` })) },
  { id: 'quimica', nombre: 'Química', piezas: [
    { label: 'Agua', tex: '\\ce{H2O}' }, { label: 'Dióxido de carbono', tex: '\\ce{CO2}' }, { label: 'Combustión', tex: '\\ce{2H2 + O2 -> 2H2O}' },
    { label: 'Equilibrio', tex: '\\ce{N2 + 3H2 <=> 2NH3}' }, { label: 'Ion', tex: '\\ce{Na+}' }, { label: 'Sulfato', tex: '\\ce{SO4^2-}' },
  ] },
  { id: 'fisica', nombre: 'Física', piezas: [
    { label: 'Velocidad', tex: 'v=\\frac{d}{t}' }, { label: 'Aceleración', tex: 'a=\\frac{\\Delta v}{\\Delta t}' }, { label: '2.ª ley de Newton', tex: 'F=ma' },
    { label: 'Potencial eléctrico', tex: 'V=\\frac{W}{q}' }, { label: 'Ley de Ohm', tex: 'V=IR' }, { label: 'Potencia', tex: 'P=\\frac{W}{t}' },
    { label: 'Energía cinética', tex: 'E_c=\\frac{1}{2}mv^{2}' }, { label: 'Energía potencial', tex: 'E_p=mgh' }, { label: 'Ley de Coulomb', tex: 'F=k\\frac{q_1 q_2}{r^{2}}' },
    { label: 'Trabajo', tex: 'W=Fd\\cos\\theta' },
  ] },
  { id: 'estadistica', nombre: 'Estadística', piezas: [
    { label: 'Media', tex: '\\bar{x}=\\frac{\\sum x_i}{n}' }, { label: 'Desviación', tex: '\\sigma=\\sqrt{\\frac{\\sum (x_i-\\bar{x})^2}{n}}' },
    { label: 'Probabilidad', tex: 'P(A)=\\frac{\\text{casos favorables}}{\\text{casos posibles}}' }, { label: 'Combinaciones', tex: '\\binom{n}{k}' }, { label: 'Factorial', tex: 'n!' },
  ] },
  { id: 'simbolos', nombre: 'Símbolos', piezas: [
    { label: 'Implica', tex: '\\Rightarrow' }, { label: 'Si y solo si', tex: '\\Leftrightarrow' }, { label: 'Flecha', tex: '\\rightarrow' }, { label: 'Por lo tanto', tex: '\\therefore' },
    { label: 'Para todo', tex: '\\forall' }, { label: 'Existe', tex: '\\exists' }, { label: 'Pertenece', tex: '\\in' }, { label: 'Unión', tex: '\\cup' }, { label: 'Intersección', tex: '\\cap' },
    { label: 'Vacío', tex: '\\emptyset' }, { label: 'Y lógico', tex: '\\land' }, { label: 'O lógico', tex: '\\lor' }, { label: 'Negación', tex: '\\neg' }, { label: 'Reales', tex: '\\mathbb{R}' }, { label: 'Naturales', tex: '\\mathbb{N}' },
  ] },
]

export const PRESETS: Record<string, Pieza[]> = {
  Matemática: [
    { label: 'x²', tex: 'x^{2}' }, { label: '√', tex: '\\sqrt{x}' }, { label: 'a/b', tex: '\\frac{a}{b}' }, { label: '±', tex: '\\pm' }, { label: '≤', tex: '\\leq' },
    { label: '≥', tex: '\\geq' }, { label: '≠', tex: '\\neq' }, { label: 'π', tex: '\\pi' }, { label: '∞', tex: '\\infty' }, { label: 'Σ', tex: '\\sum' },
  ],
  Física: [
    { label: 'Δ', tex: '\\Delta ' }, { label: 'θ', tex: '\\theta ' }, { label: 'ω', tex: '\\omega ' }, { label: 'α', tex: '\\alpha ' }, { label: 'λ', tex: '\\lambda ' },
    { label: 'μ', tex: '\\mu ' }, { label: 'ρ', tex: '\\rho ' }, { label: 'Ω', tex: '\\Omega ' }, { label: '→', tex: '\\rightarrow ' }, { label: '·', tex: '\\cdot ' },
    { label: 'm/s²', tex: '\\text{m/s}^{2}' }, { label: 'N', tex: '\\text{N}' }, { label: 'J', tex: '\\text{J}' }, { label: 'W', tex: '\\text{W}' }, { label: 'Hz', tex: '\\text{Hz}' },
  ],
  Química: [
    { label: 'H₂O', tex: '\\ce{H2O}' }, { label: 'CO₂', tex: '\\ce{CO2}' }, { label: '→', tex: '\\ce{->}' }, { label: '⇌', tex: '\\ce{<=>}' }, { label: 'NaCl', tex: '\\ce{NaCl}' },
    { label: 'H⁺', tex: '\\ce{H+}' }, { label: 'OH⁻', tex: '\\ce{OH-}' }, { label: 'mol', tex: '\\text{mol}' },
  ],
  'Letras griegas': ['alpha', 'beta', 'gamma', 'delta', 'theta', 'lambda', 'mu', 'pi', 'sigma', 'omega'].map((n) => ({ label: n, tex: `\\${n} ` })),
}
