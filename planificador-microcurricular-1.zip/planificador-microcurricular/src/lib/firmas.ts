import type { Institucion } from '../types'

export interface Firmante { id: string; cargo: string; nombre: string }

export function firmantesDisponibles(inst: Institucion): Firmante[] {
  return [
    { id: 'docente', cargo: 'Docente', nombre: inst.docente },
    { id: 'comision', cargo: 'Comisión Académica', nombre: inst.comision },
    { id: 'vicerrector', cargo: 'Vicerrector/a', nombre: inst.vicerrector },
    { id: 'rector', cargo: 'Rector/a', nombre: inst.rector },
    { id: 'secretario', cargo: 'Secretario/a', nombre: inst.secretario },
    { id: 'inspector', cargo: 'Inspector/a General', nombre: inst.inspector },
    { id: 'tutor', cargo: 'Tutor/a de Curso', nombre: inst.tutor },
    ...inst.extras.map((e) => ({ id: e.id, cargo: e.cargo, nombre: e.nombre })),
  ]
}

export function firmantesElegidos(inst: Institucion, ids: string[]): Firmante[] {
  const all = firmantesDisponibles(inst)
  return all.filter((f) => ids.includes(f.id))
}

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
export function fechaLarga(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso)
  if (!m) return iso || ''
  return `${Number(m[3])} de ${MESES[Number(m[2]) - 1]} de ${m[1]}`
}
