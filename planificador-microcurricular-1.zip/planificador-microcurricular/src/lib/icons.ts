import { ICON_CATALOG } from '../constants'

export function svgDeIcono(key: string): string {
  const def = ICON_CATALOG.find((i) => i.key === key)
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">${def?.svg ?? ''}</svg>`
}

export function defaultIconUri(key: string): string {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgDeIcono(key))}`
}

/** Icono subido por el docente o, si no hay, el vectorial por defecto. */
export function iconSrc(key: string, iconos: Record<string, string>): string {
  return iconos[key] || defaultIconUri(key)
}
