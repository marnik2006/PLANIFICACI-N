/** Reduce una imagen subida para que ocupe poco espacio en el almacenamiento local. */
export function resizeImage(file: File, maxPx: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('No se pudo leer el archivo'))
    reader.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('Imagen no válida'))
      img.onload = () => {
        const w0 = img.naturalWidth || 256
        const h0 = img.naturalHeight || 256
        const k = Math.min(1, maxPx / Math.max(w0, h0))
        const w = Math.max(1, Math.round(w0 * k))
        const h = Math.max(1, Math.round(h0 * k))
        const canvas = document.createElement('canvas')
        canvas.width = w
        canvas.height = h
        const ctx = canvas.getContext('2d')
        if (!ctx) return reject(new Error('Canvas no disponible'))
        const jpeg = file.type === 'image/jpeg'
        if (jpeg) {
          ctx.fillStyle = '#fff'
          ctx.fillRect(0, 0, w, h)
        }
        ctx.drawImage(img, 0, 0, w, h)
        resolve(canvas.toDataURL(jpeg ? 'image/jpeg' : 'image/png', 0.9))
      }
      img.src = String(reader.result)
    }
    reader.readAsDataURL(file)
  })
}

/** Igual que resizeImage pero devuelve también el tamaño final (para esquemas dentro del documento). */
export async function resizeImageDims(file: File, maxPx: number): Promise<{ src: string; w: number; h: number }> {
  const src = await resizeImage(file, maxPx)
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onerror = () => reject(new Error('Imagen no válida'))
    img.onload = () => resolve({ src, w: img.naturalWidth || 400, h: img.naturalHeight || 300 })
    img.src = src
  })
}

/** Para iconografías: siempre PNG, conserva proporciones y transparencia (no altera el diseño). */
export function resizeIconPng(file: File, maxPx: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('No se pudo leer el archivo'))
    reader.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('Imagen no válida'))
      img.onload = () => {
        const w0 = img.naturalWidth || 256
        const h0 = img.naturalHeight || 256
        const k = Math.min(1, maxPx / Math.max(w0, h0))
        const c = document.createElement('canvas')
        c.width = Math.max(1, Math.round(w0 * k))
        c.height = Math.max(1, Math.round(h0 * k))
        const ctx = c.getContext('2d')
        if (!ctx) return reject(new Error('Canvas no disponible'))
        ctx.drawImage(img, 0, 0, c.width, c.height)
        resolve(c.toDataURL('image/png'))
      }
      img.src = String(reader.result)
    }
    reader.readAsDataURL(file)
  })
}
