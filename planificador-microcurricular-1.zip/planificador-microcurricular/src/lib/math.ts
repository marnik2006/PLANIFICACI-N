/* Motor de fórmulas: LaTeX → SVG con la distribución oficial de MathJax para navegador (se carga solo cuando se necesita). */
import mathjaxUrl from 'mathjax-full/es5/tex-svg-full.js?url'

export interface MathSvg { svg: string; wEx: number; hEx: number; ok: boolean; motor?: boolean; mensaje?: string }

let ready: Promise<any> | null = null

function init(): Promise<any> {
  if (ready) return ready
  const p = new Promise<any>((resolve, reject) => {
    const w = window as any
    if (w.MathJax?.tex2svg) return resolve(w.MathJax)
    w.MathJax = {
      loader: { load: ['[tex]/mhchem', '[tex]/noundefined', '[tex]/ams', '[tex]/newcommand'] },
      tex: { packages: { '[+]': ['mhchem', 'noundefined', 'ams', 'newcommand'] }, inlineMath: [], displayMath: [] },
      svg: { fontCache: 'none' },
      options: { enableMenu: false },
      startup: { typeset: false },
    }
    const s = document.createElement('script')
    s.src = mathjaxUrl
    s.async = true
    s.onload = () => {
      const MJ = (window as any).MathJax
      if (!MJ?.startup?.promise) return reject(new Error('MathJax no se inicializó'))
      MJ.startup.promise.then(() => resolve(MJ), reject)
    }
    s.onerror = () => reject(new Error('No se pudo cargar el motor de fórmulas'))
    document.head.appendChild(s)
  })
  ready = p
  p.catch(() => {
    ready = null // permite reintentar
    document.querySelectorAll(`script[src="${mathjaxUrl}"]`).forEach((n) => n.remove())
    delete (window as any).MathJax
  })
  return p
}

const UNI: Record<string, string> = {
  Δ: '\\Delta ', θ: '\\theta ', ω: '\\omega ', α: '\\alpha ', β: '\\beta ', γ: '\\gamma ', δ: '\\delta ',
  λ: '\\lambda ', μ: '\\mu ', ρ: '\\rho ', σ: '\\sigma ', φ: '\\varphi ', π: '\\pi ', Ω: '\\Omega ',
  Σ: '\\Sigma ', ε: '\\epsilon ', τ: '\\tau ', η: '\\eta ', '·': '\\cdot ', '×': '\\times ', '÷': '\\div ',
  '±': '\\pm ', '≤': '\\le ', '≥': '\\ge ', '≠': '\\ne ', '≈': '\\approx ', '→': '\\rightarrow ',
  '∞': '\\infty ', '√': '\\sqrt ', '°': '^{\\circ}', '²': '^{2}', '³': '^{3}', '⁴': '^{4}',
  '₁': '_{1}', '₂': '_{2}', '₃': '_{3}',
}

/** Acepta LaTeX o texto sencillo (v = d / t, a², Δx) y lo deja listo para MathJax. */
export function normalizeLatex(raw: string): string {
  let s = raw.trim()
  s = s.replace(/^\$\$([\s\S]*)\$\$$/, '$1').replace(/^\$([\s\S]*)\$$/, '$1').replace(/^\\\(([\s\S]*)\\\)$/, '$1').replace(/^\\\[([\s\S]*)\\\]$/, '$1')
  s = s.replace(/[ΔθωαβγδλμφπΩρσΣετη·×÷±≤≥≠≈→∞√°²³⁴₁₂₃]/g, (c) => UNI[c] ?? c)
  s = s.replace(/\\\\\\\\/g, '\\\\') // «\\\\» doble escapado por algunas IA → «\\»
  if (!s.includes('\\')) s = s.replace(/([\w.]+(?:\^\{[^}]*\})?)\s*\/\s*([\w.]+(?:\^\{[^}]*\})?)/g, '\\frac{$1}{$2}')
  return s.trim()
}

const cache = new Map<string, MathSvg>()

export async function latexToSvg(latex: string, display = true): Promise<MathSvg> {
  const key = (display ? 'D' : 'I') + latex
  const hit = cache.get(key)
  if (hit) return hit
  let MJ: any
  try {
    MJ = await init()
  } catch (e) {
    return { svg: '', wEx: 0, hEx: 0, ok: false, motor: true, mensaje: (e as Error).message } // no se guarda en caché
  }
  let res: MathSvg
  try {
    const node: Element = MJ.tex2svg(latex, { display })
    const svgEl = node.querySelector('svg')
    if (!svgEl) throw new Error('sin svg')
    if (!svgEl.getAttribute('xmlns')) svgEl.setAttribute('xmlns', 'http://www.w3.org/2000/svg')
    const err = node.querySelector('[data-mjx-error]')?.getAttribute('data-mjx-error') ?? undefined
    const svg = svgEl.outerHTML
    res = {
      svg,
      wEx: parseFloat(/width="([\d.]+)ex"/.exec(svg)?.[1] ?? '8'),
      hEx: parseFloat(/height="([\d.]+)ex"/.exec(svg)?.[1] ?? '2'),
      ok: !err,
      mensaje: err,
    }
  } catch (e) {
    res = { svg: '', wEx: 0, hEx: 0, ok: false, mensaje: (e as Error).message }
  }
  cache.set(key, res)
  return res
}

/** Convierte las unidades «ex» de MathJax a puntos para pdfmake y fija el color negro. */
export function svgForPdf(svg: string, pt: number): { svg: string; w: number; h: number } {
  const wEx = parseFloat(/width="([\d.]+)ex"/.exec(svg)?.[1] ?? '8')
  const hEx = parseFloat(/height="([\d.]+)ex"/.exec(svg)?.[1] ?? '2')
  const w = wEx * pt
  const h = hEx * pt
  const out = svg
    .replace(/ style="[^"]*"/, '')
    .replace(/width="[\d.]+ex"/, `width="${w.toFixed(2)}"`)
    .replace(/height="[\d.]+ex"/, `height="${h.toFixed(2)}"`)
    .replace(/currentColor/g, '#000000')
  return { svg: out, w, h }
}

/** SVG → PNG (solo navegador). Se usa para Word, que no admite SVG. */
export function rasterizeSvg(svg: string, w: number, h: number, scale = 3): Promise<string> {
  return new Promise((resolve, reject) => {
    const fixed = svg
      .replace(/ style="[^"]*"/, '')
      .replace(/width="[\d.]+(?:ex|px)?"/, `width="${w}"`)
      .replace(/height="[\d.]+(?:ex|px)?"/, `height="${h}"`)
      .replace(/currentColor/g, '#000000')
    const img = new Image()
    img.onload = () => {
      const c = document.createElement('canvas')
      c.width = Math.max(1, Math.round(w * scale))
      c.height = Math.max(1, Math.round(h * scale))
      const ctx = c.getContext('2d')
      if (!ctx) return reject(new Error('canvas'))
      ctx.drawImage(img, 0, 0, c.width, c.height)
      resolve(c.toDataURL('image/png'))
    }
    img.onerror = () => reject(new Error('svg'))
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(fixed)}`
  })
}
