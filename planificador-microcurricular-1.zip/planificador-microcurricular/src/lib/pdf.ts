/* PDF real (vectorial, texto seleccionable) con pdfmake: se descarga completo, sin diálogo de impresión. */
import type { Institucion, LayoutOpts, Plan } from '../types'
import { CREDITO } from '../constants'
import { fechaLarga, firmantesElegidos } from './firmas'
import { svgForPdf } from './math'

const INK = '#14213d'
const mmPt = (v: number) => v * 2.8346

interface St { bold?: boolean; italics?: boolean; color?: string; link?: string; under?: boolean }
interface Run { t?: string; st?: St; br?: boolean; icon?: any; block?: any; kind?: string }
interface Cx { availW: number; fs: number; salto: boolean; noBreak: boolean; h2: number }

const SQ: Record<string, string> = { '🟩': '#2e9e5b', '🟪': '#7a4bc4', '🟦': '#2f6fdb', '⬜': '#d4d4d8', '🟨': '#e0b020', '🟥': '#d04030', '🟧': '#e08030' }
const limpiar = (t: string) =>
  t
    .replace(/→/g, '›').replace(/←/g, '‹').replace(/↔/g, '<>').replace(/⇒/g, '>>')
    .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu, '')

function mapText(t: string, st: St): Run[] {
  return t.split(/(🟩|🟪|🟦|⬜|🟨|🟥|🟧)/u).filter(Boolean).map((p) => (SQ[p] ? { t: '■', st: { ...st, color: SQ[p] } } : { t: limpiar(p), st }))
}

function imgNode(src: string, w: number, h?: number): any {
  if (src.startsWith('data:image/svg+xml')) {
    const svg = decodeURIComponent(src.split(',').slice(1).join(','))
    return { svg, width: w, height: h ?? w }
  }
  return h ? { image: src, width: w, height: h } : { image: src, width: w }
}

function walkInline(node: Node, st: St, out: Run[]) {
  if (node.nodeType === 3) {
    const raw = (node.textContent || '').replace(/\s+/g, ' ')
    if (raw) out.push(...mapText(raw, st))
    return
  }
  if (node.nodeType !== 1) return
  const el = node as Element
  const tag = el.tagName
  if (tag === 'BR') return void out.push({ br: true })
  if (tag === 'IMG') {
    const src = el.getAttribute('src') || ''
    if (el.classList.contains('ico')) {
      const w = Number(el.getAttribute('width')) || 12
      const h = Number(el.getAttribute('height')) || w
      out.push({ icon: imgNode(src, w, h), kind: el.classList.contains('dua-combo') ? 'combo' : undefined })
    }
    else out.push({ block: { image: src, fit: [2000, 320], alignment: 'center', margin: [0, 3, 0, 3], _pct: Number(el.getAttribute('data-escala')) || 45 } })
    return
  }
  if (tag === 'SPAN' && el.classList.contains('fase-t')) {
    const ico = el.querySelector('img.fase-ico')
    const bar = el.querySelector('img.dua-bar')
    const cols: any[] = []
    if (ico) cols.push(imgNode(ico.getAttribute('src') || '', Number(ico.getAttribute('width')) || 18, Number(ico.getAttribute('height')) || 18))
    cols.push({ text: el.querySelector('b')?.textContent ?? '', bold: true, color: INK, width: 'auto', fontSize: 10 })
    if (bar) cols.push({ ...imgNode(bar.getAttribute('src') || '', Number(bar.getAttribute('width')) || 48, Number(bar.getAttribute('height')) || 8), margin: [0, 3, 0, 0] })
    out.push({ block: { columns: cols, columnGap: 5, margin: [0, 3, 0, 3] } })
    return
  }
  if (tag === 'SPAN' && el.classList.contains('eqi')) {
    const sv = el.querySelector('svg')
    if (sv) {
      const r = svgForPdf(sv.outerHTML, 5.6)
      out.push({ icon: { svg: r.svg, width: r.w, height: r.h } })
      return
    }
  }
  let s = st
  if (tag === 'B' || tag === 'STRONG') s = { ...st, bold: true }
  else if (tag === 'I' || tag === 'EM') s = { ...st, italics: true }
  else if (tag === 'U') s = { ...st, under: true }
  else if (tag === 'A') s = { ...st, color: '#2540b8', under: true, link: el.getAttribute('href') || undefined }
  el.childNodes.forEach((c) => walkInline(c, s, out))
}

const toText = (runs: Run[]): any[] =>
  runs.map((r) => {
    const o: any = { text: r.t }
    if (r.st?.bold) o.bold = true
    if (r.st?.italics) o.italics = true
    if (r.st?.color) o.color = r.st.color
    if (r.st?.under) o.decoration = 'underline'
    if (r.st?.link) o.link = r.st.link
    return o
  })

function paragraphs(nodes: Node[], st: St): any[] {
  const runs: Run[] = []
  nodes.forEach((n) => walkInline(n, st, runs))
  const blocks: any[] = []
  let buf: Run[] = []
  const flush = () => {
    const txt = buf.map((r) => r.t ?? '').join('')
    if (txt.trim()) {
      const trimmed = [...buf]
      if (trimmed[0]?.t) trimmed[0] = { ...trimmed[0], t: trimmed[0].t!.replace(/^\s+/, '') }
      blocks.push({ text: toText(trimmed), margin: [0, 0, 0, 2] })
    }
    buf = []
  }
  let i = 0
  while (i < runs.length) {
    const r = runs[i]
    if (r.block) { flush(); blocks.push(r.block); i++ }
    else if (r.br) { flush(); i++ }
    else if (r.icon && r.kind === 'combo') {
      const icons = [r.icon]
      let j = i + 1
      while (j < runs.length && ((runs[j].icon && runs[j].kind === 'combo') || (runs[j].t !== undefined && runs[j].t!.trim() === ''))) {
        if (runs[j].icon) icons.push(runs[j].icon)
        j++
      }
      const hayTxt = buf.some((x) => (x.t ?? '').trim())
      if (hayTxt) {
        const tr = [...buf]
        if (tr[0]?.t) tr[0] = { ...tr[0], t: tr[0].t!.replace(/^\s+/, '') }
        if (tr.length) tr[tr.length - 1] = { ...tr[tr.length - 1], t: (tr[tr.length - 1].t ?? '').replace(/\s+$/, '') }
        blocks.push({ columns: [{ width: 'auto', text: toText(tr) }, ...icons.map((ic) => ({ ...ic, margin: [0, 2, 0, 0] }))], columnGap: 4, margin: [0, 0, 0, 2] })
        buf = []
      } else blocks.push({ columns: icons, columnGap: 3, margin: [0, 0, 0, 2] })
      i = j
    } else if (r.icon) {
      flush()
      const icons = [r.icon]
      let j = i + 1
      while (j < runs.length && (runs[j].icon || (runs[j].t !== undefined && runs[j].t!.trim() === ''))) {
        if (runs[j].icon) icons.push(runs[j].icon)
        j++
      }
      let k = j
      const txt: Run[] = []
      while (k < runs.length && !runs[k].icon && !runs[k].br && !runs[k].block) txt.push(runs[k++])
      const hasTxt = txt.some((x) => (x.t ?? '').trim())
      if (hasTxt && icons.length === 1) blocks.push({ columns: [icons[0], { width: '*', text: toText(txt) }], columnGap: 4, margin: [0, 0, 0, 2] })
      else {
        blocks.push({ columns: icons, columnGap: 3, margin: [0, 0, 0, 2] })
        if (hasTxt) blocks.push({ text: toText(txt), margin: [0, 0, 0, 2] })
      }
      i = k
    } else { buf.push(r); i++ }
  }
  flush()
  return blocks
}

const BLOCK = new Set(['P', 'DIV', 'UL', 'OL', 'TABLE', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'BLOCKQUOTE', 'HR', 'PRE', 'FIGURE', 'SECTION', 'ARTICLE', 'LI'])

function blocksFrom(parent: Node, st: St, cx: Cx): any[] {
  const out: any[] = []
  let buf: Node[] = []
  const flush = () => { if (buf.length) { out.push(...paragraphs(buf, st)); buf = [] } }
  parent.childNodes.forEach((n) => {
    if (n.nodeType === 1 && BLOCK.has((n as Element).tagName)) { flush(); out.push(...blockEl(n as Element, st, cx)) }
    else buf.push(n)
  })
  flush()
  return out
}

const heading = (el: Element, st: St, style: string) => {
  const runs: Run[] = []
  el.childNodes.forEach((c) => walkInline(c, { ...st, bold: true }, runs))
  return { text: toText(runs), style }
}

function blockEl(el: Element, st: St, cx: Cx): any[] {
  switch (el.tagName) {
    case 'H1': return [heading(el, st, 'h1')]
    case 'H2': {
      const h: any = heading(el, st, 'h2')
      if (cx.salto && cx.h2++ > 0) h.pageBreak = 'before'
      return [h]
    }
    case 'H3': case 'H4': case 'H5': case 'H6': return [heading(el, st, 'h3')]
    case 'P': return paragraphs(Array.from(el.childNodes), st)
    case 'UL': case 'OL': {
      const items = Array.from(el.children).filter((c) => c.tagName === 'LI').map((li) => {
        const b = blocksFrom(li, st, cx)
        return b.length === 1 ? b[0] : { stack: b.length ? b : [{ text: '' }] }
      })
      return [{ [el.tagName === 'UL' ? 'ul' : 'ol']: items, margin: [0, 2, 0, 4] }]
    }
    case 'HR': return [{ canvas: [{ type: 'line', x1: 0, y1: 0, x2: cx.availW, y2: 0, lineWidth: 0.7, lineColor: '#9ca3af' }], margin: [0, 4, 0, 4] }]
    case 'PRE': return [{ text: el.textContent || '', fontSize: cx.fs - 1, color: '#374151', margin: [0, 2, 0, 4] }]
    case 'BLOCKQUOTE': {
      const b = blocksFrom(el, st, cx)
      return [{ table: { widths: ['*'], body: [[{ stack: b.length ? b : [{ text: '' }], fillColor: '#f3f4f6' }]] }, layout: { hLineWidth: () => 0, vLineWidth: (i: number) => (i === 0 ? 3 : 0), vLineColor: () => '#6b7280' }, margin: [0, 3, 0, 5] }]
    }
    case 'TABLE': return [tableFrom(el as HTMLTableElement, st, cx)]
    case 'DIV': {
      if (el.classList.contains('eq')) {
        const svg = el.querySelector('svg')
        if (!svg) return []
        const esc = (Number(el.getAttribute('data-escala')) || 100) / 100
        const r = svgForPdf(svg.outerHTML, cx.fs * 0.6 * esc)
        const w = Math.min(r.w, cx.availW * 0.9)
        return [{ columns: [{ width: '*', text: '' }, { svg: r.svg, width: w, height: r.h * (w / r.w) }, { width: '*', text: '' }], margin: [0, 4, 0, 2] }]
      }
      if (el.classList.contains('cap')) return [{ text: el.textContent || '', italics: true, alignment: 'center', fontSize: cx.fs - 1, color: '#444', margin: [0, 0, 0, 4] }]
      return blocksFrom(el, st, cx)
    }
    default: return blocksFrom(el, st, cx)
  }
}

/** Reduce imágenes y fórmulas que excedan el ancho disponible de su celda. */
function ajustar(node: any, w: number): void {
  if (!node || typeof node !== 'object') return
  if (Array.isArray(node)) return node.forEach((n) => ajustar(n, w))
  if (node.image && node.fit) {
    const pct = node._pct ? node._pct / 100 : 1
    node.fit = [Math.min(node.fit[0], w * pct), node.fit[1]]
    delete node._pct
  }
  if (node.svg && node.width && node.width > w) {
    if (node.height) node.height = node.height * (w / node.width)
    node.width = w
  }
  for (const k of ['stack', 'columns', 'ul', 'ol']) if (node[k]) ajustar(node[k], w)
}

function tableFrom(tbl: HTMLTableElement, st: St, cx: Cx): any {
  const trs = Array.from(tbl.querySelectorAll('tr')).filter((tr) => tr.closest('table') === tbl)
  const headTrs = trs.filter((tr) => tr.parentElement?.tagName === 'THEAD')
  let headerRows = headTrs.length
  if (!headerRows && trs[0] && Array.from(trs[0].children).every((c) => c.tagName === 'TH')) headerRows = 1
  const ncols = Math.max(1, ...trs.map((tr) => Array.from(tr.children).reduce((a, c) => a + ((c as HTMLTableCellElement).colSpan || 1), 0)))
  const occ: boolean[][] = trs.map(() => Array(ncols).fill(false))
  const body: any[][] = []
  const refs: { content: any; ci: number; span: number }[] = []
  const lens = Array(ncols).fill(0)
  const cnt = Array(ncols).fill(0)
  trs.forEach((tr, ri) => {
    const row: any[] = Array(ncols).fill(null)
    let ci = 0
    Array.from(tr.children).forEach((cell) => {
      while (ci < ncols && occ[ri][ci]) ci++
      if (ci >= ncols) return
      const c = cell as HTMLTableCellElement
      const isHead = ri < headerRows || c.tagName === 'TH'
      const cs = isHead ? { ...st, bold: true, color: '#ffffff' } : st
      const b = blocksFrom(c, cs, cx)
      const content: any = b.length === 1 && b[0].text !== undefined && !b[0].columns ? { ...b[0], margin: [0, 0, 0, 0] } : { stack: b.length ? b : [{ text: '' }] }
      const colSpan = c.colSpan || 1
      const rowSpan = c.rowSpan || 1
      if (colSpan > 1) content.colSpan = colSpan
      if (rowSpan > 1) content.rowSpan = rowSpan
      row[ci] = content
      refs.push({ content, ci, span: colSpan })
      for (let dy = 0; dy < rowSpan; dy++) for (let dx = 0; dx < colSpan; dx++) if (ri + dy < trs.length && ci + dx < ncols) occ[ri + dy][ci + dx] = true
      if (colSpan === 1) { lens[ci] += Math.min((c.textContent || '').trim().length, 500); cnt[ci]++ }
      ci += colSpan
    })
    body.push(row.map((x) => x ?? { text: '' }))
  })
  const wts = lens.map((l, i) => Math.min(24, Math.max(3.5, Math.sqrt(cnt[i] ? l / cnt[i] : 4))))
  const sum = wts.reduce((a, b) => a + b, 0)
  let widths = wts.map((w) => Math.max(34, (cx.availW * w) / sum))
  const tot = widths.reduce((a, b) => a + b, 0)
  widths = widths.map((w) => Math.floor((w * (cx.availW - 10)) / tot))
  refs.forEach((r) => ajustar(r.content, widths.slice(r.ci, r.ci + r.span).reduce((a, b) => a + b, 0) - 12))
  return {
    table: { headerRows, widths, body, dontBreakRows: cx.noBreak },
    layout: {
      hLineWidth: () => 0.6, vLineWidth: () => 0.6, hLineColor: () => '#6b7280', vLineColor: () => '#6b7280',
      paddingLeft: () => 4, paddingRight: () => 4, paddingTop: () => 3, paddingBottom: () => 3,
      fillColor: (ri: number) => (ri < headerRows ? INK : ri % 2 === 0 ? '#f5f6fa' : null),
    },
    margin: [0, 3, 0, 6],
  }
}

function legalizacion(inst: Institucion, plan: Plan, cx: Cx): any[] {
  const f = firmantesElegidos(inst, plan.firmas)
  if (!f.length) return []
  const fecha = fechaLarga(plan.fechaDocumento)
  const h = (t: string) => ({ text: t, bold: true, color: '#ffffff' })
  const w = cx.availW - 10
  return [{
    unbreakable: true,
    stack: [
      { text: 'LEGALIZACIÓN', style: 'h2' },
      {
        table: {
          headerRows: 1, dontBreakRows: true, widths: [w * 0.24, w * 0.26, w * 0.22, w * 0.16, w * 0.12],
          body: [[h('Firma'), h('Nombre'), h('Cargo'), h('Fecha'), h('Sello')], ...f.map((s) => [{ text: '', margin: [0, 24, 0, 0] }, s.nombre || '—', s.cargo, fecha, ''])],
        },
        layout: { hLineWidth: () => 0.6, vLineWidth: () => 0.6, hLineColor: () => '#6b7280', vLineColor: () => '#6b7280', fillColor: (ri: number) => (ri === 0 ? INK : null) },
      },
    ],
  }]
}

export function pdfDefinition(o: { inst: Institucion; plan: Plan; bodyHtml: string; layout: LayoutOpts; title: string }): any {
  const { inst, plan, layout: L } = o
  const doc = new DOMParser().parseFromString(`<body>${o.bodyHtml}</body>`, 'text/html')
  const [a, b] = L.papel === 'A4' ? [595.28, 841.89] : [612, 792]
  const pageW = L.orientacion === 'landscape' ? b : a
  const mg = mmPt(L.margenMm)
  const availW = pageW - 2 * mg
  const cx: Cx = { availW, fs: L.fuentePt, salto: L.saltoPorSeccion, noBreak: L.evitarCortarFilas, h2: 0 }
  const cuerpo = blocksFrom(doc.body, {}, cx)
  ajustar(cuerpo, availW)
  const content = [...cuerpo, ...legalizacion(inst, plan, cx)]
  const line = (y = 0, w = 1) => ({ canvas: [{ type: 'line', x1: 0, y1: y, x2: availW, y2: y, lineWidth: w, lineColor: INK }] })

  const logo = inst.logo ? { image: inst.logo, fit: [50, 46], width: 50 } : { text: '', width: 50 }
  const header = () => ({
    margin: [mg, 14, mg, 0],
    stack: [
      {
        columns: [
          { ...logo, width: 50 },
          { width: '*', stack: [
            ...(inst.mostrarMinisterio ? [{ text: 'REPÚBLICA DEL ECUADOR · MINISTERIO DE EDUCACIÓN', fontSize: 7, alignment: 'center', color: '#444', characterSpacing: 1 }] : []),
            { text: (inst.nombre || 'NOMBRE DE LA UNIDAD EDUCATIVA').toUpperCase(), fontSize: 15, bold: true, alignment: 'center', color: INK },
            ...(inst.linea ? [{ text: inst.linea, fontSize: 7.5, alignment: 'center', color: '#444' }] : []),
          ] },
          { text: '', width: 50 },
        ],
      },
      line(4, 1.5),
    ],
  })
  const quien = [inst.docente ? `Docente: ${inst.docente}` : '', inst.tutor ? `Tutor/a: ${inst.tutor}` : ''].filter(Boolean).join('   ·   ')
  const footer = (page: number, count: number) => ({
    margin: [mg, 0, mg, 10],
    stack: [
      line(0, 0.8),
      { columns: [
        { text: quien, fontSize: 8, width: '*' },
        { text: `${inst.nombre}${plan.anioLectivo ? ' · ' + plan.anioLectivo : ''}`, fontSize: 8, alignment: 'center', width: 'auto' },
        { text: `Pág. ${page} de ${count}`, fontSize: 8, alignment: 'right', width: '*' },
      ], margin: [0, 3, 0, 0] },
      ...(L.mostrarCredito ? [{ text: `Sistema elaborado por: ${CREDITO}`, fontSize: 6.5, color: '#777', alignment: 'right' }] : []),
    ],
  })
  return {
    info: { title: o.title, author: inst.docente, creator: 'Planificador Microcurricular — ' + CREDITO },
    pageSize: L.papel === 'A4' ? 'A4' : 'LETTER',
    pageOrientation: L.orientacion,
    pageMargins: [mg, mg + 54, mg, mg + 34],
    header, footer, content,
    defaultStyle: { fontSize: L.fuentePt, lineHeight: 1.15 },
    styles: {
      h1: { fontSize: L.fuentePt + 6, bold: true, color: INK, alignment: 'center', margin: [0, 4, 0, 8] },
      h2: { fontSize: L.fuentePt + 2.5, bold: true, color: INK, margin: [0, 12, 0, 5] },
      h3: { fontSize: L.fuentePt + 1, bold: true, color: INK, margin: [0, 8, 0, 3] },
    },
  }
}

export async function createPdfBlob(def: any): Promise<Blob> {
  // @ts-ignore módulos UMD sin tipos de ESM
  const pm: any = await import('pdfmake/build/pdfmake')
  // @ts-ignore
  const vf: any = await import('pdfmake/build/vfs_fonts')
  const pdfMake = pm.default ?? pm
  const vfs = vf.default ?? vf
  if (typeof pdfMake.addVirtualFileSystem === 'function') pdfMake.addVirtualFileSystem(vfs)
  else pdfMake.vfs = vfs
  return new Promise<Blob>((resolve, reject) => {
    try {
      pdfMake.createPdf(def).getBlob((b: Blob) => resolve(b))
    } catch (e) {
      reject(e)
    }
  })
}
