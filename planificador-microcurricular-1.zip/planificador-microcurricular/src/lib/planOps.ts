import type { AppState, Criterio, Curriculo, Destreza, Plan, PlanGuardado } from '../types'
import { bestIndicador, suggestTags } from './curriculum'
import { defaultPlan } from '../defaults'
import { uid } from './util'

export const isSel = (p: Plan, criterioCodigo: string, codigo: string) =>
  p.destrezas.some((d) => d.codigo === codigo && d.criterioCodigo === criterioCodigo)

export function addDestreza(
  plan: Plan,
  cur: Curriculo,
  criterio: Criterio,
  d: Destreza,
  opts?: { objetivo?: string; indicador?: string; query?: string },
): Plan {
  let next = plan
  if (!isSel(plan, criterio.codigo, d.codigo)) {
    const ind = opts?.indicador ?? bestIndicador(criterio, d, opts?.query)?.codigo ?? ''
    const tags = suggestTags(`${d.descripcion} ${criterio.descripcion}`, cur.asignatura)
    next = {
      ...plan,
      destrezas: [
        ...plan.destrezas,
        {
          codigo: d.codigo,
          criterioCodigo: criterio.codigo,
          indicadorCodigo: ind,
          periodos: 2,
          competencias: tags.competencias,
          inserciones: tags.inserciones,
        },
      ],
    }
  }
  if (!next.criterios.includes(criterio.codigo)) next = { ...next, criterios: [...next.criterios, criterio.codigo] }
  if (opts?.objetivo && !next.objetivos.includes(opts.objetivo)) next = { ...next, objetivos: [...next.objetivos, opts.objetivo] }
  return next
}

export function removeDestreza(plan: Plan, criterioCodigo: string, codigo: string): Plan {
  const destrezas = plan.destrezas.filter((d) => !(d.codigo === codigo && d.criterioCodigo === criterioCodigo))
  return { ...plan, destrezas, criterios: [...new Set(destrezas.map((d) => d.criterioCodigo))] }
}

export function clearSelection(plan: Plan): Plan {
  return { ...plan, destrezas: [], criterios: [], objetivos: [], cronograma: [] }
}

export function saveToLibrary(
  s: AppState,
  nombre: string,
  asNew: boolean,
): { state: AppState; id: string } {
  const now = new Date().toISOString()
  const cur = s.curriculos.find((c) => c.id === s.plan.curriculoId)
  const asignatura = cur ? `${cur.asignatura}${cur.nivel ? ' · ' + cur.nivel : ''}` : ''
  const existing = !asNew && s.planActualId ? s.guardados.find((g) => g.id === s.planActualId) : undefined
  if (existing) {
    const upd: PlanGuardado = {
      ...existing,
      nombre,
      asignatura,
      trimestre: s.plan.trimestre,
      parcial: s.plan.parcial,
      actualizado: now,
      plan: s.plan,
    }
    return {
      id: existing.id,
      state: { ...s, guardados: s.guardados.map((g) => (g.id === existing.id ? upd : g)) },
    }
  }
  const id = uid()
  const nuevo: PlanGuardado = {
    id,
    nombre,
    asignatura,
    trimestre: s.plan.trimestre,
    parcial: s.plan.parcial,
    creado: now,
    actualizado: now,
    plan: s.plan,
  }
  return { id, state: { ...s, guardados: [nuevo, ...s.guardados], planActualId: id } }
}

/** Nueva planificación conservando currículo y datos comunes del curso. */
export function newPlan(s: AppState): AppState {
  const p = s.plan
  const d = defaultPlan()
  return {
    ...s,
    planActualId: null,
    plan: {
      ...d,
      curriculoId: p.curriculoId,
      grado: p.grado,
      paralelos: p.paralelos,
      jornada: p.jornada,
      anioLectivo: p.anioLectivo,
      periodosSemana: p.periodosSemana,
      minutosPeriodo: p.minutosPeriodo,
      layout: p.layout,
      trimestre: p.trimestre,
      parcial: p.parcial,
    },
  }
}
