import type { Curriculo, Institucion, Plan, TipoPlan } from '../types'
import { COLUMNAS_DEFAULT, COMPETENCIAS, ESTRATEGIAS, EXTENSIONES, ICON_CATALOG, INSERCIONES, METODOLOGIAS, TIPOS, metodologiaDe } from '../constants'
import { resumen } from './schedule'
import { bitsATriple, sugerirDua } from './dua'

const SEP = '==========================================================='
const h = (t: string) => `\n${SEP}\n${t}\n${SEP}\n`
const tokenDe = (key: string) => `{{${key}}}`
const nombreDe = (key: string) => ICON_CATALOG.find((i) => i.key === key)?.nombre ?? key

function rolObjetivo(tipo: TipoPlan): string {
  const doc = TIPOS.find((t) => t.id === tipo)?.nombre ?? 'PLANIFICACIÓN MICROCURRICULAR'
  return `ROL:
Actúa como un especialista en diseño curricular del Ministerio de Educación del Ecuador, experto en planificación curricular, ciclo de aprendizaje, metodologías activas y Diseño Universal para el Aprendizaje (DUA 3.0).

OBJETIVO:
A partir de los datos curriculares en formato JSON que se incluyen más abajo (asignatura, nivel, objetivos, criterios de evaluación, destrezas con criterios de desempeño e indicadores de evaluación), debes generar el documento: ${doc.toUpperCase()}, completo, listo para exportar a PDF y Word, con la estructura y reglas descritas en este texto.`
}

function bloqueJson(plan: Plan, cur?: Curriculo): string {
  if (!cur || !plan.destrezas.length) {
    return '(Aún no se han seleccionado destrezas. El docente pegará aquí el bloque JSON curricular o indicará las destrezas a desarrollar.)'
  }
  const selCrit = cur.criterios.filter((c) => plan.criterios.includes(c.codigo))
  const json = {
    asignatura: cur.asignatura,
    nivel: cur.nivel,
    objetivos: plan.objetivos.length ? cur.objetivos.filter((o) => plan.objetivos.includes(o.codigo)) : cur.objetivos,
    criterios: selCrit.map((c) => {
      const indSel = new Set(plan.destrezas.filter((d) => d.criterioCodigo === c.codigo).map((d) => d.indicadorCodigo))
      const inds = c.indicadores.filter((i) => indSel.has(i.codigo))
      return {
        codigo: c.codigo,
        descripcion: c.descripcion,
        destrezas_con_criterios_de_desempeno: c.destrezas.filter((d) =>
          plan.destrezas.some((s) => s.codigo === d.codigo && s.criterioCodigo === c.codigo),
        ),
        indicadores_evaluacion: inds.length ? inds : c.indicadores,
      }
    }),
  }
  const nota = plan.objetivos.length
    ? ''
    : '(El docente no escogió objetivos específicos: selecciona de la lista los pertinentes para las destrezas indicadas y transcríbelos en la sección de objetivos.)\n'
  return nota + '```json\n' + JSON.stringify(json, null, 2) + '\n```'
}

function fasesTexto(plan: Plan): string {
  const m = metodologiaDe(plan.metodologia)
  return m.fases.map((f, i) => `  ${i + 1}. ${f.nombre}: ${f.desc}`).join('\n')
}

function bloqueMetodologia(plan: Plan): string {
  if (plan.metodologia === 'ia') {
    const lista = METODOLOGIAS.filter((m) => m.id !== 'ia')
      .map((m) => `  - ${m.nombre}: ${m.resumen}`)
      .join('\n')
    return `- METODOLOGÍA DE APRENDIZAJE: elígela TÚ. Para cada destreza e indicador, escoge la más pertinente entre las metodologías oficiales y activas usadas en el sistema educativo ecuatoriano:\n${lista}\n  Declara la metodología elegida (y una línea de justificación) en el encabezado de cada destreza y organiza TODAS las orientaciones por las fases de la metodología elegida, en su orden.`
  }
  const m = metodologiaDe(plan.metodologia)
  return `- METODOLOGÍA DE APRENDIZAJE: ${m.nombre} (${m.resumen}). Fases en este orden:\n${fasesTexto(plan)}\n  ${m.detalle}`
}

function bloqueActividades(plan: Plan): string {
  const L: string[] = []
  const conActs = plan.actividades.filter((f) => f.items.some((i) => i.texto.trim()))
  if (conActs.length) {
    L.push(h('ACTIVIDADES BASE DEFINIDAS POR EL DOCENTE (por fase)'))
    L.push('Úsalas como punto de partida: conserva su intención, mejóralas con un ejemplo concreto, complétalas hasta cumplir el nivel de extensión y respeta el orden de las fases. Puedes agregar actividades nuevas si hacen falta. Si una actividad trae [DUA definido: …], conserva exactamente esa secuencia de 3 símbolos al cerrarla (el docente la eligió); en las demás, decide tú.')
    conActs.forEach((f) => {
      L.push(`Fase «${f.fase}»:`)
      const rol = metodologiaDe(plan.metodologia).fases.find((x) => x.nombre === f.fase)?.rol ?? null
      f.items.filter((i) => i.texto.trim()).forEach((i, k) => L.push(`  ${k + 1}. ${i.texto.trim()}  [DUA definido: ${bitsATriple(i.dua ?? sugerirDua(i.texto, rol))}]`))
    })
  }
  if (plan.visuales.length) {
    L.push(h('MATERIAL VISUAL DEFINIDO POR EL DOCENTE (imágenes, esquemas y fórmulas)'))
    L.push('El sistema reemplaza cada marcador por la imagen o la fórmula. Escribe el marcador EXACTAMENTE como aparece (con llaves dobles), dentro de la fase y la actividad indicadas (dentro de la celda de orientaciones metodológicas), en una línea propia. No lo modifiques, no lo describas y no escribas la fórmula por tu cuenta: ya está dibujada.')
    plan.visuales.forEach((v) => {
      const sem = v.semana === 'todos' ? 'todas las semanas' : (plan.cronograma[Number(v.semana)]?.semana ?? `semana ${v.semana}`)
      const act = v.actividad < 0 ? 'toda la fase' : `actividad ${v.actividad + 1}`
      const fase = v.fase ? `fase «${v.fase}»` : 'la fase donde mejor encaje'
      if (v.tipo === 'formula') L.push(`- ${tokenDe('eq:' + v.id)} Fórmula (LaTeX: ${v.latex}) ${v.pie ? `«${v.pie}»` : ''} → ${fase}; ${act}; aparece en: ${sem}.`)
      else L.push(`- ${tokenDe('fig:' + v.id)} Imagen o esquema ${v.pie ? `«${v.pie}»` : ''} → ${fase}; ${act}; aparece en: ${sem}.`)
    })
    L.push('Las explicaciones de las actividades deben mencionar la fórmula o el esquema cuando corresponda (por ejemplo, «a partir de la fórmula mostrada»).')
  }
  return L.join('\n')
}

function columnasTabla(plan: Plan): string {
  const cols = (plan.columnas?.length ? plan.columnas : COLUMNAS_DEFAULT).filter((c) => c.on || c.id === 'orientaciones')
  const desc: Record<string, string> = {
    destreza: 'Destreza: código + descripción textual (reescribe el verbo en infinitivo si hace falta, agregando un rasgo de calidad: "con exactitud", "con argumentación", "con orden y limpieza", etc.). Debajo del texto coloca los marcadores de competencias e inserciones de esa destreza.',
    indicador: 'Indicador: código + descripción (el asignado en este documento).',
    orientaciones: 'Orientaciones metodológicas: encabezado (Unidad/Bloque, Tema, tiempo estimado en períodos y minutos) y luego las actividades organizadas por las fases de la metodología elegida, cada una con su código (f.n) y su cierre DUA.',
    recursos: 'Recursos: materiales, plataformas TIC, fichas, guías (mínimo 3 por destreza).',
    evaluacion: 'Evaluación: técnica + instrumento + criterio de verificación (4-5 líneas).',
    criterio: 'Criterio de evaluación: código + descripción tomados del JSON.',
    tiempo: 'Tiempo: períodos y minutos de la destreza (usa los valores entregados).',
  }
  const head = `| ${cols.map((c) => c.label).join(' | ')} |`
  const det = cols.map((c) => `- ${c.label}: ${desc[c.id] ?? 'contenido pertinente a la columna.'}`).join('\n')
  return `Columnas fijas, en este orden: ${head}\nPor cada destreza seleccionada genera una fila con:\n${det}`
}

/* ---------- estructuras por tipo de documento ---------- */

function estructura(tipo: TipoPlan, plan: Plan): string {
  const tabla = columnasTabla(plan)
  const sinLegal = 'La LEGALIZACIÓN (firmas) NO la incluyas: el sistema la agrega al final con los firmantes que elija el docente.'
  switch (tipo) {
    case 'pud':
      return `A. DATOS INFORMATIVOS
Tabla con: Institución | Docente | Asignatura | Grado/Curso | Paralelos | Año lectivo | Unidad | Tema | Fecha inicio | Fecha finalización | Total de períodos.

B. OBJETIVO DE LA UNIDAD Y OBJETIVOS DE APRENDIZAJE
Redacta un objetivo específico de la unidad (una oración en infinitivo, medible) y transcribe los objetivos del JSON (código + descripción).

C. CRITERIOS DE EVALUACIÓN
Transcribe el/los criterio(s) (código + descripción).

D. INSERCIONES CURRICULARES / EJES TRANSVERSALES
Señala las pertinentes con sus marcadores y una frase de cómo se integran (Educación cívica, ética e integridad; Educación socioemocional; Educación para la seguridad vial y movilidad sostenible; Educación para el desarrollo sostenible; Educación financiera; Educación para la Seguridad Integral).

E. TABLA DE PLANIFICACIÓN DE LA UNIDAD
${tabla}

F. CRONOGRAMA SEMANAL
Tabla: Semana | Fechas | Períodos | Fase dominante | Contenido (usa el cronograma entregado).

G. ADAPTACIONES CURRICULARES PARA ESTUDIANTES CON NEE
Subtabla NEE G1 y G2: Estudiante | Grado | Estrategia específica. Subtabla NEE G3: Estudiante | DCD | Indicador | Estrategia | Recursos | Evaluación. Si no hay casos escribe "No se registran casos" en todas las columnas.

${sinLegal}`
    case 'pca':
      return `A. DATOS INFORMATIVOS
Tabla con: Institución | Docente | Asignatura | Área/Nivel | Grado/Curso | Año lectivo | Total de semanas | Períodos semanales | Número de unidades (${plan.numUnidades}).

B. OBJETIVOS DEL ÁREA/ASIGNATURA Y DEL SUBNIVEL
Transcribe los objetivos del JSON (código + descripción).

C. ORGANIZACIÓN ANUAL POR UNIDADES
Distribuye las destrezas seleccionadas en ${plan.numUnidades} unidades coherentes (agrupa por afinidad temática y progresión). Tabla: N.º | Título de la unidad | Objetivos de aprendizaje (códigos) | Destrezas con criterio de desempeño (código y texto abreviado) | Criterios e indicadores de evaluación (códigos) | Inserciones curriculares (marcadores) | Metodología | Recursos | Evaluación | Semanas | Períodos. Los períodos suman el total anual entregado.

D. RESUMEN DE TIEMPOS
Total de semanas, períodos por unidad y total anual, semanas de evaluación y de imprevistos.

E. ADAPTACIONES CURRICULARES GENERALES PARA NEE
Estrategias generales por grado (G1, G2, G3).

${sinLegal}`
    case 'clase':
      return `A. DATOS INFORMATIVOS
Tabla con: Institución | Docente | Asignatura | Grado/Curso | Paralelos | Fecha de la clase | Duración (períodos y minutos) | Tema de la clase.

B. DESTREZA E INDICADOR
Código + descripción de la destreza y del indicador asignado.

C. OBJETIVO DE LA CLASE
Una oración en infinitivo, medible y coherente con la destreza.

D. D.U.A. 3.0 — BREVE
Tres líneas: 🟩 Compromiso, 🟪 Representación, 🟦 Acción y expresión.

E. DESARROLLO DE LA CLASE POR FASES
Tabla: FASE | TIEMPO (min) | ACTIVIDADES (con códigos (f.n) y cierre DUA) | RECURSOS | EVALUACIÓN FORMATIVA. Una fila por fase de la metodología. La suma de los tiempos es exactamente la duración total.

F. EVALUACIÓN
Técnica + instrumento + criterios, con 2 o 3 preguntas o ejercicios de ejemplo (con respuesta).

G. TAREA O REFUERZO
Actividad breve y autónoma para casa.

H. ADAPTACIONES NEE
Una línea por grado si hay casos; si no, "No se registran casos".

${sinLegal}`
    case 'recuperacion':
      return `A. DATOS INFORMATIVOS
Tabla con: Institución | Docente | Asignatura | Grado/Curso | Paralelos | Año lectivo | Período del refuerzo | Número de sesiones.

B. DIAGNÓSTICO DE LOS ESTUDIANTES
Tabla: Estudiante | Promedio | Destreza(s) con dificultad | Causa probable | Prioridad (usa los datos entregados abajo; si falta algo, propónlo como hipótesis a verificar).

C. DESTREZAS IMPRESCINDIBLES A REFORZAR
Destrezas del JSON con su indicador, ordenadas por prioridad.

D. PLAN DE REFUERZO POR SESIONES
Tabla: Sesión | Semana/fecha | Destreza | Actividades por fases de la metodología (con códigos (f.n) y cierre DUA) | Recursos | Evaluación formativa.

E. EVALUACIÓN DE LA RECUPERACIÓN
Instrumento, criterios y meta: superar el promedio de 7/10 en la destreza reforzada; incluye una evaluación diagnóstica de entrada y otra de cierre.

F. COMPROMISOS Y SEGUIMIENTO
Compromisos del docente, del estudiante y del representante legal; comunicación con el DECE cuando corresponda; registro de avances.

G. ADAPTACIONES NEE
Si hay casos, estrategias específicas; si no, "No se registran casos".

${sinLegal}`
    case 'cnc':
      return `A. DATOS INFORMATIVOS
Tabla con: Institución | Docente | Asignatura | Área/Nivel | Grado/Curso | Paralelos | Año lectivo | Unidad/Experiencia | Fecha inicio | Fecha finalización | Total de períodos.

B. COMPETENCIAS CLAVE
Competencias a desarrollar, derivadas de las destrezas e indicadores entregados. Si el JSON no trae competencias, propónlas y márcalas con [propuesta] para que el docente las verifique.

C. SABERES
Saberes conceptuales, procedimentales y actitudinales que se movilizan (derívalos de las destrezas).

D. EXPERIENCIA DE APRENDIZAJE
Situación significativa o reto, producto o evidencia esperada y actividades organizadas por las fases de la metodología elegida (códigos (f.n) y cierre DUA).
${tabla}

E. EVALUACIÓN
Criterios, evidencias, técnicas e instrumentos (incluye una rúbrica analítica breve).

F. INSERCIONES CURRICULARES
Con marcadores y una frase de integración.

G. ADAPTACIONES NEE
Si hay casos, estrategias específicas; si no, "No se registran casos".

Si algún dato propio del currículo por competencias no figura en el JSON, indícalo entre corchetes como [por confirmar] en lugar de inventarlo.

${sinLegal}`
    case 'micro':
    default:
      return `A. ENCABEZADO — DATOS INFORMATIVOS
Tabla con: Asignatura | Área/Nivel | Grado/Curso | Paralelos | Docente | Jornada | Año lectivo | Fecha inicio | Fecha finalización.

B. COMPETENCIAS
Marca (con los marcadores de icono) las competencias que se trabajan: Comunicacionales, Matemáticas/Disciplinares, Digitales, Socioemocionales. Usa los marcadores indicados arriba, por ejemplo ${tokenDe(COMPETENCIAS[0].key)}.

C. INSERCIONES CURRICULARES
Señala los ejes transversales/insertos institucionales pertinentes (Educación cívica, ética e integridad; Educación socioemocional; Educación para la seguridad vial y movilidad sostenible; Educación para el desarrollo sostenible; Educación financiera; Educación para la Seguridad Integral) según el contenido de la destreza. Usa los marcadores indicados arriba, por ejemplo ${tokenDe(INSERCIONES[0].key)}.

D. D.U.A. 3.0 — DESCRIPCIÓN GENERAL
Redacta tres párrafos fijos que expliquen cómo se aplicará cada principio a lo largo de la unidad:
- 🟩 COMPROMISO: motivación, relevancia, autorregulación.
- 🟪 REPRESENTACIÓN: múltiples formas de presentar la información.
- 🟦 ACCIÓN Y EXPRESIÓN: múltiples formas de que el estudiante demuestre el aprendizaje.

E. OBJETIVOS DE APRENDIZAJE
Transcribe el/los objetivo(s) (código + descripción) tomados del JSON.

F. ESTÁNDARES DE APRENDIZAJE
Transcribe el/los criterio(s) de evaluación (código + descripción) tomados del JSON.

F.1 CRONOGRAMA SEMANAL
Tabla: Semana | Fechas | Períodos | Fase dominante | Contenido (usa el cronograma entregado).

G. TABLA DE PLANIFICACIÓN MICROCURRICULAR (núcleo del documento)
${tabla}

H. ADAPTACIONES PARA ESTUDIANTES CON NEE
Dos subtablas:
- NEE G1 y G2: Estudiante | Grado de NEE | Estrategia específica.
- NEE G3: Estudiante | DCD | Indicador | Estrategia | Recursos | Evaluación.
Si no hay casos, escribe "No se registran casos" en todas las columnas.

${sinLegal}`
  }
}

/* ---------- reglas comunes ---------- */

function reglasFases(plan: Plan): string {
  const m = metodologiaDe(plan.metodologia)
  const lista =
    plan.metodologia === 'ia'
      ? 'Usa las fases de la metodología que elijas, en su orden.'
      : `Organiza cada orientación en estas fases, en este orden:\n${fasesTexto(plan)}`
  const equiv =
    plan.metodologia === 'erca' || plan.metodologia === 'acc'
      ? '\nEquivalencia ERCA ↔ ACC: Anticipación = Experiencia; Construcción = Reflexión + Conceptualización; Consolidación = Aplicación. Respeta el número de fases de la metodología elegida; no mezcles ambos esquemas en la misma tabla.'
      : ''
  return `${lista}${equiv}
- Cada fase debe cumplir su propósito: la primera conecta con la vida cotidiana y activa saberes previos; las intermedias modelan, guían el análisis paso a paso e incluyen ejemplos resueltos; la última permite practicar de forma autónoma o grupal, argumentar y transferir.
- Cada actividad lleva un código (f.n), donde f es el número de la fase y n el de la actividad dentro de ella.${m.id === 'ia' ? '' : ''}`
}

const REGLAS_DUA = `Leyenda fija (usar siempre en este orden): 🟩 = Compromiso | 🟪 = Representación | 🟦 = Acción y Expresión | ⬜ = Principio no aplicado en esa actividad puntual.
Reglas de uso:
1. Cada actividad de las fases debe cerrar con una secuencia de EXACTAMENTE 3 símbolos, en el orden fijo [Compromiso][Representación][Acción y Expresión]. Ejemplos válidos: 🟩⬜⬜ | ⬜🟪⬜ | 🟩🟪⬜ | 🟩🟪🟦 | ⬜⬜🟦
2. Analiza el verbo y el contexto de cada actividad para decidir qué principio(s) aplican:
   - Si la actividad motiva, conecta con intereses/vida real, ofrece opciones o refuerza autonomía → activar 🟩.
   - Si presenta el contenido con apoyos visuales, gráficos, manipulativos, múltiples lenguajes (texto, imagen, símbolo) → activar 🟪.
   - Si pide al estudiante producir, resolver, argumentar, expresar de distintas formas (oral, escrita, gráfica) → activar 🟦.
3. No repetir siempre la misma combinación; debe variar según la naturaleza real de cada actividad.
4. Al inicio de cada fase puede añadirse también una secuencia general que resuma el énfasis DUA dominante de esa fase completa.
5. Analiza una por una las actividades de cada fase y asigna SOLO los principios que de verdad se aplican según su contenido pedagógico y la estrategia descrita. NO marques 🟩🟪🟦 en todas: reserva la combinación de los tres para las actividades realmente integrales, y no confundas las fases (Anticipación, Construcción, Consolidación) con los principios DUA.
6. Escribe el título de cada fase al inicio de su línea, en negrita y sin texto antes (por ejemplo **Anticipación**), y cada actividad en su propia línea terminando con su código (f.n) seguido de los 3 símbolos. El sistema coloca automáticamente el icono de la fase, la barra de colores DUA y los indicadores de cada actividad.`

const REGLAS_REDACCION = `- Usar verbos en infinitivo para las actividades (Reconocer, Aplicar, Resolver, Argumentar, Comparar...). Incluir siempre al menos un ejemplo numérico/concreto por actividad.
- Mantener coherencia entre destreza → indicador → actividades → evaluación (misma habilidad y contenido).
- Sujeto de la acción: centrar el protagonismo en el estudiante o comunidad de aprendizaje; verbos en infinitivo o tercera persona del plural ("Los estudiantes seleccionan...", "Analizar colectivamente..."). Eliminar enfoques magistrales pasivos.
- Fusión metodológica: no segmentar el DUA 3.0 en filas o columnas aisladas; las opciones de accesibilidad y expresión se amalgaman dentro del flujo natural de las fases.
- Diferenciación de productos: en la última fase el estudiante tiene la agencia de elegir el medio o formato (dramatización, informe, campaña digital...) para demostrar la destreza.`

const ORIENTACIONES_2026 = `Cuatro elementos mandatorios en cada orientación metodológica (un solo bloque integrado por momento didáctico):
• Secuencia didáctica de aula: ruta cronológica basada estrictamente en las fases de la metodología elegida.
• Filtrado DUA 3.0 (Marco ACC): consideraciones para derribar barreras de ACCESO, andamiar la CONSTRUCCIÓN del conocimiento y empoderar la AGENCIA (internalización) del aprendiz.
• Inserciones curriculares obligatorias: hilo conductor temático integrado de forma orgánica (las inserciones indicadas por destreza).
• Estrategias de aprendizaje activo: acciones autónomas y cooperativas que ejecutan los estudiantes, según la estrategia elegida.

Matriz de integración didáctica (referencia para ERCA):
| Momento ERCA | Filtro DUA 3.0 (ACC) | Enfoque tecnológico y de inserción (redacción tipo) |
|---|---|---|
| Experiencia | ACCESO | Explorar el fenómeno o dilema real mediante múltiples soportes elegibles (material concreto, recursos de audio locales o infografías visuales), validando las identidades y saberes previos del entorno comunitario. |
| Reflexión | CONSTRUCCIÓN | Problematizar el contexto en comunidades cooperativas. Emplear andamiajes semánticos (glosarios bilingües/ilustrados) y preguntas guía para eliminar barreras lingüísticas y sostener el esfuerzo colectivo. |
| Conceptualización | CONSTRUCCIÓN | Sistematizar principios científicos o conceptuales mediante organizadores gráficos diversificados, mapas conceptuales multimedia o modelado físico de variables del entorno. |
| Aplicación | AGENCIA | Resolver un reto social o práctico del entorno resolviendo la inserción curricular; el estudiante ejerce su agencia decidiendo el formato de salida y autoevaluando su proceso. |
Si la metodología elegida es otra, aplica la misma lógica ACCESO–CONSTRUCCIÓN–AGENCIA a sus fases.`

/* ---------- prompt completo ---------- */

export function buildPrompt(inst: Institucion, plan: Plan, cur?: Curriculo): string {
  const tipo: TipoPlan = plan.tipo || 'micro'
  const r = resumen(plan)
  const ext = EXTENSIONES.find((e) => e.id === plan.extension)!
  const est = ESTRATEGIAS.find((e) => e.id === plan.estrategia)!
  const L: string[] = []

  L.push(rolObjetivo(tipo))
  L.push(h('DATOS CURRICULARES (JSON)'))
  L.push(bloqueJson(plan, cur))

  L.push(h('DATOS INFORMATIVOS'))
  const info: [string, string][] = [
    ['Tipo de documento', TIPOS.find((t) => t.id === tipo)?.nombre ?? ''],
    ['Institución', inst.nombre],
    ['Docente', inst.docente],
    ['Asignatura', cur?.asignatura ?? ''],
    ['Área/Nivel', cur?.nivel ?? ''],
    ['Grado/Curso', plan.grado],
    ['Paralelos', plan.paralelos],
    ['Jornada', plan.jornada],
    ['Año lectivo', plan.anioLectivo],
    [tipo === 'clase' ? 'Fecha de la clase' : 'Fecha de inicio', plan.inicio],
    ...(tipo === 'clase' ? [] : ([['Fecha de finalización', plan.fin]] as [string, string][])),
    ['Unidad / Bloque', plan.unidad],
    ['Tema', plan.tema],
    ['Trimestre / Parcial', `Trimestre ${plan.trimestre} · Parcial ${plan.parcial}`],
  ]
  info.forEach(([k, v]) => L.push(`- ${k}: ${v || '(no indicado)'}`))

  L.push(h('TIEMPO Y CRONOGRAMA'))
  L.push(`1 período = ${plan.minutosPeriodo} minutos. Períodos por semana: ${plan.periodosSemana}.`)
  L.push(`Total de períodos (suma de destrezas): ${r.totalPeriodos} (${r.totalMin} minutos). Semanas lectivas del calendario: ${r.semanas} (${r.disponibles} períodos disponibles = ${r.disponiblesMin} minutos).`)
  L.push('Tiempo por destreza (usa exactamente estos valores):')
  plan.destrezas.forEach((d, i) => L.push(`  ${i + 1}. ${d.codigo}: ${d.periodos} período(s) = ${d.periodos * plan.minutosPeriodo} min`))
  if (plan.cronograma.length && tipo !== 'clase') {
    L.push('\nCronograma semanal (inclúyelo como tabla, respetando fechas y fases):')
    L.push('| Semana | Fechas | Períodos (min) | Fase dominante | Contenido |')
    L.push('|---|---|---|---|---|')
    plan.cronograma.forEach((w) => L.push(`| ${w.semana} | ${w.fechas} | ${w.periodos ?? '—'} (${(w.periodos ?? 0) * plan.minutosPeriodo} min) | ${w.fase} | ${w.contenido || '—'} |`))
  }

  L.push(h('CONFIGURACIÓN ELEGIDA POR EL DOCENTE'))
  L.push(bloqueMetodologia(plan))
  L.push(`- NIVEL DE EXTENSIÓN: ${ext.nombre.toUpperCase()} → ${ext.regla}`)
  L.push(
    plan.estrategia === 'ia'
      ? `- ESTRATEGIA DE APRENDIZAJE ACTIVO: ${est.nombre} — ${est.desc} Justifica en una línea la estrategia elegida para cada destreza.`
      : `- ESTRATEGIA DE APRENDIZAJE ACTIVO: ${est.nombre} — ${est.desc} Debe ser la estrategia dominante en todas las fases.`,
  )
  L.push('\nCompetencias e inserciones por destreza (usa los marcadores EXACTAMENTE como están entre llaves dobles; el sistema los reemplaza por los iconos):')
  plan.destrezas.forEach((d) => {
    const comps = d.competencias.map((k) => `${tokenDe(k)} ${nombreDe(k)}`).join('; ') || 'ninguna'
    const ins = d.inserciones.map((k) => `${tokenDe(k)} ${nombreDe(k)}`).join('; ') || 'ninguna'
    L.push(`  - ${d.codigo} → Competencias: ${comps} | Inserciones: ${ins}`)
  })
  L.push('\nIndicador de evaluación asignado a cada destreza:')
  plan.destrezas.forEach((d) => {
    const ind = cur?.criterios.find((c) => c.codigo === d.criterioCodigo)?.indicadores.find((i) => i.codigo === d.indicadorCodigo)
    L.push(`  - ${d.codigo} → ${ind ? `${ind.codigo}: ${ind.descripcion}` : '(elige el indicador que más directamente evalúe la destreza)'}`)
  })

  const acts = bloqueActividades(plan)
  if (acts) L.push(acts)

  L.push(h('ESTUDIANTES CON NEE'))
  if (plan.nee12.length) {
    L.push('NEE G1 y G2:')
    plan.nee12.forEach((n) => L.push(`  - ${n.estudiante} | ${n.grado} | ${n.estrategia || '(propón la estrategia específica)'}`))
  } else L.push('NEE G1 y G2: No se registran casos.')
  if (plan.nee3.length) {
    L.push('NEE G3:')
    plan.nee3.forEach((n) =>
      L.push(
        `  - ${n.estudiante} | DCD: ${n.dcd || '(propón)'} | Indicador: ${n.indicador || '(propón)'} | Estrategia: ${n.estrategia || '(propón)'} | Recursos: ${n.recursos || '(propón)'} | Evaluación: ${n.evaluacion || '(propón)'}`,
      ),
    )
  } else L.push('NEE G3: No se registran casos.')

  if (tipo === 'recuperacion') {
    L.push(h('ESTUDIANTES EN RECUPERACIÓN PEDAGÓGICA (promedio bajo 7)'))
    if (plan.refuerzo.length) plan.refuerzo.forEach((e) => L.push(`  - ${e.estudiante} | promedio: ${e.promedio || '(no indicado)'} | dificultades: ${e.dificultad || '(propón hipótesis a verificar)'}`))
    else L.push('(El docente aún no registró estudiantes: redacta el plan de forma general para un grupo con promedio inferior a 7 y deja la tabla de diagnóstico con filas vacías para completar.)')
  }

  L.push(h(`ESTRUCTURA OBLIGATORIA DEL DOCUMENTO DE SALIDA — ${(TIPOS.find((t) => t.id === tipo)?.corto ?? '').toUpperCase()}`))
  L.push(estructura(tipo, plan))

  if (tipo !== 'pca') {
    L.push(h('REGLAS DE LAS FASES (METODOLOGÍA ELEGIDA)'))
    L.push(reglasFases(plan))
    L.push(h('REGLAS DEL CÓDIGO DUA 3.0 CON EMOJIS (OBLIGATORIO)'))
    L.push(REGLAS_DUA)
  }
  L.push(h('REGLAS DE REDACCIÓN'))
  L.push(REGLAS_REDACCION)
  L.push(`- El tiempo estimado se expresa en períodos (1 período = ${plan.minutosPeriodo} min) y su equivalente en minutos.`)
  if (tipo !== 'pca') {
    L.push(h('ORIENTACIONES METODOLÓGICAS 2026'))
    L.push(ORIENTACIONES_2026)
  }

  L.push(h('FORMATO DE SALIDA FINAL'))
  L.push(`- Entrega SOLO el documento, en tablas Markdown claras (puedes usar <br> dentro de las celdas para separar actividades), sin comentarios previos ni posteriores y sin envolverlo en bloques de código.
- Empieza directamente en la sección A. NO incluyas el nombre de la institución, el logo ni el título general: el sistema agrega el membrete institucional, el pie con el nombre del docente/tutor y la tabla de firmas automáticamente.
- Usa encabezados de nivel 2 (##) para cada sección, con saltos lógicos por destreza.
- Para las competencias e inserciones usa únicamente los marcadores {{comp:...}} y {{ins:...}} entregados arriba; no inventes otros ni los sustituyas por emojis.
- Para imágenes, esquemas y fórmulas usa únicamente los marcadores {{fig:...}} y {{eq:...}} entregados arriba, cuando existan.
- Mantén el estilo de una planificación institucional del Ministerio de Educación del Ecuador.`)

  if (plan.instrucciones.trim()) {
    L.push(h('INSTRUCCIONES ADICIONALES DEL DOCENTE'))
    L.push(plan.instrucciones.trim())
  }
  return L.join('\n')
}
