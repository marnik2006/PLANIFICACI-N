import type { Curriculo, Plan, SemanaRow } from '../types'
import { EVAL_SEMANA, fasesParaCronograma } from '../constants'

export function parseDate(s: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s)
  if (!m) return null
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]))
  return isNaN(d.getTime()) ? null : d
}

export const fmt = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

const addDays = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n)
/** 1 = lunes … 7 = domingo */
const diaIso = (d: Date) => (d.getDay() === 0 ? 7 : d.getDay())

export interface SemanaCalc {
  start: Date // primer día de clase de la semana
  end: Date // último día de clase de la semana
  dias: number // días de clase dentro del rango
  periodos: number // períodos disponibles esa semana
}

/**
 * Semanas lectivas reales entre inicio y fin: semanas de lunes a domingo, contando solo los días
 * de clase marcados y descontando feriados. Una semana parcial recibe períodos proporcionales.
 */
export function semanasCalendario(plan: Pick<Plan, 'inicio' | 'fin' | 'diasClase' | 'feriados' | 'periodosSemana'>): SemanaCalc[] {
  const a = parseDate(plan.inicio)
  const b = parseDate(plan.fin)
  if (!a || !b || b < a) return []
  const dias = plan.diasClase?.length ? plan.diasClase : [1, 2, 3, 4, 5]
  const libres = new Set(plan.feriados ?? [])
  const semanas = new Map<string, { first: Date; last: Date; n: number }>()
  const orden: string[] = []
  for (let d = a, k = 0; d <= b && k < 800; d = addDays(d, 1), k++) {
    if (!dias.includes(diaIso(d)) || libres.has(fmt(d))) continue
    const lunes = fmt(addDays(d, 1 - diaIso(d)))
    const w = semanas.get(lunes)
    if (w) {
      w.last = d
      w.n++
    } else {
      semanas.set(lunes, { first: d, last: d, n: 1 })
      orden.push(lunes)
    }
  }
  const ps = Number(plan.periodosSemana) || 0
  return orden.map((k) => {
    const w = semanas.get(k)!
    return { start: w.first, end: w.last, dias: w.n, periodos: Math.round((ps * w.n) / dias.length) }
  })
}

export interface Resumen {
  totalPeriodos: number
  totalMin: number
  semanas: number
  disponibles: number
  disponiblesMin: number
  diff: number
}

export function resumen(plan: Plan): Resumen {
  const minutos = Number(plan.minutosPeriodo) || 45
  const totalPeriodos = plan.destrezas.reduce((a, d) => a + (Number(d.periodos) || 0), 0)
  const sem = semanasCalendario(plan)
  const disponibles = sem.reduce((a, w) => a + w.periodos, 0)
  return {
    totalPeriodos,
    totalMin: totalPeriodos * minutos,
    semanas: sem.length,
    disponibles,
    disponiblesMin: disponibles * minutos,
    diff: disponibles - totalPeriodos,
  }
}

const corto = (s: string, n = 110) => (s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s)

export function buildCronograma(plan: Plan, cur?: Curriculo): SemanaRow[] {
  const weeks = semanasCalendario(plan)
  if (!weeks.length) return []
  const n = weeks.length
  const hayEval = n >= 4
  const t = hayEval ? n - 1 : n

  // reparte las destrezas según los períodos reales de cada semana
  const cola = plan.destrezas.map((s) => {
    const d = cur?.criterios.find((c) => c.codigo === s.criterioCodigo)?.destrezas.find((x) => x.codigo === s.codigo)
    return { texto: `${s.codigo} ${corto(d?.descripcion ?? '')}`.trim(), resto: Math.max(1, Number(s.periodos) || 1) }
  })
  const contenido: string[] = Array.from({ length: t }, () => '')
  let q = 0
  for (let w = 0; w < t && q < cola.length; w++) {
    let cap = weeks[w].periodos
    while (cap > 0 && q < cola.length) {
      const take = Math.min(cap, cola[q].resto)
      contenido[w] += `${contenido[w] ? ' / ' : ''}${cola[q].texto} (${take} p.)`
      cola[q].resto -= take
      cap -= take
      if (cola[q].resto === 0) q++
    }
  }
  if (q < cola.length) {
    const falta = cola.slice(q).reduce((a, c) => a + c.resto, 0)
    contenido[t - 1] += `${contenido[t - 1] ? ' / ' : ''}[Faltan ${falta} período(s) por ubicar: ${cola.slice(q).map((c) => c.texto).join('; ')}]`
  }

  const fases = fasesParaCronograma(plan.metodologia)
  const f = fases.length
  const rows: SemanaRow[] = []
  for (let i = 0; i < t; i++) {
    let fase: string
    if (t >= f) fase = fases[Math.min(f - 1, Math.floor((i * f) / t))]
    else {
      const a = Math.floor((i * f) / t)
      const b = Math.max(a, Math.floor(((i + 1) * f - 1) / t))
      fase = fases.slice(a, b + 1).join(' + ')
    }
    if (!hayEval && i === t - 1) fase += ' + Evaluación'
    rows.push({ semana: `Semana ${i + 1}`, fechas: `${fmt(weeks[i].start)} a ${fmt(weeks[i].end)}`, fase, contenido: contenido[i], periodos: weeks[i].periodos })
  }
  if (hayEval) {
    rows.push({
      semana: 'Evaluación',
      fechas: `${fmt(weeks[n - 1].start)} a ${fmt(weeks[n - 1].end)}`,
      fase: EVAL_SEMANA,
      contenido: 'Evaluación sumativa con instrumento acorde al indicador (rúbrica, lista de cotejo o prueba)',
      periodos: weeks[n - 1].periodos,
    })
  }
  return rows
}
