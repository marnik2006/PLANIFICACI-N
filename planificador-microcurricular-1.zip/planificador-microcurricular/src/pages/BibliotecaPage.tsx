import { useState } from 'react'
import { Card, Field, Page } from '../ui'
import { useApp, normalizePlan } from '../store'
import { newPlan, saveToLibrary } from '../lib/planOps'
import { downloadBlob, safeName, uid } from '../lib/util'
import { TIPOS } from '../constants'
import type { PageId } from '../types'

export default function BibliotecaPage({ go }: { go: (p: PageId) => void }) {
  const { state, update, setPlan, toast } = useApp()
  const { plan, guardados, planActualId } = state
  const cur = state.curriculos.find((c) => c.id === plan.curriculoId)
  const actual = guardados.find((g) => g.id === planActualId)
  const [nombre, setNombre] = useState('')
  const [ft, setFt] = useState(0)
  const [fp, setFp] = useState(0)
  const [q, setQ] = useState('')

  const nombreSug = nombre || actual?.nombre || [cur?.asignatura, plan.unidad || plan.tema].filter(Boolean).join(' – ') || 'Planificación'
  const lista = guardados.filter((g) => (!ft || g.trimestre === ft) && (!fp || g.parcial === fp) && (!q || (g.nombre + g.asignatura).toLowerCase().includes(q.toLowerCase())))
  const tipoDe = (t: string) => TIPOS.find((x) => x.id === t)?.corto ?? 'Plan'

  const guardar = (asNew: boolean) => {
    update((s) => saveToLibrary(s, nombreSug, asNew).state)
    toast(asNew || !actual ? 'Planificación guardada' : 'Planificación actualizada')
  }
  const abrir = (id: string) => {
    const g = guardados.find((x) => x.id === id)
    if (!g) return
    update((s) => ({ ...s, plan: normalizePlan(g.plan), planActualId: g.id }))
    toast(`Abierta: ${g.nombre}`)
    go('datos')
  }
  const duplicar = (id: string) => {
    const g = guardados.find((x) => x.id === id)
    if (!g) return
    const now = new Date().toISOString()
    update((s) => ({ ...s, guardados: [{ ...g, id: uid(), nombre: `${g.nombre} (copia)`, creado: now, actualizado: now }, ...s.guardados] }))
  }
  const eliminar = (id: string) => {
    const g = guardados.find((x) => x.id === id)
    if (!g || !window.confirm(`¿Eliminar «${g.nombre}»? Esta acción no se puede deshacer.`)) return
    update((s) => ({ ...s, guardados: s.guardados.filter((x) => x.id !== id), planActualId: s.planActualId === id ? null : s.planActualId }))
  }
  const exportar = (id: string) => {
    const g = guardados.find((x) => x.id === id)
    if (g) downloadBlob(new Blob([JSON.stringify(g, null, 2)], { type: 'application/json' }), `${safeName(g.nombre)}.json`)
  }

  return (
    <Page
      title="Mis planificaciones"
      lead="Guarda cada planificación por trimestre y parcial, vuelve a abrirla, duplícala o bórrala."
      actions={<button className="btn" onClick={() => { update(newPlan); toast('Nueva planificación: elige qué deseas planificar'); go('curriculo') }}>Nueva planificación</button>}
    >
      <Card title="Guardar la planificación actual">
        <div className="grid-3">
          <Field label="Nombre"><input value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder={nombreSug} /></Field>
          <Field label="Trimestre"><select value={plan.trimestre} onChange={(e) => setPlan({ trimestre: Number(e.target.value) })}>{[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
          <Field label="Parcial"><select value={plan.parcial} onChange={(e) => setPlan({ parcial: Number(e.target.value) })}>{[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
        </div>
        <div className="row">
          {actual && <button className="btn primary" onClick={() => guardar(false)}>Actualizar «{actual.nombre}»</button>}
          <button className={actual ? 'btn' : 'btn primary'} onClick={() => guardar(true)}>Guardar como nueva</button>
        </div>
      </Card>

      <Card title={`Guardadas (${lista.length}${lista.length !== guardados.length ? ` de ${guardados.length}` : ''})`}>
        <div className="grid-3">
          <Field label="Buscar"><input value={q} onChange={(e) => setQ(e.target.value)} /></Field>
          <Field label="Trimestre"><select value={ft} onChange={(e) => setFt(Number(e.target.value))}><option value={0}>Todos</option>{[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
          <Field label="Parcial"><select value={fp} onChange={(e) => setFp(Number(e.target.value))}><option value={0}>Todos</option>{[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
        </div>
        {!lista.length && <p className="empty">Todavía no hay planificaciones guardadas con estos filtros.</p>}
        {lista.map((g) => (
          <div key={g.id} className={`saved ${g.id === planActualId ? 'on' : ''}`}>
            <div>
              <strong>{g.nombre}</strong>
              <p className="muted">
                <span className="badge">{tipoDe(g.plan.tipo)}</span> Trimestre {g.trimestre} · Parcial {g.parcial}
                {g.asignatura ? ` · ${g.asignatura}` : ''} · {g.plan.destrezas.length} destreza(s) · {g.plan.respuesta ? 'con documento' : 'sin documento'}
              </p>
              <p className="muted small">Actualizada: {new Date(g.actualizado).toLocaleString('es-EC')}</p>
            </div>
            <div className="row wrap">
              <button className="btn small primary" onClick={() => abrir(g.id)}>Abrir</button>
              <button className="btn small" onClick={() => duplicar(g.id)}>Duplicar</button>
              <button className="btn small" onClick={() => exportar(g.id)}>Exportar</button>
              <button className="btn small danger" onClick={() => eliminar(g.id)}>Eliminar</button>
            </div>
          </div>
        ))}
      </Card>
    </Page>
  )
}
