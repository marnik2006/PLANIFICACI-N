import { useMemo, useState, type DragEvent } from 'react'
import { Card, Page } from '../ui'
import { useApp } from '../store'
import type { Criterio, Curriculo, Destreza, PageId } from '../types'
import { buildIndex, norm, parseCurriculos, search } from '../lib/curriculum'
import { addDestreza, clearSelection, isSel, removeDestreza } from '../lib/planOps'

export default function CurriculoPage({ go }: { go: (p: PageId) => void }) {
  const { state, update, setPlan, toast } = useApp()
  const { plan, curriculos } = state
  const cur: Curriculo | undefined = curriculos.find((c) => c.id === plan.curriculoId) ?? undefined
  const [q, setQ] = useState('')
  const [drag, setDrag] = useState(false)
  const idx = useMemo(() => (cur ? buildIndex(cur) : null), [cur])
  const hits = useMemo(() => (cur && idx && q.trim() ? search(cur, idx, q) : []), [cur, idx, q])

  async function loadFiles(files: FileList | File[]) {
    const added: Curriculo[] = []
    for (const f of Array.from(files)) {
      try {
        added.push(...parseCurriculos(await f.text()))
      } catch (e) {
        toast(`${f.name}: ${(e as Error).message}`)
      }
    }
    if (!added.length) return
    update((s) => {
      const cs = [...s.curriculos]
      for (const a of added) {
        const i = cs.findIndex((c) => norm(c.asignatura) === norm(a.asignatura) && norm(c.nivel) === norm(a.nivel))
        if (i >= 0) {
          a.id = cs[i].id
          cs[i] = a
        } else cs.push(a)
      }
      const first = added[0]
      const cambia = s.plan.curriculoId !== first.id
      const plan = cambia ? { ...clearSelection(s.plan), curriculoId: first.id } : s.plan
      return { ...s, curriculos: cs, plan }
    })
    toast(`${added.length} currículo(s) cargado(s)`)
  }

  async function loadExample() {
    try {
      const r = await fetch(`${import.meta.env.BASE_URL}ejemplo-filosofia.json`)
      await loadFiles([new File([await r.text()], 'ejemplo-filosofia.json')])
    } catch {
      toast('No se pudo cargar el ejemplo')
    }
  }

  function switchCur(id: string) {
    if (id === plan.curriculoId) return
    setPlan((p) => ({ ...clearSelection(p), curriculoId: id }))
    setQ('')
    if (plan.destrezas.length) toast('Cambiaste de currículo: se limpió la selección anterior')
  }

  function removeCur(id: string) {
    if (!window.confirm('¿Quitar este currículo cargado?')) return
    update((s) => {
      const cs = s.curriculos.filter((c) => c.id !== id)
      const activo = s.plan.curriculoId === id
      return {
        ...s,
        curriculos: cs,
        plan: activo ? { ...clearSelection(s.plan), curriculoId: cs[0]?.id ?? '' } : s.plan,
      }
    })
  }

  const toggleD = (c: Criterio, d: Destreza) => {
    if (!cur) return
    setPlan((p) => (isSel(p, c.codigo, d.codigo) ? removeDestreza(p, c.codigo, d.codigo) : addDestreza(p, cur, c, d)))
  }
  const toggleAll = (c: Criterio) => {
    if (!cur) return
    setPlan((p) => {
      const todas = c.destrezas.every((d) => isSel(p, c.codigo, d.codigo))
      let n = p
      for (const d of c.destrezas) n = todas ? removeDestreza(n, c.codigo, d.codigo) : addDestreza(n, cur, c, d)
      return n
    })
  }
  const toggleO = (codigo: string) =>
    setPlan((p) => ({
      ...p,
      objetivos: p.objetivos.includes(codigo) ? p.objetivos.filter((x) => x !== codigo) : [...p.objetivos, codigo],
    }))

  const onDrop = (e: DragEvent) => {
    e.preventDefault()
    setDrag(false)
    if (e.dataTransfer.files.length) void loadFiles(e.dataTransfer.files)
  }

  return (
    <Page
      title="Currículo"
      lead="Sube el archivo .json con objetivos, criterios, destrezas e indicadores. Después busca por código, contenido o escribe un tema y el asistente propone la destreza, el indicador y el objetivo."
    >
      <div
        className={`drop ${drag ? 'over' : ''}`}
        onDragOver={(e) => {
          e.preventDefault()
          setDrag(true)
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={onDrop}
      >
        <p>
          <strong>Arrastra aquí el archivo .json</strong> o
        </p>
        <div className="row">
          <label className="btn primary">
            Elegir archivos .json
            <input type="file" accept=".json,application/json" multiple hidden onChange={(e) => e.target.files && void loadFiles(e.target.files)} />
          </label>
          <button className="btn ghost" onClick={() => void loadExample()}>
            Probar con un ejemplo (Filosofía BGU)
          </button>
        </div>
      </div>

      {curriculos.length > 0 && (
        <div className="chips">
          {curriculos.map((c) => (
            <span key={c.id} className={`chip-cur ${c.id === cur?.id ? 'on' : ''}`}>
              <button onClick={() => switchCur(c.id)}>
                {c.asignatura}
                {c.nivel ? ` · ${c.nivel}` : ''}
              </button>
              <button className="x" aria-label="Quitar currículo" onClick={() => removeCur(c.id)}>
                ×
              </button>
            </span>
          ))}
        </div>
      )}

      {cur && (
        <>
          <Card title="Buscar destreza" hint="Funciona sin conexión: compara tu texto con las destrezas del JSON cargado (por código, palabras clave o tema).">
            <input
              className="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Código, contenido o tema… ej.: falacias, mito y razón, CS.F.5.2.4"
            />
            {q.trim() && !hits.length && <p className="hint">Sin coincidencias. Prueba con otras palabras o elige abajo manualmente.</p>}
            {hits.map((h, i) => {
              const sel = isSel(plan, h.criterio.codigo, h.destreza.codigo)
              return (
                <div key={h.criterio.codigo + h.destreza.codigo} className={`hit ${i === 0 ? 'best' : ''}`}>
                  {i === 0 && <span className="badge">Mejor coincidencia</span>}
                  <div className="codes">
                    <b>{h.destreza.codigo}</b> <span>{h.criterio.codigo}</span>
                  </div>
                  <p>{h.destreza.descripcion}</p>
                  <p className="hint">
                    {h.indicador && (
                      <>
                        Indicador sugerido: <b>{h.indicador.codigo}</b>.{' '}
                      </>
                    )}
                    {h.objetivo && (
                      <>
                        Objetivo sugerido: <b>{h.objetivo.codigo}</b>.
                      </>
                    )}
                  </p>
                  <div className="row">
                    {sel ? (
                      <button className="btn ghost" onClick={() => setPlan((p) => removeDestreza(p, h.criterio.codigo, h.destreza.codigo))}>
                        Quitar
                      </button>
                    ) : (
                      <>
                        <button
                          className="btn primary"
                          onClick={() =>
                            setPlan((p) =>
                              addDestreza(p, cur, h.criterio, h.destreza, {
                                objetivo: h.objetivo?.codigo,
                                indicador: h.indicador?.codigo,
                                query: q,
                              }),
                            )
                          }
                        >
                          Usar sugerencia completa
                        </button>
                        <button className="btn" onClick={() => toggleD(h.criterio, h.destreza)}>
                          Solo la destreza
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )
            })}
          </Card>

          <Card title={`Objetivos de aprendizaje (${plan.objetivos.length} elegidos)`}>
            <details>
              <summary>Ver y elegir objetivos</summary>
              <ul className="plain">
                {cur.objetivos.map((o) => (
                  <li key={o.codigo}>
                    <label className="check">
                      <input type="checkbox" checked={plan.objetivos.includes(o.codigo)} onChange={() => toggleO(o.codigo)} />
                      <span>
                        <b>{o.codigo}</b> {o.descripcion}
                      </span>
                    </label>
                  </li>
                ))}
              </ul>
            </details>
          </Card>

          <Card title="Criterios de evaluación y destrezas" hint="Abre un criterio para ver sus destrezas. El indicador se asigna solo y puedes cambiarlo en «Datos y tiempos».">
            {cur.criterios.map((c) => {
              const n = c.destrezas.filter((d) => isSel(plan, c.codigo, d.codigo)).length
              return (
                <details key={c.codigo} className="crit" open={n > 0}>
                  <summary>
                    <b>{c.codigo}</b> {c.descripcion}
                    {n > 0 && <span className="badge ok">{n} elegida(s)</span>}
                  </summary>
                  <button className="btn small" onClick={() => toggleAll(c)}>
                    {c.destrezas.every((d) => isSel(plan, c.codigo, d.codigo)) ? 'Quitar todas' : 'Elegir todas las destrezas'}
                  </button>
                  <ul className="plain">
                    {c.destrezas.map((d) => (
                      <li key={d.codigo}>
                        <label className="check">
                          <input type="checkbox" checked={isSel(plan, c.codigo, d.codigo)} onChange={() => toggleD(c, d)} />
                          <span>
                            <b>{d.codigo}</b> {d.descripcion}
                          </span>
                        </label>
                      </li>
                    ))}
                  </ul>
                </details>
              )
            })}
          </Card>

          <div className="sticky-bar">
            <span>
              {plan.destrezas.length} destreza(s) · {plan.objetivos.length} objetivo(s)
            </span>
            <button className="btn primary" disabled={!plan.destrezas.length} onClick={() => go('datos')}>
              Continuar a datos y tiempos
            </button>
          </div>
        </>
      )}
    </Page>
  )
}
