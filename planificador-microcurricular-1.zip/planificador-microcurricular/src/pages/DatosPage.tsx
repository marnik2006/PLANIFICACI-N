import { Card, Field, Page } from '../ui'
import { useApp } from '../store'
import { IconView } from '../icons'
import { COMPETENCIAS, INSERCIONES } from '../constants'
import { buildCronograma, resumen } from '../lib/schedule'
import { removeDestreza } from '../lib/planOps'
import type { DestrezaSel, PageId } from '../types'

export default function DatosPage({ go }: { go: (p: PageId) => void }) {
  const { state, setPlan } = useApp()
  const { plan } = state
  const cur = state.curriculos.find((c) => c.id === plan.curriculoId)
  const r = resumen(plan)
  const esClase = plan.tipo === 'clase'

  const setDs = (i: number, patch: Partial<DestrezaSel>) => setPlan((p) => ({ ...p, destrezas: p.destrezas.map((d, k) => (k === i ? { ...d, ...patch } : d)) }))
  const toggleTag = (i: number, campo: 'competencias' | 'inserciones', key: string) => {
    const d = plan.destrezas[i]
    setDs(i, { [campo]: d[campo].includes(key) ? d[campo].filter((k) => k !== key) : [...d[campo], key] } as Partial<DestrezaSel>)
  }
  const regen = () => setPlan((p) => ({ ...p, cronograma: buildCronograma(p, cur) }))
  const setFecha = (campo: 'inicio' | 'fin', v: string) =>
    setPlan((p) => {
      const n = { ...p, [campo]: v }
      return n.cronograma.length ? n : { ...n, cronograma: buildCronograma(n, cur) }
    })
  const repartir = () => {
    if (!r.disponibles || !plan.destrezas.length) return
    const base = Math.floor(r.disponibles / plan.destrezas.length)
    let extra = r.disponibles - base * plan.destrezas.length
    setPlan((p) => ({ ...p, destrezas: p.destrezas.map((d) => ({ ...d, periodos: Math.max(1, base + (extra-- > 0 ? 1 : 0)) })) }))
  }
  const setRow = (i: number, patch: Record<string, string | number>) => setPlan((p) => ({ ...p, cronograma: p.cronograma.map((w, k) => (k === i ? { ...w, ...patch } : w)) }))

  return (
    <Page title="Datos y tiempos" lead="Completa los datos informativos, ajusta los períodos de cada destreza y revisa el cronograma semanal.">
      <Card title="Datos informativos">
        <div className="grid-3">
          <Field label="Grado/Curso"><input value={plan.grado} onChange={(e) => setPlan({ grado: e.target.value })} placeholder="Ej.: 1ro BGU" /></Field>
          <Field label="Paralelos"><input value={plan.paralelos} onChange={(e) => setPlan({ paralelos: e.target.value })} placeholder="A, B" /></Field>
          <Field label="Jornada">
            <select value={plan.jornada} onChange={(e) => setPlan({ jornada: e.target.value })}><option>Matutina</option><option>Vespertina</option><option>Nocturna</option></select>
          </Field>
          <Field label="Año lectivo"><input value={plan.anioLectivo} onChange={(e) => setPlan({ anioLectivo: e.target.value })} /></Field>
          <Field label={esClase ? 'Fecha de la clase' : 'Fecha de inicio'}><input type="date" value={plan.inicio} onChange={(e) => setFecha('inicio', e.target.value)} /></Field>
          {!esClase && <Field label="Fecha de finalización"><input type="date" value={plan.fin} onChange={(e) => setFecha('fin', e.target.value)} /></Field>}
          <Field label="Unidad / Bloque"><input value={plan.unidad} onChange={(e) => setPlan({ unidad: e.target.value })} placeholder="Ej.: Unidad 1" /></Field>
          <Field label="Tema"><input value={plan.tema} onChange={(e) => setPlan({ tema: e.target.value })} /></Field>
          {plan.tipo === 'pca' && (
            <Field label="Número de unidades del año">
              <input type="number" min={1} max={12} value={plan.numUnidades} onChange={(e) => setPlan({ numUnidades: Math.max(1, Number(e.target.value) || 1) })} />
            </Field>
          )}
          <div className="grid-2 tight">
            <Field label="Trimestre"><select value={plan.trimestre} onChange={(e) => setPlan({ trimestre: Number(e.target.value) })}>{[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
            <Field label="Parcial"><select value={plan.parcial} onChange={(e) => setPlan({ parcial: Number(e.target.value) })}>{[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
          </div>
          <Field label="Períodos por semana"><input type="number" min={1} value={plan.periodosSemana} onChange={(e) => setPlan({ periodosSemana: Math.max(1, Number(e.target.value) || 1) })} /></Field>
          <Field label="Minutos por período">
            <div className="row" style={{ marginTop: 0 }}>
              {[40, 45].map((m) => <button key={m} className={`btn small ${plan.minutosPeriodo === m ? 'primary' : ''}`} onClick={() => setPlan({ minutosPeriodo: m })}>{m} min</button>)}
              <input type="number" min={10} max={120} value={plan.minutosPeriodo} onChange={(e) => setPlan({ minutosPeriodo: Math.max(10, Number(e.target.value) || 45) })} aria-label="Minutos por período" />
            </div>
          </Field>
        </div>
      </Card>

      {!esClase && (
        <Card title="Calendario de clases" hint="Las semanas se cuentan de lunes a domingo, solo con los días de clase y sin los feriados; una semana incompleta recibe períodos proporcionales.">
          <div className="tags">
            <span className="tags-label">Días de clase</span>
            {[[1, 'Lun'], [2, 'Mar'], [3, 'Mié'], [4, 'Jue'], [5, 'Vie'], [6, 'Sáb']].map(([n, l]) => (
              <button key={n} className={`tag ${plan.diasClase.includes(n as number) ? 'on' : ''}`} onClick={() => setPlan((p) => ({ ...p, diasClase: p.diasClase.includes(n as number) ? p.diasClase.filter((x) => x !== n) : [...p.diasClase, n as number].sort() }))}>{l}</button>
            ))}
          </div>
          <div className="tags">
            <span className="tags-label">Sin clase (feriados)</span>
            {plan.feriados.map((f) => <button key={f} className="tag on" onClick={() => setPlan((p) => ({ ...p, feriados: p.feriados.filter((x) => x !== f) }))} title="Quitar">{f} ✕</button>)}
            <input type="date" style={{ width: 160 }} aria-label="Agregar día sin clase" onChange={(e) => { const v = e.target.value; if (v) { setPlan((p) => ({ ...p, feriados: p.feriados.includes(v) ? p.feriados : [...p.feriados, v].sort() })); e.target.value = '' } }} />
          </div>
          {r.semanas > 0 && (
            <p className="note">
              <b>{r.semanas} semana(s) lectiva(s)</b> × {plan.periodosSemana} períodos/semana = <b>{r.disponibles} períodos</b> de {plan.minutosPeriodo} min = {r.disponiblesMin} min ({(r.disponiblesMin / 60).toFixed(1)} h).
            </p>
          )}
        </Card>
      )}

      <Card title="Destrezas y tiempo" hint="Cambia los períodos de cada destreza: el total se calcula solo.">
        {!plan.destrezas.length && <p className="empty">Aún no elegiste destrezas. <button className="link" onClick={() => go('curriculo')}>Ir a Currículo</button></p>}
        {plan.destrezas.map((s, i) => {
          const c = cur?.criterios.find((x) => x.codigo === s.criterioCodigo)
          const d = c?.destrezas.find((x) => x.codigo === s.codigo)
          return (
            <div key={s.criterioCodigo + s.codigo} className="ds">
              <div className="ds-head">
                <div><b>{s.codigo}</b> <span className="muted">{s.criterioCodigo}</span><p>{d?.descripcion ?? '(destreza no encontrada en el currículo cargado)'}</p></div>
                <button className="btn small ghost" onClick={() => setPlan((p) => removeDestreza(p, s.criterioCodigo, s.codigo))}>Quitar</button>
              </div>
              <div className="grid-2">
                <Field label="Indicador de evaluación">
                  <select value={s.indicadorCodigo} onChange={(e) => setDs(i, { indicadorCodigo: e.target.value })}>
                    {c?.indicadores.map((ind) => <option key={ind.codigo} value={ind.codigo}>{ind.codigo} — {ind.descripcion.slice(0, 90)}…</option>)}
                    {!c?.indicadores.length && <option value="">Sin indicadores</option>}
                  </select>
                </Field>
                <Field label={`Períodos (${s.periodos * plan.minutosPeriodo} min)`}>
                  <input type="number" min={1} value={s.periodos} onChange={(e) => setDs(i, { periodos: Math.max(1, Number(e.target.value) || 1) })} />
                </Field>
              </div>
              <div className="tags"><span className="tags-label">Competencias</span>
                {COMPETENCIAS.map((t) => <button key={t.key} className={`tag ${s.competencias.includes(t.key) ? 'on' : ''}`} onClick={() => toggleTag(i, 'competencias', t.key)} title={t.nombre}><IconView k={t.key} size={16} /> {t.nombre}</button>)}
              </div>
              <div className="tags"><span className="tags-label">Inserciones</span>
                {INSERCIONES.map((t) => <button key={t.key} className={`tag ${s.inserciones.includes(t.key) ? 'on' : ''}`} onClick={() => toggleTag(i, 'inserciones', t.key)} title={t.nombre}><IconView k={t.key} size={16} /> {t.nombre.replace('Educación ', '').replace('para la ', '').replace('para el ', '')}</button>)}
              </div>
            </div>
          )
        })}
        {plan.destrezas.length > 0 && (
          <div className={`total ${r.semanas && r.diff !== 0 ? (r.diff > 0 ? 'warn' : 'bad') : ''}`}>
            <div><strong>{r.totalPeriodos} períodos</strong> · {r.totalMin} min ({(r.totalMin / 60).toFixed(1)} h){r.semanas > 0 && <> · disponibles: {r.disponibles} períodos en {r.semanas} semana(s)</>}</div>
            {r.semanas > 0 && !esClase && (
              <div className="row">
                <span>{r.diff === 0 ? 'El tiempo cuadra' : r.diff > 0 ? `Sobran ${r.diff} período(s)` : `Faltan ${-r.diff} período(s)`}</span>
                <button className="btn small" onClick={repartir}>Repartir según el calendario</button>
              </div>
            )}
          </div>
        )}
      </Card>

      {!esClase && (
        <Card title="Cronograma semanal" hint="Se calcula con las fechas, las destrezas y las fases de la metodología. Puedes editar cualquier celda; irá en el prompt.">
          <div className="row">
            <button className="btn" onClick={regen} disabled={!r.semanas}>{plan.cronograma.length ? 'Recalcular cronograma' : 'Calcular cronograma'}</button>
            {!r.semanas && <span className="hint">Indica fecha de inicio y de finalización.</span>}
          </div>
          {plan.cronograma.length > 0 && (
            <div className="table-wrap">
              <table className="tbl">
                <thead><tr><th>Semana</th><th>Fechas</th><th>Períodos</th><th>Fase dominante</th><th>Contenido</th></tr></thead>
                <tbody>
                  {plan.cronograma.map((w, i) => (
                    <tr key={i}>
                      <td><input value={w.semana} onChange={(e) => setRow(i, { semana: e.target.value })} /></td>
                      <td><input value={w.fechas} onChange={(e) => setRow(i, { fechas: e.target.value })} /></td>
                      <td style={{ width: 80 }}><input type="number" min={0} value={w.periodos ?? 0} onChange={(e) => setPlan((p) => ({ ...p, cronograma: p.cronograma.map((x, k) => (k === i ? { ...x, periodos: Math.max(0, Number(e.target.value) || 0) } : x)) }))} /></td>
                      <td><input value={w.fase} onChange={(e) => setRow(i, { fase: e.target.value })} /></td>
                      <td><textarea rows={2} value={w.contenido} onChange={(e) => setRow(i, { contenido: e.target.value })} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      <div className="sticky-bar">
        <span>{plan.destrezas.length} destreza(s) · {r.totalPeriodos} períodos</span>
        <button className="btn primary" onClick={() => go('metodologia')}>Continuar a metodología</button>
      </div>
    </Page>
  )
}
