import { useEffect, useMemo, useState } from 'react'
import { Card, Field, Modal, Page } from '../ui'
import { useApp } from '../store'
import { buildPreviewHtml, buildWordBlob, docTitle, renderBody, resolveLayout } from '../lib/docRender'
import { createPdfBlob, pdfDefinition } from '../lib/pdf'
import { downloadBlob, safeName, today, uid } from '../lib/util'
import { saveToLibrary } from '../lib/planOps'
import { firmantesDisponibles } from '../lib/firmas'
import type { LayoutOpts } from '../types'

function FirmasModal({ accion, onClose, onOk }: { accion: 'pdf' | 'word'; onClose: () => void; onOk: (ids: string[], fecha: string) => void }) {
  const { state, update } = useApp()
  const { plan, institucion: inst } = state
  const [ids, setIds] = useState<string[]>(plan.firmas)
  const [fecha, setFecha] = useState(plan.fechaDocumento || today())
  const [cargo, setCargo] = useState('')
  const [nombre, setNombre] = useState('')
  const lista = firmantesDisponibles(inst)
  const toggle = (id: string) => setIds((a) => (a.includes(id) ? a.filter((x) => x !== id) : [...a, id]))
  const agregar = () => {
    if (!cargo.trim()) return
    const id = uid()
    update((s) => ({ ...s, institucion: { ...s.institucion, extras: [...s.institucion.extras, { id, cargo: cargo.trim(), nombre: nombre.trim() }] } }))
    setIds((a) => [...a, id])
    setCargo('')
    setNombre('')
  }
  return (
    <Modal title="¿Quién firma el documento?" onClose={onClose}>
      <Field label="Fecha del documento"><input type="date" value={fecha} onChange={(e) => setFecha(e.target.value)} /></Field>
      <p className="hint">Marca quién firma. Los nombres se toman de «Institución».</p>
      <div className="firmas">
        {lista.map((f) => (
          <label key={f.id} className="check firma">
            <input type="checkbox" checked={ids.includes(f.id)} onChange={() => toggle(f.id)} />
            <span><b>{f.cargo}</b><br /><small className={f.nombre ? '' : 'muted'}>{f.nombre || '(sin nombre en Institución)'}</small></span>
          </label>
        ))}
      </div>
      <div className="row">
        <input placeholder="Cargo" value={cargo} onChange={(e) => setCargo(e.target.value)} />
        <input placeholder="Nombre" value={nombre} onChange={(e) => setNombre(e.target.value)} />
        <button className="btn small" onClick={agregar}>Agregar firma</button>
      </div>
      <div className="row end">
        <button className="btn ghost" onClick={onClose}>Cancelar</button>
        <button className="btn primary" onClick={() => onOk(ids, fecha)}>Generar {accion === 'pdf' ? 'PDF' : 'Word'}</button>
      </div>
    </Modal>
  )
}

export default function DocumentoPage() {
  const { state, setPlan, update, toast } = useApp()
  const { plan, institucion: inst } = state
  const cur = state.curriculos.find((c) => c.id === plan.curriculoId)
  const [body, setBody] = useState('')
  const [busy, setBusy] = useState(false)
  const [avisoRender, setAvisoRender] = useState('')
  const [modal, setModal] = useState<null | 'pdf' | 'word'>(null)

  useEffect(() => {
    let live = true
    if (!plan.respuesta.trim()) { setBody(''); return }
    renderBody(plan.respuesta, state.iconos, plan.visuales, state.duaModo)
      .then((h) => { if (live) { setBody(h); setAvisoRender('') } })
      .catch((e) => { if (live) setAvisoRender(`No se pudo actualizar la vista previa (${(e as Error).message}). Se conserva la última versión válida.`) })
    return () => { live = false }
  }, [plan.respuesta, plan.visuales, state.iconos, state.duaModo])

  const layout = useMemo(() => resolveLayout(plan.layout, body), [plan.layout, body])
  const title = docTitle(inst, cur?.asignatura ?? '', plan.unidad)
  const preview = useMemo(() => (body ? buildPreviewHtml({ inst, plan, body, layout, title }) : ''), [inst, plan, body, layout, title])
  const setL = (patch: Partial<LayoutOpts>) => setPlan((p) => ({ ...p, layout: { ...p.layout, ...patch } }))
  const L = plan.layout

  async function generar(accion: 'pdf' | 'word', ids: string[], fecha: string) {
    setModal(null)
    const p2 = { ...plan, firmas: ids, fechaDocumento: fecha }
    setPlan({ firmas: ids, fechaDocumento: fecha })
    setBusy(true)
    try {
      if (accion === 'pdf') {
        toast('Generando PDF…')
        const blob = await createPdfBlob(pdfDefinition({ inst, plan: p2, bodyHtml: body, layout, title }))
        downloadBlob(blob, `${safeName(title)}.pdf`)
        toast('PDF descargado')
      } else {
        downloadBlob(await buildWordBlob({ inst, plan: p2, body, layout, title }), `${safeName(title)}.doc`)
        toast('Word descargado')
      }
    } catch (e) {
      toast(`No se pudo generar el archivo: ${(e as Error).message}`)
    } finally {
      setBusy(false)
    }
  }
  const pedir = (a: 'pdf' | 'word') => (body ? setModal(a) : toast('Primero pega la respuesta de la IA'))
  const guardar = () => {
    const nombre = [cur?.asignatura, plan.unidad || plan.tema].filter(Boolean).join(' – ') || 'Planificación'
    update((s) => saveToLibrary(s, nombre, false).state)
    toast('Guardada en «Mis planificaciones»')
  }

  return (
    <Page
      title="Documento PDF / Word"
      lead="Pega la respuesta de la IA. El sistema agrega el membrete con logo, los iconos, las imágenes y fórmulas, el pie con docente/tutor y la tabla de firmas."
      actions={
        <>
          <button className="btn primary" disabled={busy} onClick={() => pedir('pdf')}>{busy ? 'Generando…' : 'Descargar PDF'}</button>
          <button className="btn" disabled={busy} onClick={() => pedir('word')}>Descargar Word</button>
          <button className="btn ghost" onClick={guardar}>Guardar planificación</button>
        </>
      }
    >
      <Card title="Respuesta de la IA" hint="Acepta Markdown o HTML. Si la IA agregó texto antes o después del documento, bórralo aquí.">
        <textarea rows={8} value={plan.respuesta} onChange={(e) => setPlan({ respuesta: e.target.value })} placeholder="Pega aquí la planificación generada por la IA…" />
        {plan.respuesta && <button className="btn small ghost" onClick={() => window.confirm('¿Borrar la respuesta pegada?') && setPlan({ respuesta: '' })}>Borrar respuesta</button>}
      </Card>

      <Card title="Ajuste de página">
        <div className="seg">
          <button className={L.modo === 'auto' ? 'on' : ''} onClick={() => setL({ modo: 'auto' })}>Automático</button>
          <button className={L.modo === 'manual' ? 'on' : ''} onClick={() => setL({ modo: 'manual', orientacion: layout.orientacion, fuentePt: layout.fuentePt, margenMm: layout.margenMm })}>Manual</button>
        </div>
        {L.modo === 'auto' ? (
          <p className="hint">Elige solo: hoja {layout.orientacion === 'landscape' ? 'horizontal' : 'vertical'} (según el ancho de las tablas), letra {layout.fuentePt} pt, márgenes {layout.margenMm} mm, membrete y pie en cada página.</p>
        ) : (
          <div className="grid-3">
            <Field label="Orientación"><select value={L.orientacion} onChange={(e) => setL({ orientacion: e.target.value as LayoutOpts['orientacion'] })}><option value="landscape">Horizontal</option><option value="portrait">Vertical</option></select></Field>
            <Field label="Papel"><select value={L.papel} onChange={(e) => setL({ papel: e.target.value as LayoutOpts['papel'] })}><option>A4</option><option>Letter</option></select></Field>
            <Field label={`Márgenes: ${L.margenMm} mm`}><input type="range" min={5} max={30} value={L.margenMm} onChange={(e) => setL({ margenMm: Number(e.target.value) })} /></Field>
            <Field label={`Tamaño de letra: ${L.fuentePt} pt`}><input type="range" min={7} max={13} step={0.5} value={L.fuentePt} onChange={(e) => setL({ fuentePt: Number(e.target.value) })} /></Field>
            <label className="check"><input type="checkbox" checked={L.saltoPorSeccion} onChange={(e) => setL({ saltoPorSeccion: e.target.checked })} />Salto de página antes de cada sección</label>
            <label className="check"><input type="checkbox" checked={L.evitarCortarFilas} onChange={(e) => setL({ evitarCortarFilas: e.target.checked })} />No cortar filas de tabla entre páginas</label>
          </div>
        )}
        <label className="check"><input type="checkbox" checked={L.mostrarCredito} onChange={(e) => setL({ mostrarCredito: e.target.checked })} />Mostrar «Sistema elaborado por» en el pie</label>
      </Card>

      {avisoRender && <div className="alert">{avisoRender}</div>}
      <Card title="Vista previa" hint="Los saltos de página exactos se ven en el PDF descargado. Word: abre el .doc y, si ves una barra amarilla, pulsa «Habilitar edición».">
        {preview ? <iframe className="preview" title="Vista previa del documento" srcDoc={preview} /> : <p className="empty">La vista previa aparecerá cuando pegues la respuesta de la IA.</p>}
      </Card>
      {modal && <FirmasModal accion={modal} onClose={() => setModal(null)} onOk={(ids, f) => void generar(modal, ids, f)} />}
    </Page>
  )
}
