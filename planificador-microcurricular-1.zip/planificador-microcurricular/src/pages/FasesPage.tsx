import { useEffect, useState } from 'react'
import { Card, Page } from '../ui'
import { useApp } from '../store'
import { metodologiaDe } from '../constants'
import { generarActividades, generarFase } from '../lib/actividades'
import { MetodologiaIconos } from '../components/MetodologiaIconos'
import { DUA_PRINC, faseIconoKey } from '../constants'
import { picBarra, picSubida, sugerirDua, unirBits } from '../lib/dua'
import { uid } from '../lib/util'
import { MathView } from '../components/MathView'
import { FormulaDialog, ImageDialog, PasteDialog, type Destino } from '../components/VisualDialogs'
import type { PageId, Visual } from '../types'

export default function FasesPage({ go }: { go: (p: PageId) => void }) {
  const { state, setPlan, toast } = useApp()
  const { plan } = state
  const cur = state.curriculos.find((c) => c.id === plan.curriculoId)
  const asig = cur?.asignatura ?? ''
  const m = metodologiaDe(plan.metodologia)
  const esIA = plan.metodologia === 'ia'
  const nombres = m.fases.map((f) => f.nombre).join('|')
  const [dlg, setDlg] = useState<{ k: 'paste' | 'img' | 'eq'; fase: string } | null>(null)

  useEffect(() => {
    if (!esIA && plan.actividades.map((a) => a.fase).join('|') !== nombres) setPlan((p) => ({ ...p, actividades: generarActividades(p, asig) }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nombres, esIA])

  const semanas = plan.cronograma.map((w, i) => ({ value: String(i), label: `${w.semana} (${w.fechas})` }))
  const destino = (fase: string): Destino => ({ fase, actividades: plan.actividades.find((a) => a.fase === fase)?.items ?? [], semanas })
  const setItems = (fase: string, fn: (items: { id: string; texto: string }[]) => { id: string; texto: string }[]) =>
    setPlan((p) => ({ ...p, actividades: p.actividades.map((a) => (a.fase === fase ? { ...a, items: fn(a.items) } : a)) }))
  const addVisual = (v: Omit<Visual, 'id'>) => {
    setPlan((p) => ({ ...p, visuales: [...p.visuales, { ...v, id: uid() }] }))
    setDlg(null)
    toast('Agregado a la fase')
  }

  function VisualesDe({ fase }: { fase: string }) {
    const vs = plan.visuales.filter((v) => v.fase === fase)
    if (!vs.length) return null
    return (
      <div className="visuales">
        <span className="tags-label">Apoyos visuales</span>
        {vs.map((v) => (
          <div className="visual" key={v.id}>
            <div className="visual-m">{v.tipo === 'img' ? <img src={v.src} alt={v.pie || 'Imagen'} /> : <MathView latex={v.latex} />}</div>
            <span className="muted small">
              {v.pie || (v.tipo === 'img' ? 'Imagen' : 'Fórmula')} · {v.semana === 'todos' ? 'Todas las semanas' : plan.cronograma[Number(v.semana)]?.semana} · {v.actividad < 0 ? 'toda la fase' : `actividad ${v.actividad + 1}`}
            </span>
            <button className="btn small ghost" onClick={() => setPlan((p) => ({ ...p, visuales: p.visuales.filter((x) => x.id !== v.id) }))} aria-label="Quitar">✕</button>
          </div>
        ))}
      </div>
    )
  }

  const Botones = ({ fase }: { fase: string }) => (
    <div className="row wrap between">
      <div className="row wrap">
        {!esIA && (
          <>
            <button className="btn small" onClick={() => setItems(fase, (it) => [...it, { id: uid(), texto: '' }])}>+ Agregar actividad</button>
            <button className="btn small ghost" onClick={() => setDlg({ k: 'paste', fase })}>Pegar lista</button>
            <button className="btn small ghost" onClick={() => { const f = m.fases.find((x) => x.nombre === fase)!; setItems(fase, () => generarFase(plan, asig, f.rol)) }}>↻ Regenerar fase</button>
          </>
        )}
      </div>
      <div className="row wrap">
        <button className="btn small ghost" onClick={() => setDlg({ k: 'img', fase })}>🖼 Imagen o esquema</button>
        <button className="btn small ghost" onClick={() => setDlg({ k: 'eq', fase })}>Σ Fórmula</button>
      </div>
    </div>
  )

  return (
    <Page
      title="Fases y actividades"
      lead={`Metodología: ${m.nombre}. Edita, agrega o quita actividades de cada fase, regenera las que no te gusten y añade imágenes, esquemas o fórmulas. Todo viaja en el prompt.`}
      actions={!esIA && <button className="btn" onClick={() => setPlan((p) => ({ ...p, actividades: generarActividades(p, asig) }))}>↻ Regenerar todas</button>}
    >
      <MetodologiaIconos compacto />
      {esIA && (
        <Card title="La IA elegirá la metodología">
          <p>Las actividades por fase las propone la IA según cada destreza. Aquí puedes dejar listas las imágenes, esquemas y fórmulas que deben aparecer en el documento.</p>
          <Botones fase="" />
          <VisualesDe fase="" />
        </Card>
      )}
      {!esIA &&
        m.fases.map((f, fi) => {
          const items = plan.actividades.find((a) => a.fase === f.nombre)?.items ?? []
          const union = items.reduce((u, it) => unirBits(u, it.dua ?? sugerirDua(it.texto, f.rol)), '000')
          const barra = picBarra(state.iconos, union === '000' ? '111' : union)
          return (
            <div className="card fase" key={f.nombre}>
              <div className="fase-head">
                {(() => { const ic = picSubida(state.iconos, faseIconoKey(f.rol), 38); return ic ? <img className="fase-ico-ui" src={ic.src} alt={f.nombre} style={{ height: 38, width: 'auto' }} /> : <span className="fase-badge">{f.nombre[0]}</span> })()}
                <div>
                  <h2 className="card-title">{fi + 1}. {f.nombre} <img src={barra.src} alt="Principios DUA" width={barra.w} height={barra.h} style={{ verticalAlign: 'middle', marginLeft: 8 }} /></h2>
                  <p className="hint">{f.desc}</p>
                </div>
              </div>
              {items.map((it, k) => {
                const bits = it.dua ?? sugerirDua(it.texto, f.rol)
                return (
                <div className="act" key={it.id}>
                  <span className="act-n">{k + 1}</span>
                  <div className="act-body">
                    <textarea rows={2} value={it.texto} onChange={(e) => setItems(f.nombre, (a) => a.map((x) => (x.id === it.id ? { ...x, texto: e.target.value } : x)))} />
                    <div className="dua-tog" aria-label="Principios DUA de la actividad">
                      {DUA_PRINC.map((p, i) => (
                        <button key={p.key} type="button" className={bits[i] === '1' ? 'on' : ''} style={{ background: bits[i] === '1' ? p.color : '#fff' }} title={`${p.nombre}: ${bits[i] === '1' ? 'aplica' : 'no aplica'}`} aria-pressed={bits[i] === '1'}
                          onClick={() => { const nb = [...bits]; nb[i] = nb[i] === '1' ? '0' : '1'; if (!nb.includes('1')) return; setItems(f.nombre, (a) => a.map((x) => (x.id === it.id ? { ...x, dua: nb.join('') } : x))) }} />
                      ))}
                      <span className="muted small">{it.dua ? 'DUA definido por ti' : 'DUA sugerido'}{state.iconos[`duac:${bits}`] && <img src={state.iconos[`duac:${bits}`]} alt="" style={{ height: 12, marginLeft: 8, verticalAlign: 'middle' }} />}</span>
                    </div>
                  </div>
                  <button className="btn small ghost" aria-label="Quitar actividad" onClick={() => setItems(f.nombre, (a) => a.filter((x) => x.id !== it.id))}>✕</button>
                </div>
                )
              })}
              <Botones fase={f.nombre} />
              <VisualesDe fase={f.nombre} />
            </div>
          )
        })}

      {dlg?.k === 'paste' && (
        <PasteDialog fase={dlg.fase} onClose={() => setDlg(null)} onAdd={(lines) => { setItems(dlg.fase, (it) => [...it.filter((x) => x.texto.trim()), ...lines.map((t) => ({ id: uid(), texto: t }))]); setDlg(null) }} />
      )}
      {dlg?.k === 'img' && <ImageDialog destino={destino(dlg.fase)} onClose={() => setDlg(null)} onAdd={addVisual} />}
      {dlg?.k === 'eq' && <FormulaDialog destino={destino(dlg.fase)} onClose={() => setDlg(null)} onAdd={addVisual} />}

      <div className="sticky-bar">
        <span>{plan.actividades.reduce((a, f) => a + f.items.length, 0)} actividades · {plan.visuales.length} apoyo(s) visual(es)</span>
        <button className="btn primary" onClick={() => go('prompt')}>Generar prompt para la IA</button>
      </div>
    </Page>
  )
}
