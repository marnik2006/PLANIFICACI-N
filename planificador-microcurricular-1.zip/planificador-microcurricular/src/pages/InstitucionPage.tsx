import type { ChangeEvent } from 'react'
import { Card, Field, Page } from '../ui'
import { useApp } from '../store'
import { resizeImage } from '../lib/image'
import type { Institucion } from '../types'

export default function InstitucionPage() {
  const { state, update, toast } = useApp()
  const i = state.institucion
  const set = (patch: Partial<Institucion>) => update((s) => ({ ...s, institucion: { ...s.institucion, ...patch } }))

  async function onLogo(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    try {
      set({ logo: await resizeImage(f, 360) })
      toast('Logo cargado')
    } catch {
      toast('No se pudo leer la imagen. Usa PNG, JPG o SVG.')
    }
  }

  return (
    <Page
      title="Institución y docente"
      lead="Estos datos aparecen en el membrete de cada página del PDF y del Word, y el nombre del docente/tutor en el pie."
    >
      <div className="grid-2">
        <Card title="Unidad educativa">
          <Field label="Nombre de la unidad educativa">
            <input value={i.nombre} onChange={(e) => set({ nombre: e.target.value })} placeholder="Ej.: Unidad Educativa «27 de Febrero»" />
          </Field>
          <Field label="Línea adicional del membrete" hint="Opcional: AMIE, zona, distrito, dirección o teléfono.">
            <input value={i.linea} onChange={(e) => set({ linea: e.target.value })} />
          </Field>
          <label className="check">
            <input type="checkbox" checked={i.mostrarMinisterio} onChange={(e) => set({ mostrarMinisterio: e.target.checked })} />
            Mostrar «República del Ecuador · Ministerio de Educación»
          </label>
          <div className="logo-row">
            <div className="logo-box">{i.logo ? <img src={i.logo} alt="Logo de la institución" /> : <span>Sin logo</span>}</div>
            <div className="stack">
              <label className="btn">
                Subir logo
                <input type="file" accept="image/*" hidden onChange={onLogo} />
              </label>
              {i.logo && (
                <button className="btn ghost" onClick={() => set({ logo: '' })}>
                  Quitar logo
                </button>
              )}
            </div>
          </div>
        </Card>

        <Card title="Responsables" hint="Los nombres se usan en el pie del documento y en la tabla de legalización.">
          <Field label="Docente">
            <input value={i.docente} onChange={(e) => set({ docente: e.target.value })} />
          </Field>
          <Field label="Tutor/a (aparece al pie de cada página)">
            <input value={i.tutor} onChange={(e) => set({ tutor: e.target.value })} />
          </Field>
          <Field label="Comisión Académica">
            <input value={i.comision} onChange={(e) => set({ comision: e.target.value })} />
          </Field>
          <Field label="Vicerrector/a">
            <input value={i.vicerrector} onChange={(e) => set({ vicerrector: e.target.value })} />
          </Field>
          <Field label="Rector/a">
            <input value={i.rector} onChange={(e) => set({ rector: e.target.value })} />
          </Field>
          <Field label="Secretario/a">
            <input value={i.secretario} onChange={(e) => set({ secretario: e.target.value })} />
          </Field>
          <Field label="Inspector/a General">
            <input value={i.inspector} onChange={(e) => set({ inspector: e.target.value })} />
          </Field>
          {i.extras.map((x) => (
            <div className="row" key={x.id}>
              <input value={x.cargo} onChange={(e) => set({ extras: i.extras.map((y) => (y.id === x.id ? { ...y, cargo: e.target.value } : y)) })} aria-label="Cargo" />
              <input value={x.nombre} onChange={(e) => set({ extras: i.extras.map((y) => (y.id === x.id ? { ...y, nombre: e.target.value } : y)) })} aria-label="Nombre" />
              <button className="btn small ghost" onClick={() => set({ extras: i.extras.filter((y) => y.id !== x.id) })}>Quitar</button>
            </div>
          ))}
        </Card>
      </div>

      <Card title="Vista del membrete">
        <div className="membrete">
          <div className="membrete-logo">{i.logo && <img src={i.logo} alt="" />}</div>
          <div className="membrete-txt">
            {i.mostrarMinisterio && <small>REPÚBLICA DEL ECUADOR · MINISTERIO DE EDUCACIÓN</small>}
            <strong>{(i.nombre || 'Nombre de la unidad educativa').toUpperCase()}</strong>
            {i.linea && <small>{i.linea}</small>}
          </div>
          <div className="membrete-logo" />
        </div>
        <div className="membrete-pie">
          <span>{i.docente ? `Docente: ${i.docente}` : 'Docente: —'}</span>
          <span>{i.tutor ? `Tutor/a: ${i.tutor}` : 'Tutor/a: —'}</span>
        </div>
      </Card>
    </Page>
  )
}
