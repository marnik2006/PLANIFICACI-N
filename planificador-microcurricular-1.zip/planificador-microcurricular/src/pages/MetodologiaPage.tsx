import { Card, Page } from '../ui'
import { useApp } from '../store'
import { COLUMNAS_DEFAULT, ESTRATEGIAS, EXTENSIONES, METODOLOGIAS, metodologiaDe } from '../constants'
import { uid } from '../lib/util'
import { generarActividades } from '../lib/actividades'
import { buildCronograma } from '../lib/schedule'
import type { MetodologiaId, PageId } from '../types'

export default function MetodologiaPage({ go }: { go: (p: PageId) => void }) {
  const { state, setPlan } = useApp()
  const { plan } = state
  const cur = state.curriculos.find((c) => c.id === plan.curriculoId)
  const m = metodologiaDe(plan.metodologia)
  const cols = plan.columnas?.length ? plan.columnas : COLUMNAS_DEFAULT

  function elegir(id: MetodologiaId) {
    if (id === plan.metodologia) return
    if (plan.actividades.some((f) => f.items.length) && !window.confirm('Al cambiar de metodología se reemplazan las actividades por fase (las imágenes y fórmulas se conservan). ¿Continuar?')) return
    setPlan((p) => {
      const np = { ...p, metodologia: id }
      return {
        ...np,
        actividades: generarActividades(np, cur?.asignatura ?? ''),
        visuales: p.visuales.map((v) => ({ ...v, fase: '', actividad: -1 })),
        cronograma: p.cronograma.length ? buildCronograma(np, cur) : [],
      }
    })
  }
  const setCol = (i: number, patch: Partial<{ label: string; on: boolean }>) => setPlan((p) => ({ ...p, columnas: cols.map((c, k) => (k === i ? { ...c, ...patch } : c)) }))
  const mover = (i: number, d: number) =>
    setPlan((p) => {
      const a = [...cols]
      const j = i + d
      if (j < 0 || j >= a.length) return p
      ;[a[i], a[j]] = [a[j], a[i]]
      return { ...p, columnas: a }
    })

  const upd12 = (id: string, patch: Record<string, string>) => setPlan((p) => ({ ...p, nee12: p.nee12.map((n) => (n.id === id ? { ...n, ...patch } : n)) }))
  const upd3 = (id: string, patch: Record<string, string>) => setPlan((p) => ({ ...p, nee3: p.nee3.map((n) => (n.id === id ? { ...n, ...patch } : n)) }))
  const updR = (id: string, patch: Record<string, string>) => setPlan((p) => ({ ...p, refuerzo: p.refuerzo.map((n) => (n.id === id ? { ...n, ...patch } : n)) }))

  return (
    <Page title="Metodología y NEE" lead="Elige cómo se desarrollará el proceso didáctico (las actividades se organizan por fases), la estrategia activa y la extensión.">
      <Card title="Metodología de aprendizaje" hint="Metodologías usadas en el sistema educativo ecuatoriano. Si lo prefieres, deja que la IA elija la más adecuada para cada destreza.">
        <div className="options met">
          {METODOLOGIAS.map((x) => (
            <button key={x.id} className={`option ${plan.metodologia === x.id ? 'on' : ''}`} onClick={() => elegir(x.id)} aria-pressed={plan.metodologia === x.id}>
              <strong>{plan.metodologia === x.id ? '✔ ' : ''}{x.nombre}</strong>
              <span>{x.resumen}</span>
            </button>
          ))}
        </div>
        <div className="note"><b>{m.nombre}.</b> {m.detalle}</div>
      </Card>

      <Card title="Estrategia de aprendizaje activo" hint="Cómo trabajan los estudiantes dentro de las fases.">
        <div className="options">
          {ESTRATEGIAS.map((e) => (
            <button key={e.id} className={`option ${plan.estrategia === e.id ? 'on' : ''}`} onClick={() => setPlan({ estrategia: e.id })}>
              <strong>{e.nombre}</strong>
              <span>{e.desc}</span>
            </button>
          ))}
        </div>
      </Card>

      <Card title="Nivel de extensión de las orientaciones metodológicas">
        <div className="options four">
          {EXTENSIONES.map((e) => (
            <button key={e.id} className={`option ${plan.extension === e.id ? 'on' : ''}`} onClick={() => setPlan({ extension: e.id })}>
              <strong>{e.nombre}</strong>
              <span>{e.desc}</span>
            </button>
          ))}
        </div>
      </Card>

      <Card title="Columnas del cuadro principal" hint="Apaga las que tu institución no usa, cámbiales el nombre o reordénalas. «Orientaciones» siempre se mantiene.">
        {cols.map((c, i) => (
          <div className="col-row" key={c.id}>
            <span className="col-n">{c.on ? cols.slice(0, i + 1).filter((x) => x.on).length : '—'}</span>
            <input value={c.label} onChange={(e) => setCol(i, { label: e.target.value })} aria-label={`Nombre de la columna ${c.id}`} />
            <button className="btn small ghost" onClick={() => mover(i, -1)} aria-label="Subir">↑</button>
            <button className="btn small ghost" onClick={() => mover(i, 1)} aria-label="Bajar">↓</button>
            <label className="switch">
              <input type="checkbox" checked={c.on || c.id === 'orientaciones'} disabled={c.id === 'orientaciones'} onChange={(e) => setCol(i, { on: e.target.checked })} />
              <span>{c.on || c.id === 'orientaciones' ? 'Sí' : 'No'}</span>
            </label>
          </div>
        ))}
        <button className="btn small ghost" onClick={() => setPlan({ columnas: COLUMNAS_DEFAULT.map((c) => ({ ...c })) })}>Restaurar formato estándar</button>
      </Card>

      {plan.tipo === 'recuperacion' && (
        <Card title="Estudiantes en recuperación (promedio bajo 7)">
          {plan.refuerzo.map((n) => (
            <div className="nee-row" key={n.id}>
              <input placeholder="Estudiante" value={n.estudiante} onChange={(e) => updR(n.id, { estudiante: e.target.value })} />
              <input placeholder="Promedio" value={n.promedio} onChange={(e) => updR(n.id, { promedio: e.target.value })} />
              <input placeholder="Dificultades observadas (opcional)" value={n.dificultad} onChange={(e) => updR(n.id, { dificultad: e.target.value })} />
              <button className="btn small ghost" onClick={() => setPlan((p) => ({ ...p, refuerzo: p.refuerzo.filter((x) => x.id !== n.id) }))}>Quitar</button>
            </div>
          ))}
          <button className="btn" onClick={() => setPlan((p) => ({ ...p, refuerzo: [...p.refuerzo, { id: uid(), estudiante: '', promedio: '', dificultad: '' }] }))}>Agregar estudiante</button>
        </Card>
      )}

      <Card title="NEE G1 y G2" hint="Si no hay casos, déjalo vacío: el documento dirá «No se registran casos».">
        {plan.nee12.map((n) => (
          <div className="nee-row" key={n.id}>
            <input placeholder="Estudiante" value={n.estudiante} onChange={(e) => upd12(n.id, { estudiante: e.target.value })} />
            <select value={n.grado} onChange={(e) => upd12(n.id, { grado: e.target.value })}><option>G1</option><option>G2</option></select>
            <input placeholder="Estrategia específica (opcional)" value={n.estrategia} onChange={(e) => upd12(n.id, { estrategia: e.target.value })} />
            <button className="btn small ghost" onClick={() => setPlan((p) => ({ ...p, nee12: p.nee12.filter((x) => x.id !== n.id) }))}>Quitar</button>
          </div>
        ))}
        <button className="btn" onClick={() => setPlan((p) => ({ ...p, nee12: [...p.nee12, { id: uid(), estudiante: '', grado: 'G1', estrategia: '' }] }))}>Agregar estudiante G1/G2</button>
      </Card>

      <Card title="NEE G3 (adaptación significativa)">
        {plan.nee3.map((n) => (
          <div className="nee3" key={n.id}>
            <div className="row">
              <input placeholder="Estudiante" value={n.estudiante} onChange={(e) => upd3(n.id, { estudiante: e.target.value })} />
              <button className="btn small ghost" onClick={() => setPlan((p) => ({ ...p, nee3: p.nee3.filter((x) => x.id !== n.id) }))}>Quitar</button>
            </div>
            <div className="grid-2">
              <input placeholder="DCD adaptada" value={n.dcd} onChange={(e) => upd3(n.id, { dcd: e.target.value })} />
              <input placeholder="Indicador" value={n.indicador} onChange={(e) => upd3(n.id, { indicador: e.target.value })} />
              <input placeholder="Estrategia" value={n.estrategia} onChange={(e) => upd3(n.id, { estrategia: e.target.value })} />
              <input placeholder="Recursos" value={n.recursos} onChange={(e) => upd3(n.id, { recursos: e.target.value })} />
              <input placeholder="Evaluación" value={n.evaluacion} onChange={(e) => upd3(n.id, { evaluacion: e.target.value })} />
            </div>
          </div>
        ))}
        <button className="btn" onClick={() => setPlan((p) => ({ ...p, nee3: [...p.nee3, { id: uid(), estudiante: '', dcd: '', indicador: '', estrategia: '', recursos: '', evaluacion: '' }] }))}>Agregar estudiante G3</button>
      </Card>

      <div className="sticky-bar">
        <span>{m.nombre} · {EXTENSIONES.find((e) => e.id === plan.extension)?.nombre}</span>
        <button className="btn primary" onClick={() => go('fases')}>Continuar a fases y actividades</button>
      </div>
    </Page>
  )
}
