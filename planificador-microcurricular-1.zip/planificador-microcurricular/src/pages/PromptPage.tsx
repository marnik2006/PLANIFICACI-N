import { useMemo } from 'react'
import { Card, Page } from '../ui'
import { useApp } from '../store'
import { buildPrompt } from '../lib/prompt'
import { copyText, downloadBlob, safeName } from '../lib/util'
import type { PageId } from '../types'

export default function PromptPage({ go }: { go: (p: PageId) => void }) {
  const { state, setPlan, toast } = useApp()
  const { plan, institucion: inst } = state
  const cur = state.curriculos.find((c) => c.id === plan.curriculoId)
  const prompt = useMemo(() => buildPrompt(inst, plan, cur), [inst, plan, cur])

  const checks: [string, boolean][] = [
    ['Currículo cargado', !!cur],
    ['Al menos una destreza elegida', plan.destrezas.length > 0],
    ['Fechas de inicio y fin', !!plan.inicio && !!plan.fin],
    ['Nombre de la institución', !!inst.nombre.trim()],
    ['Nombre del docente', !!inst.docente.trim()],
  ]

  async function copy() {
    toast((await copyText(prompt)) ? 'Prompt copiado. Pégalo en tu IA.' : 'No se pudo copiar. Selecciona el texto y cópialo.')
  }

  return (
    <Page
      title="Prompt para la IA"
      lead="Copia este prompt, pégalo en ChatGPT, Claude, Gemini u otra IA y luego trae la respuesta a «Documento PDF / Word»."
      actions={
        <>
          <button className="btn primary" onClick={() => void copy()}>Copiar prompt</button>
          <button className="btn" onClick={() => downloadBlob(new Blob([prompt], { type: 'text/plain;charset=utf-8' }), `${safeName('prompt-' + (cur?.asignatura ?? 'planificacion'))}.txt`)}>
            Descargar .txt
          </button>
        </>
      }
    >
      <Card title="Antes de copiar">
        <ul className="checks">
          {checks.map(([t, ok]) => (
            <li key={t} className={ok ? 'ok' : 'pend'}>{ok ? '✔' : '○'} {t}</li>
          ))}
        </ul>
      </Card>

      <Card title="Instrucciones adicionales para la IA" hint="Opcional. Ej.: contexto de la comunidad, sin internet ni proyector, usar materiales del entorno, tono, vocabulario bilingüe…">
        <textarea rows={4} value={plan.instrucciones} onChange={(e) => setPlan({ instrucciones: e.target.value })} placeholder="Escribe aquí lo que la IA debe tener en cuenta…" />
        <div className="row wrap">
          {['Contexto de la comunidad (Otavalo/Imbabura)', 'Trabajo en grupos', 'Material concreto', 'Sin internet ni proyector', 'Evaluación formativa', 'Interculturalidad y saberes ancestrales'].map((t) => (
            <button key={t} className="btn small ghost" onClick={() => setPlan({ instrucciones: plan.instrucciones ? `${plan.instrucciones.trim()}\n- ${t}` : `- ${t}` })}>
              + {t}
            </button>
          ))}
        </div>
      </Card>

      <Card title={`Prompt generado (${prompt.length.toLocaleString('es')} caracteres)`} hint="Se actualiza solo cuando cambias cualquier dato.">
        <textarea className="mono" readOnly rows={18} value={prompt} onFocus={(e) => e.currentTarget.select()} />
        <div className="row">
          <button className="btn primary" onClick={() => void copy()}>Copiar prompt</button>
          <button className="btn" onClick={() => go('documento')}>Ya tengo la respuesta de la IA</button>
        </div>
      </Card>
    </Page>
  )
}
