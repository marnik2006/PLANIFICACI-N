import { useMemo, useState, type ChangeEvent } from 'react'
import { Card, Page } from '../ui'
import { useApp, normalizeState, STORAGE_KEY } from '../store'
import { ICON_CATALOG } from '../constants'
import { IconView } from '../icons'
import { MetodologiaIconos } from '../components/MetodologiaIconos'
import { resizeImage } from '../lib/image'
import { downloadBlob, today } from '../lib/util'
import { defaultState } from '../defaults'

export default function RespaldoPage() {
  const { state, update, replace, resetAll, toast, saveError } = useApp()
  const [modo, setModo] = useState<'reemplazar' | 'combinar'>('reemplazar')
  const bytes = useMemo(() => new Blob([JSON.stringify(state)]).size, [state])

  async function onIcon(key: string, e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    try {
      const url = await resizeImage(f, 128)
      update((s) => ({ ...s, iconos: { ...s.iconos, [key]: url } }))
    } catch {
      toast('No se pudo leer la imagen')
    }
  }
  const quitarIcon = (key: string) =>
    update((s) => {
      const iconos = { ...s.iconos }
      delete iconos[key]
      return { ...s, iconos }
    })

  function respaldo() {
    const data = { app: 'planificador-mc', version: 1, exportedAt: new Date().toISOString(), state }
    downloadBlob(new Blob([JSON.stringify(data)], { type: 'application/json' }), `respaldo-planificador-${today()}.json`)
  }

  async function restaurar(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    try {
      const data = JSON.parse(await f.text())
      if (data?.app !== 'planificador-mc' || !data.state) throw new Error('formato')
      const incoming = normalizeState(data.state)
      if (modo === 'reemplazar') {
        if (!window.confirm('Se reemplazarán TODOS los datos actuales por los del respaldo. ¿Continuar?')) return
        replace(incoming)
      } else {
        update((s) => ({
          ...s,
          guardados: [...s.guardados, ...incoming.guardados.filter((g) => !s.guardados.some((x) => x.id === g.id))],
          curriculos: [...s.curriculos, ...incoming.curriculos.filter((c) => !s.curriculos.some((x) => x.id === c.id))],
        }))
      }
      toast('Respaldo restaurado')
    } catch {
      toast('El archivo no es un respaldo válido de este sistema')
    }
  }

  function reiniciar() {
    const t = window.prompt('Esto eliminará TODO lo realizado (planificaciones, currículos, logo, iconos). Escribe REINICIAR para confirmar.')
    if (t?.trim().toUpperCase() !== 'REINICIAR') return
    resetAll()
    toast('Sistema reiniciado a valores de fábrica')
  }

  return (
    <Page title="Respaldo e iconos" lead="Tu trabajo se guarda solo en este dispositivo. Descarga un respaldo para llevarlo a otra laptop o celular.">
      <Card title="Iconografía de competencias e inserciones" hint="Sube tus propios iconos (PNG, JPG o SVG). Se verán en las destrezas y dentro del PDF/Word donde la IA coloque cada competencia o inserción.">
        <div className="icons-grid">
          {ICON_CATALOG.map((i) => (
            <div className="icon-card" key={i.key}>
              <div className="icon-prev"><IconView k={i.key} size={40} /></div>
              <div className="icon-txt">
                <strong>{i.nombre}</strong>
                <span className="muted small">{i.tipo === 'comp' ? 'Competencia' : 'Inserción curricular'}</span>
              </div>
              <div className="row">
                <label className="btn small">
                  Subir
                  <input type="file" accept="image/*" hidden onChange={(e) => void onIcon(i.key, e)} />
                </label>
                {state.iconos[i.key] && <button className="btn small ghost" onClick={() => quitarIcon(i.key)}>Restaurar</button>}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <MetodologiaIconos />

      <div className="grid-2">
        <Card title="Respaldo" hint="Incluye institución, logo, currículos cargados, iconos y todas las planificaciones guardadas.">
          <button className="btn primary" onClick={respaldo}>Descargar respaldo (.json)</button>
          <p className="muted small">
            Espacio usado en este dispositivo: {(bytes / 1024).toFixed(0)} KB. Guardadas: {state.guardados.length} planificación(es).
          </p>
          {saveError && <p className="alert">{saveError}</p>}
        </Card>

        <Card title="Restaurar">
          <div className="seg">
            <button className={modo === 'reemplazar' ? 'on' : ''} onClick={() => setModo('reemplazar')}>Reemplazar todo</button>
            <button className={modo === 'combinar' ? 'on' : ''} onClick={() => setModo('combinar')}>Solo agregar planificaciones y currículos</button>
          </div>
          <label className="btn">
            Elegir archivo de respaldo
            <input type="file" accept=".json,application/json" hidden onChange={(e) => void restaurar(e)} />
          </label>
        </Card>
      </div>

      <Card title="Reiniciar a valores de fábrica">
        <p>Elimina todo lo realizado en este sistema. Descarga un respaldo antes si quieres conservar algo.</p>
        <button className="btn danger" onClick={reiniciar}>Reiniciar sistema</button>
        <span className="hint"> (clave de almacenamiento: {STORAGE_KEY}; estado inicial: {Object.keys(defaultState()).length} secciones)</span>
      </Card>
    </Page>
  )
}
