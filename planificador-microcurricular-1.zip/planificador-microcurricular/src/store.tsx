import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import type { AppState, Plan } from './types'
import { defaultPlan, defaultState } from './defaults'

export const STORAGE_KEY = 'planificador-mc-v1'

export function normalizePlan(p: any): Plan {
  const d = defaultPlan()
  return { ...d, ...(p ?? {}), layout: { ...d.layout, ...(p?.layout ?? {}) } }
}

export function normalizeState(raw: any): AppState {
  const d = defaultState()
  return {
    ...d,
    ...(raw ?? {}),
    institucion: { ...d.institucion, ...(raw?.institucion ?? {}) },
    curriculos: Array.isArray(raw?.curriculos) ? raw.curriculos : [],
    plan: normalizePlan(raw?.plan),
    planActualId: raw?.planActualId ?? null,
    iconos: raw?.iconos && typeof raw.iconos === 'object' ? raw.iconos : {},
    duaModo: raw?.duaModo === 'iconos' ? 'iconos' : 'cuadros',
    guardados: Array.isArray(raw?.guardados)
      ? raw.guardados.map((g: any) => ({ ...g, plan: normalizePlan(g.plan) }))
      : [],
  }
}

function load(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return normalizeState(JSON.parse(raw))
  } catch {
    /* datos corruptos: se inicia desde cero */
  }
  return defaultState()
}

interface Ctx {
  state: AppState
  update: (fn: (s: AppState) => AppState) => void
  setPlan: (patch: Partial<Plan> | ((p: Plan) => Plan)) => void
  replace: (s: AppState) => void
  resetAll: () => void
  saveError: string | null
  toast: (m: string) => void
  toastMsg: string | null
}

const AppCtx = createContext<Ctx | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(load)
  const [saveError, setSaveError] = useState<string | null>(null)
  const [toastMsg, setToastMsg] = useState<string | null>(null)
  const toastTimer = useRef<number | undefined>(undefined)

  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
        setSaveError(null)
      } catch {
        setSaveError(
          'No se pudo guardar en este dispositivo (almacenamiento lleno). Descarga un respaldo desde «Respaldo e iconos».',
        )
      }
    }, 400)
    return () => window.clearTimeout(t)
  }, [state])

  const update = useCallback((fn: (s: AppState) => AppState) => setState((s) => fn(s)), [])
  const setPlan = useCallback(
    (patch: Partial<Plan> | ((p: Plan) => Plan)) =>
      setState((s) => ({
        ...s,
        plan: typeof patch === 'function' ? patch(s.plan) : { ...s.plan, ...patch },
      })),
    [],
  )
  const replace = useCallback((s: AppState) => setState(normalizeState(s)), [])
  const resetAll = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY)
    } catch {
      /* nada */
    }
    setState(defaultState())
  }, [])
  const toast = useCallback((m: string) => {
    setToastMsg(m)
    window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(() => setToastMsg(null), 3500)
  }, [])

  return (
    <AppCtx.Provider value={{ state, update, setPlan, replace, resetAll, saveError, toast, toastMsg }}>
      {children}
    </AppCtx.Provider>
  )
}

export function useApp(): Ctx {
  const c = useContext(AppCtx)
  if (!c) throw new Error('useApp debe usarse dentro de AppProvider')
  return c
}
