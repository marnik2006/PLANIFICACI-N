export interface Objetivo { codigo: string; descripcion: string }
export interface Destreza { codigo: string; descripcion: string }
export interface Indicador { codigo: string; descripcion: string }
export interface Criterio {
  codigo: string
  descripcion: string
  destrezas: Destreza[]
  indicadores: Indicador[]
}
export interface Curriculo {
  id: string
  asignatura: string
  nivel: string
  objetivos: Objetivo[]
  criterios: Criterio[]
}

export interface DestrezaSel {
  codigo: string
  criterioCodigo: string
  indicadorCodigo: string
  periodos: number
  competencias: string[]
  inserciones: string[]
}
export interface SemanaRow { semana: string; fechas: string; fase: string; contenido: string; periodos?: number }
export interface NEE12 { id: string; estudiante: string; grado: string; estrategia: string }
export interface NEE3 {
  id: string
  estudiante: string
  dcd: string
  indicador: string
  estrategia: string
  recursos: string
  evaluacion: string
}

export type TipoPlan = '' | 'pud' | 'micro' | 'pca' | 'clase' | 'recuperacion' | 'cnc'
export type MetodologiaId = 'ia' | 'erca' | 'acc' | 'saberes' | 'abp' | 'proyectos' | 'indagacion' | 'dua' | 'invertida'
export type Extension = 'breve' | 'medio' | 'extenso' | 'muy_extenso'
export type Estrategia = 'abp' | 'cooperativo' | 'invertida' | 'gamificacion' | 'rutinas' | 'ia'

export interface ActividadFase { id: string; texto: string; dua?: string } // dua: '101' = Compromiso + Acción
export interface FaseActs { fase: string; items: ActividadFase[] }
/** Imagen/esquema o fórmula (LaTeX) que acompaña una fase. */
export interface Visual {
  id: string
  tipo: 'img' | 'formula'
  src: string
  latex: string
  pie: string
  semana: string // 'todos' o índice del cronograma
  fase: string // '' = cualquier fase
  actividad: number // -1 = toda la fase
  escala?: number // imagen: % del ancho disponible; fórmula: % del tamaño normal
}
export interface ColumnaCfg { id: string; label: string; on: boolean }
export interface Refuerzo { id: string; estudiante: string; promedio: string; dificultad: string }
export interface FirmanteExtra { id: string; cargo: string; nombre: string }

export interface LayoutOpts {
  modo: 'auto' | 'manual'
  orientacion: 'portrait' | 'landscape'
  papel: 'A4' | 'Letter'
  margenMm: number
  fuentePt: number
  saltoPorSeccion: boolean
  evitarCortarFilas: boolean
  mostrarCredito: boolean
}

export interface Plan {
  tipo: TipoPlan
  metodologia: MetodologiaId
  actividades: FaseActs[]
  visuales: Visual[]
  columnas: ColumnaCfg[]
  numUnidades: number
  refuerzo: Refuerzo[]
  firmas: string[]
  fechaDocumento: string
  curriculoId: string
  unidad: string
  tema: string
  grado: string
  paralelos: string
  jornada: string
  anioLectivo: string
  inicio: string
  fin: string
  periodosSemana: number
  minutosPeriodo: number
  diasClase: number[] // 1=lunes … 5=viernes
  feriados: string[] // fechas sin clase (AAAA-MM-DD)
  objetivos: string[]
  criterios: string[]
  destrezas: DestrezaSel[]
  extension: Extension
  estrategia: Estrategia
  cronograma: SemanaRow[]
  nee12: NEE12[]
  nee3: NEE3[]
  instrucciones: string
  trimestre: number
  parcial: number
  respuesta: string
  layout: LayoutOpts
}

export interface Institucion {
  nombre: string
  linea: string
  logo: string
  mostrarMinisterio: boolean
  docente: string
  tutor: string
  vicerrector: string
  comision: string
  rector: string
  secretario: string
  inspector: string
  extras: FirmanteExtra[]
}

export interface PlanGuardado {
  id: string
  nombre: string
  trimestre: number
  parcial: number
  asignatura: string
  creado: string
  actualizado: string
  plan: Plan
}

export interface AppState {
  version: number
  institucion: Institucion
  curriculos: Curriculo[]
  plan: Plan
  planActualId: string | null
  iconos: Record<string, string>
  duaModo: 'cuadros' | 'iconos' // cómo se marca el DUA en cada actividad
  guardados: PlanGuardado[]
}

export type PageId =
  | 'institucion'
  | 'curriculo'
  | 'datos'
  | 'metodologia'
  | 'fases'
  | 'prompt'
  | 'documento'
  | 'biblioteca'
  | 'respaldo'
