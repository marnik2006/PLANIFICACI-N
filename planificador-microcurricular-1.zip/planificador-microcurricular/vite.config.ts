import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base './' permite abrir el build (dist/) desde cualquier carpeta o servidor estático.
// optimizeDeps.include: pdfmake se carga bajo demanda; preoptimizarlo evita que el servidor de
// desarrollo recargue la página la primera vez que se usa. MathJax se carga como script de navegador.
export default defineConfig({
  plugins: [react()],
  base: './',
  optimizeDeps: {
    include: [
      'pdfmake/build/pdfmake',
      'pdfmake/build/vfs_fonts',
    ],
  },
})
